

import org.testng.annotations.Test;
import org.testng.Assert;
import org.testng.AssertJUnit;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.Keys;

public class CourseList extends DriverIntializor {
	

	@Test(priority = 1, groups = "regression")
	public void announcements__1() // testing Platform administration --> Course list --> Course title(e.g CNET)
	// --> Add a new portlet: Announcement
	{
		currrent_test="announcements__1";
		try {

			driver.findElement(By.id("login")).clear();

		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("authentication", "id", "login");
			String xpathExpression = "//*[@id='" + idValue + "']";
			driver.findElement(By.xpath(xpathExpression)).clear();
		}

		try {

			driver.findElement(By.name("login")).sendKeys("admin");

		} catch (NoSuchElementException e) {
			String nameValue = repairerObj.repair("authentication", "name", "login");
			String xpathExpression = "//*[@name='" + nameValue + "']";
			driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
		}

		try {

			driver.findElement(By.id("password")).clear();

		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("authentication", "id", "password");
			String xpathExpression = "//*[@id='" + idValue + "']";
			driver.findElement(By.xpath(xpathExpression)).clear();
		}

		try {

			driver.findElement(By.name("password")).sendKeys("admin");

		} catch (NoSuchElementException e) {
			String nameValue = repairerObj.repair("authentication", "name", "password");
			String xpathExpression = "//*[@name='" + nameValue + "']";
			driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
		}

		try {

			driver.findElement(By.xpath("//*[@id=\"loginBox\"]/form/fieldset/button")).click();

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("authentication", "text", "Enter");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();
		}

		try {

			driver.findElement(By.xpath("//*[@id=\"userBannerLeft\"]/ul/li[3]/span/a")).click();

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("admin", "text", "Platform administration");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();
		}

		try {

			driver.findElement(By.xpath("//*[@id=\"claroBody\"]/ul/li[2]/ul/li[2]/a")).click(); // click on Course list
			flag = 1;																			// button in Courses

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("admin", "text", "Course list");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();
			flag = 2;
		}

		try {

			driver.findElement(By.xpath("//*[@id=\"claroBody\"]/table[2]/tbody/tr/td[2]/a")).click(); // click on Course
																										// Title(e.g
																										// CNET)
		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("admin_courses", "text", "DATA STRUCTURE");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();

		}

		try {

			driver.findElement(By.xpath("//*[@id=\"courseRightContent\"]/div/ul[1]/li[1]/a")).click(); // click on
																										// Course
																										// Title(e.g
																										// CNET)

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("course", "text", "Add a new portlet: Announcement");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();

		}

		try {
			Assert.assertTrue(driver.findElement(By.cssSelector("BODY")).getText()
					.matches("^[\\s\\S]*" + "Portlet created" + "[\\s\\S]*$"));

		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("admin_category", "id", "claroBody");
			String xpathExpression = "//*[@id='" + idValue + "']";
			Assert.assertEquals(driver.findElement(By.xpath(xpathExpression)).getText(), "Portlet created");

		}

		try {

			driver.findElement(By.xpath("//*[@id=\"courseRightContent\"]/div/div[2]/h1/a")).click(); // click on Manage
																										// Next course
																										// events

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("course", "text", " Manage");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();

		}

		try {

			driver.findElement(By.xpath("//*[@id=\"courseRightContent\"]/div/table/tbody/tr/td[2]/ul/li[1]/a")).click(); // click
																															// on
																															// Add
																															// announcement

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("announcements", "text", "Add announcement");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();

		}
		try {

			driver.findElement(By.id("title"))
					.sendKeys("Regarding AI Elective Registration for Batch-2019 in Fall-2022 Semester");

		} catch (NoSuchElementException e) {
			String nameValue = repairerObj.repair("announcements", "id", "title");
			String xpathExpression = "//*[@id='" + nameValue + "']";
			driver.findElement(By.xpath(xpathExpression))
					.sendKeys("Regarding AI Elective Registration for Batch-2019 in Fall-2022 Semester");
		}
		try {
			driver.findElement(By.xpath("//*[@id=\"newContent_bold\"]/span[1]")).click();

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("announcements", "id", " newContent_bold");
			String xpathExpression = "//*[@id='" + new_value + "']";
			driver.findElement(By.xpath(xpathExpression)).click();

		}

		driver.findElement(By.id("title")).sendKeys(Keys.chord(Keys.SHIFT, Keys.TAB));

		try {
			WebElement ele = driver.findElement(By.name("emailOption"));
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", ele);

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("announcements", "id", "emailOption");
			String xpathExpression = "//*[@id='" + new_value + "']";
			WebElement ele = driver.findElement(By.xpath(xpathExpression));
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", ele);
		}

		try {

			WebElement ele = driver.findElement(By.className("doCollapse"));
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", ele);

		} catch (NoSuchElementException e) {
			String nameValue = repairerObj.repair("announcements", "class", "doCollapse");
			String xpathExpression = "//*[@class='" + nameValue + "']";
			WebElement ele = driver.findElement(By.xpath(xpathExpression));
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", ele);
		}
		try {

			WebElement ele = driver.findElement(By.id("enable_visible_from"));
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", ele);

		} catch (NoSuchElementException e) {
			String nameValue = repairerObj.repair("announcements", "id", "enable_visible_from");
			String xpathExpression = "//*[@id='" + nameValue + "']";
			WebElement ele = driver.findElement(By.xpath(xpathExpression));
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", ele);
		}
		try {

			WebElement ele = driver.findElement(By.id("enable_visible_until"));
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", ele);

		} catch (NoSuchElementException e) {
			String nameValue = repairerObj.repair("announcements", "id", "enable_visible_until");
			String xpathExpression = "//*[@id='" + nameValue + "']";
			WebElement ele = driver.findElement(By.xpath(xpathExpression));
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", ele);
		}

		jse = (JavascriptExecutor) driver;
		jse.executeScript("scroll(0,300)");

		try {

			WebElement ele = driver.findElement(By.xpath("//*[@id=\"courseRightContent\"]/form/input"));
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", ele);

		} catch (NoSuchElementException e) {
			String nameValue = repairerObj.repair("announcements", "name", "submitEvent");
			String xpathExpression = "//*[@id='" + nameValue + "']";
			WebElement ele = driver.findElement(By.xpath(xpathExpression));
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", ele);
		}

		try {
			Assert.assertTrue(driver.findElement(By.cssSelector("BODY")).getText()
					.matches("^[\\s\\S]*" + "Announcement has been added" + "[\\s\\S]*$"));
		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("announcements", "id", "claroBody");
			String xpathExpression = "//*[@id='" + idValue + "']";
			AssertJUnit.assertEquals(driver.findElement(By.xpath(xpathExpression)).getText(),
					"Announcement has been added");

		}

		try {

			WebElement ele = driver.findElement(By.linkText("Clear up list of announcements"));
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", ele);

		} catch (NoSuchElementException e) {
			String nameValue = repairerObj.repair("announcements", "text", "Clear up list of announcements");
			String xpathExpression = "//*[@id='" + nameValue + "']";
			WebElement ele = driver.findElement(By.xpath(xpathExpression));
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", ele);
		}

		Alert alert = driver.switchTo().alert();
		alert.accept();
		try {

			Assert.assertTrue(driver.findElement(By.cssSelector("BODY")).getText()
					.matches("^[\\s\\S]*" + "Announcements list has been cleared up" + "[\\s\\S]*$"));
		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("announcements", "id", "claroBody");
			String xpathExpression = "//*[@id='" + idValue + "']";
			AssertJUnit.assertEquals(driver.findElement(By.xpath(xpathExpression)).getText(),
					"Announcements list has been cleared up");

		}

		
		try {

			WebElement ele = driver.findElement(By.linkText("Messages to selected users"));
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", ele);

		} catch (NoSuchElementException e) {
			String nameValue = repairerObj.repair("announcements", "text", "Messages to selected users");
			String xpathExpression = "//*[@id='" + nameValue + "']";
			WebElement ele = driver.findElement(By.xpath(xpathExpression));
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", ele);
		}

		try {

			driver.findElement(By.xpath("//*[@id=\"mslist1\"]/option[2]")).click();

		} catch (NoSuchElementException e) {
			String nameValue = repairerObj.repair("messagescourse", "text", "Afzal Aqeel");
			String xpathExpression = "//*[@id='" + nameValue + "']";
			WebElement ele = driver.findElement(By.xpath(xpathExpression));
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", ele);
		}

		try {

			WebElement ele = driver.findElement(
					By.xpath("//*[@id=\"courseRightContent\"]/div[2]/form/div/table/tbody/tr/td[2]/a[1]/img"));
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", ele);

		} catch (NoSuchElementException e) {
			String nameValue = repairerObj.repair("messagescourse", "class", "arrows");
			String xpathExpression = "//*[@class='" + nameValue + "']";
			WebElement ele = driver.findElement(By.xpath(xpathExpression));
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", ele);
		}
		try {

			driver.findElement(By.xpath("//*[@id=\"courseRightContent\"]/div[2]/form/div/div/input[1]"))
					.sendKeys("FYP Hardware");

		} catch (NoSuchElementException e) {
			String nameValue = repairerObj.repair("messagescourse", "name", "subject");
			String xpathExpression = "//*[@name='" + nameValue + "']";
			driver.findElement(By.xpath(xpathExpression)).sendKeys("FYP Hardware");
		}

		try {

			WebElement ele = driver.findElement(By.cssSelector(
					"#courseRightContent > div.messagesform > form > div > div > input[type=submit]:nth-child(12)"));
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", ele);

		} catch (NoSuchElementException e) {
			String nameValue = repairerObj.repair("messagescourse", "name", "submitMessage");
			String xpathExpression = "//*[@name='" + nameValue + "']";
			WebElement ele = driver.findElement(By.xpath(xpathExpression));
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", ele);

		}
		try {

			Assert.assertTrue(driver.findElement(By.cssSelector("BODY")).getText()
					.matches("^[\\s\\S]*" + "Message sent" + "[\\s\\S]*$"));
		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("messagescourse", "id", "claroBody");
			String xpathExpression = "//*[@id='" + idValue + "']";
			AssertJUnit.assertEquals(driver.findElement(By.xpath(xpathExpression)).getText(), "Message sent");

		}
		try {

			driver.findElement(By.id("courseHomePage")).click();

		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("course", "id", "courseHomePage");
			String xpathExpression = "//*[@id='" + idValue + "']";
			driver.findElement(By.xpath(xpathExpression)).click();
		}
		

		try {

			driver.findElement(By.xpath("//*[@id=\"courseRightContent\"]/div/div/h1/span[2]/a[4]/img")).click(); // click
																													// on
																													// delete
																													// portlet

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("course", "alt", "Delete");
			String xpathExpression = "//img[@alt='" + new_value + "']";
			driver.findElement(By.xpath(xpathExpression)).click();

		}
		// logout
		try {

			WebElement ele = driver.findElements(By.xpath("//*[@id=\"userBannerRight\"]/ul/li[3]/span/a")).get(0);
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", ele); // logout

		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("messagescourse", "id", "userBannerRight");
			String xpathExpression = "//*[@id='" + idValue + "']";
			WebElement ele = driver.findElements(By.xpath(xpathExpression)).get(0);
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", ele);
		}
	}

	
	
	@Test(priority = 2, groups = "regression")
	public void messages_course__1() // testing Platform administration --> Course list --> Course title(e.g CNET)
	// --> Add a new portlet: Announcement ---> messagescourse
	{
		currrent_test="messages_course__1";
		try {

			driver.findElement(By.id("login")).clear();

		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("authentication", "id", "login");
			String xpathExpression = "//*[@id='" + idValue + "']";
			driver.findElement(By.xpath(xpathExpression)).clear();
		}

		try {

			driver.findElement(By.name("login")).sendKeys("admin");

		} catch (NoSuchElementException e) {
			String nameValue = repairerObj.repair("authentication", "name", "login");
			String xpathExpression = "//*[@name='" + nameValue + "']";
			driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
		}

		try {

			driver.findElement(By.id("password")).clear();

		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("authentication", "id", "password");
			String xpathExpression = "//*[@id='" + idValue + "']";
			driver.findElement(By.xpath(xpathExpression)).clear();
		}

		try {

			driver.findElement(By.name("password")).sendKeys("admin");

		} catch (NoSuchElementException e) {
			String nameValue = repairerObj.repair("authentication", "name", "password");
			String xpathExpression = "//*[@name='" + nameValue + "']";
			driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
		}

		try {

			driver.findElement(By.xpath("//*[@id=\"loginBox\"]/form/fieldset/button")).click();

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("authentication", "text", "Enter");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();
		}

		try {

			driver.findElement(By.xpath("//*[@id=\"userBannerLeft\"]/ul/li[3]/span/a")).click();

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("admin", "text", "Platform administration");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();
		}

		try {

			driver.findElement(By.xpath("//*[@id=\"claroBody\"]/ul/li[2]/ul/li[2]/a")).click(); // click on Course list
			flag = 1;																			// button in Courses

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("admin", "text", "Course list");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();
			flag = 2;
		}

		try {

			driver.findElement(By.xpath("//*[@id=\"claroBody\"]/table[2]/tbody/tr/td[2]/a")).click(); // click on Course
																										// Title(e.g
																										// CNET)
		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("admin_courses", "text", "DATA STRUCTURE");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();

		}

		try {

			driver.findElement(By.xpath("//*[@id=\"courseRightContent\"]/div/ul[1]/li[1]/a")).click(); // click on
																										// Course
																										// Title(e.g
																										// CNET)

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("course", "text", "Add a new portlet: Announcement");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();

		}

		try {
			Assert.assertTrue(driver.findElement(By.cssSelector("BODY")).getText()
					.matches("^[\\s\\S]*" + "Portlet created" + "[\\s\\S]*$"));

		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("admin_category", "id", "claroBody");
			String xpathExpression = "//*[@id='" + idValue + "']";
			Assert.assertEquals(driver.findElement(By.xpath(xpathExpression)).getText(), "Portlet created");

		}

		try {

			driver.findElement(By.xpath("//*[@id=\"courseRightContent\"]/div/div[2]/h1/a")).click(); // click on Manage
																										// Next course
																										// events

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("course", "text", " Manage");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();

		}

		try {

			driver.findElement(By.xpath("//*[@id=\"courseRightContent\"]/div/table/tbody/tr/td[2]/ul/li[1]/a")).click(); // click
																															// on
																															// Add
																															// announcement

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("announcements", "text", "Add announcement");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();

		}
		try {

			driver.findElement(By.id("title"))
					.sendKeys("Regarding AI Elective Registration for Batch-2019 in Fall-2022 Semester");

		} catch (NoSuchElementException e) {
			String nameValue = repairerObj.repair("announcements", "id", "title");
			String xpathExpression = "//*[@id='" + nameValue + "']";
			driver.findElement(By.xpath(xpathExpression))
					.sendKeys("Regarding AI Elective Registration for Batch-2019 in Fall-2022 Semester");
		}
		try {
			driver.findElement(By.xpath("//*[@id=\"newContent_bold\"]/span[1]")).click();

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("announcements", "id", " newContent_bold");
			String xpathExpression = "//*[@id='" + new_value + "']";
			driver.findElement(By.xpath(xpathExpression)).click();

		}

		driver.findElement(By.id("title")).sendKeys(Keys.chord(Keys.SHIFT, Keys.TAB));

		try {
			WebElement ele = driver.findElement(By.name("emailOption"));
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", ele);

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("announcements", "id", "emailOption");
			String xpathExpression = "//*[@id='" + new_value + "']";
			WebElement ele = driver.findElement(By.xpath(xpathExpression));
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", ele);
		}

		try {

			WebElement ele = driver.findElement(By.className("doCollapse"));
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", ele);

		} catch (NoSuchElementException e) {
			String nameValue = repairerObj.repair("announcements", "class", "doCollapse");
			String xpathExpression = "//*[@class='" + nameValue + "']";
			WebElement ele = driver.findElement(By.xpath(xpathExpression));
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", ele);
		}
		try {

			WebElement ele = driver.findElement(By.id("enable_visible_from"));
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", ele);

		} catch (NoSuchElementException e) {
			String nameValue = repairerObj.repair("announcements", "id", "enable_visible_from");
			String xpathExpression = "//*[@id='" + nameValue + "']";
			WebElement ele = driver.findElement(By.xpath(xpathExpression));
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", ele);
		}
		try {

			WebElement ele = driver.findElement(By.id("enable_visible_until"));
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", ele);

		} catch (NoSuchElementException e) {
			String nameValue = repairerObj.repair("announcements", "id", "enable_visible_until");
			String xpathExpression = "//*[@id='" + nameValue + "']";
			WebElement ele = driver.findElement(By.xpath(xpathExpression));
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", ele);
		}

		jse = (JavascriptExecutor) driver;
		jse.executeScript("scroll(0,300)");

		try {

			WebElement ele = driver.findElement(By.xpath("//*[@id=\"courseRightContent\"]/form/input"));
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", ele);

		} catch (NoSuchElementException e) {
			String nameValue = repairerObj.repair("announcements", "name", "submitEvent");
			String xpathExpression = "//*[@id='" + nameValue + "']";
			WebElement ele = driver.findElement(By.xpath(xpathExpression));
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", ele);
		}

		try {
			Assert.assertTrue(driver.findElement(By.cssSelector("BODY")).getText()
					.matches("^[\\s\\S]*" + "Announcement has been added" + "[\\s\\S]*$"));
		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("announcements", "id", "claroBody");
			String xpathExpression = "//*[@id='" + idValue + "']";
			AssertJUnit.assertEquals(driver.findElement(By.xpath(xpathExpression)).getText(),
					"Announcement has been added");

		}

		try {

			WebElement ele = driver.findElement(By.linkText("Clear up list of announcements"));
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", ele);

		} catch (NoSuchElementException e) {
			String nameValue = repairerObj.repair("announcements", "text", "Clear up list of announcements");
			String xpathExpression = "//*[@id='" + nameValue + "']";
			WebElement ele = driver.findElement(By.xpath(xpathExpression));
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", ele);
		}

		Alert alert = driver.switchTo().alert();
		alert.accept();

		try {

			Assert.assertTrue(driver.findElement(By.cssSelector("BODY")).getText()
					.matches("^[\\s\\S]*" + "Announcements list has been cleared up" + "[\\s\\S]*$"));
		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("announcements", "id", "claroBody");
			String xpathExpression = "//*[@id='" + idValue + "']";
			AssertJUnit.assertEquals(driver.findElement(By.xpath(xpathExpression)).getText(),
					"Announcements list has been cleared up");

		}

		try {

			WebElement ele = driver.findElement(By.linkText("Messages to selected users"));
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", ele);

		} catch (NoSuchElementException e) {
			String nameValue = repairerObj.repair("announcements", "text", "Messages to selected users");
			String xpathExpression = "//*[@id='" + nameValue + "']";
			WebElement ele = driver.findElement(By.xpath(xpathExpression));
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", ele);
		}

		try {

			driver.findElement(By.xpath("//*[@id=\"mslist1\"]/option[2]")).click();

		} catch (NoSuchElementException e) {
			String nameValue = repairerObj.repair("messagescourse", "text", "Afzal Aqeel");
			String xpathExpression = "//*[@id='" + nameValue + "']";
			WebElement ele = driver.findElement(By.xpath(xpathExpression));
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", ele);
		}

		try {

			WebElement ele = driver.findElement(
					By.xpath("//*[@id=\"courseRightContent\"]/div[2]/form/div/table/tbody/tr/td[2]/a[1]/img"));
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", ele);

		} catch (NoSuchElementException e) {
			String nameValue = repairerObj.repair("messagescourse", "class", "arrows");
			String xpathExpression = "//*[@class='" + nameValue + "']";
			WebElement ele = driver.findElement(By.xpath(xpathExpression));
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", ele);
		}
		try {

			driver.findElement(By.xpath("//*[@id=\"courseRightContent\"]/div[2]/form/div/div/input[1]"))
					.sendKeys("FYP Hardware");

		} catch (NoSuchElementException e) {
			String nameValue = repairerObj.repair("messagescourse", "name", "subject");
			String xpathExpression = "//*[@name='" + nameValue + "']";
			driver.findElement(By.xpath(xpathExpression)).sendKeys("FYP Hardware");
		}

		try {

			WebElement ele = driver.findElement(By.cssSelector(
					"#courseRightContent > div.messagesform > form > div > div > input[type=submit]:nth-child(12)"));
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", ele);

		} catch (NoSuchElementException e) {
			String nameValue = repairerObj.repair("messagescourse", "name", "submitMessage");
			String xpathExpression = "//*[@name='" + nameValue + "']";
			WebElement ele = driver.findElement(By.xpath(xpathExpression));
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", ele);

		}
		try {

			Assert.assertTrue(driver.findElement(By.cssSelector("BODY")).getText()
					.matches("^[\\s\\S]*" + "Message sent" + "[\\s\\S]*$"));
		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("messagescourse", "id", "claroBody");
			String xpathExpression = "//*[@id='" + idValue + "']";
			AssertJUnit.assertEquals(driver.findElement(By.xpath(xpathExpression)).getText(), "Message sent");

		}

		// logout
		try {

			WebElement ele = driver.findElements(By.xpath("//*[@id=\"userBannerRight\"]/ul/li[3]/span/a")).get(0);
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", ele); // logout

		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("messagescourse", "id", "userBannerRight");
			String xpathExpression = "//*[@id='" + idValue + "']";
			WebElement ele = driver.findElements(By.xpath(xpathExpression)).get(0);
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", ele);
		}
	}

	@Test(priority = 3, groups = "regression")
	public void agenda__1() // testing Platform administration --> Course list --> Course title(e.g CNET)
							// --> agenda
	{
		currrent_test="agenda__1";
		// logIn
		try {

			driver.findElement(By.id("login")).clear();

		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("authentication", "id", "login");
			String xpathExpression = "//*[@id='" + idValue + "']";
			driver.findElement(By.xpath(xpathExpression)).clear();
		}

		try {

			driver.findElement(By.name("login")).sendKeys("admin");

		} catch (NoSuchElementException e) {
			String nameValue = repairerObj.repair("authentication", "name", "login");
			String xpathExpression = "//*[@name='" + nameValue + "']";
			driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
		}

		try {

			driver.findElement(By.id("password")).clear();

		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("authentication", "id", "password");
			String xpathExpression = "//*[@id='" + idValue + "']";
			driver.findElement(By.xpath(xpathExpression)).clear();
		}

		try {

			driver.findElement(By.name("password")).sendKeys("admin");

		} catch (NoSuchElementException e) {
			String nameValue = repairerObj.repair("authentication", "name", "password");
			String xpathExpression = "//*[@name='" + nameValue + "']";
			driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
		}

		try {

			driver.findElement(By.xpath("//*[@id=\"loginBox\"]/form/fieldset/button")).click();

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("authentication", "text", "Enter");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();
		}

		try {

			driver.findElement(By.xpath("//*[@id=\"userBannerLeft\"]/ul/li[3]/span/a")).click();

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("admin", "text", "Platform administration");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();
		}

		try {

			driver.findElement(By.xpath("//*[@id=\"claroBody\"]/ul/li[2]/ul/li[2]/a")).click(); // click on Course list
			flag = 1;																			// button in Courses

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("admin", "text", "Course list");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();
			flag = 2;
		}

		try {

			driver.findElement(By.xpath("//*[@id=\"claroBody\"]/table[2]/tbody/tr/td[2]/a")).click(); // click on Course
																										// Title(e.g
																										// CNET)
		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("admin_courses", "text", "DATA STRUCTURE");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();

		}

		// Delete portlet

		try {

			driver.findElement(By.xpath("//*[@id=\"courseRightContent\"]/div/div/h1/span[2]/a[4]/img")).click(); // click
																													// on
																													// delete
																													// portlet

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("course", "alt", "Delete");
			String xpathExpression = "//img[@alt='" + new_value + "']";
			driver.findElement(By.xpath(xpathExpression)).click();

		}

		try {

			Assert.assertTrue(driver.findElement(By.cssSelector("BODY")).getText()
					.matches("^[\\s\\S]*" + "Portlet deleted" + "[\\s\\S]*$"));
		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("course", "id", "claroBody");
			String xpathExpression = "//*[@id='" + idValue + "']";
			AssertJUnit.assertEquals(driver.findElement(By.xpath(xpathExpression)).getText(), "Portlet deleted");

		}

		try {

			driver.findElement(By.linkText("Add a new portlet: Calendar")).click(); // Add a new portlet

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("course", "alt", "Add a new portlet: Calendar");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();

		}

		try {

			Assert.assertTrue(driver.findElement(By.cssSelector("BODY")).getText()
					.matches("^[\\s\\S]*" + "Portlet created" + "[\\s\\S]*$"));
		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("course", "id", "claroBody");
			String xpathExpression = "//*[@id='" + idValue + "']";
			AssertJUnit.assertEquals(driver.findElement(By.xpath(xpathExpression)).getText(), "Portlet created");

		}

		try {

			driver.findElement(By.xpath("//*[@id=\"courseRightContent\"]/div/div[2]/h1/a")).click(); // click on Manage
																										// Next course
																										// events

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("course", "text", " Manage");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();

		}

		try {

			driver.findElement(By.xpath("//*[@id=\"courseRightContent\"]/div/table/tbody/tr/td[2]/ul/li[2]/a")).click(); // click
			// on
			// Add
			// an event

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("agenda", "text", "Add an event");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();

		}
		try {

			driver.findElement(By.id("title")).sendKeys("Batch 22 Orientation Session");

		} catch (NoSuchElementException e) {
			String nameValue = repairerObj.repair("agenda", "id", "title");
			String xpathExpression = "//*[@id='" + nameValue + "']";
			driver.findElement(By.xpath(xpathExpression)).sendKeys("Batch 22 Orientation Session");
		}

		try {

			driver.findElement(By.id("lasting")).sendKeys("2-Hours");

		} catch (NoSuchElementException e) {
			String nameValue = repairerObj.repair("agenda", "id", "lasting");
			String xpathExpression = "//*[@id='" + nameValue + "']";
			driver.findElement(By.xpath(xpathExpression)).sendKeys("2-Hours");
		}

		try {

			driver.findElement(By.id("location")).sendKeys("Auditorium");

		} catch (NoSuchElementException e) {
			String nameValue = repairerObj.repair("agenda", "id", "location");
			String xpathExpression = "//*[@id='" + nameValue + "']";
			driver.findElement(By.xpath(xpathExpression)).sendKeys("Auditorium");
		}

		try {

			driver.findElement(By.id("speakers")).sendKeys("Dr. Ahmad Ali, Dr. Sikandar Sultan");

		} catch (NoSuchElementException e) {
			String nameValue = repairerObj.repair("agenda", "id", "speakers");
			String xpathExpression = "//*[@id='" + nameValue + "']";
			driver.findElement(By.xpath(xpathExpression)).sendKeys("Dr. Ahmad Ali, Dr. Sikandar Sultan");
		}
		driver.findElement(By.id("speakers")).sendKeys(Keys.chord(Keys.SHIFT, Keys.TAB));
		try {

			WebElement ele = driver.findElement(By.xpath("//*[@id=\"courseRightContent\"]/form/input"));
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", ele);

		} catch (NoSuchElementException e) {
			String nameValue = repairerObj.repair("agenda", "name", "submitEvent");
			String xpathExpression = "//*[@name='" + nameValue + "']";
			WebElement ele = driver.findElement(By.xpath(xpathExpression));
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", ele);

		}

		try {

			Assert.assertTrue(driver.findElement(By.cssSelector("BODY")).getText()
					.matches("^[\\s\\S]*" + "Event added to the agenda." + "[\\s\\S]*$"));
		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("agenda", "id", "claroBody");
			String xpathExpression = "//*[@id='" + idValue + "']";
			AssertJUnit.assertEquals(driver.findElement(By.xpath(xpathExpression)).getText(),
					"Event added to the agenda.");

		}

		try {

			driver.findElement(By.xpath("//*[@id=\"courseRightContent\"]/div[3]/div[3]/a[2]/img")).click();

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("agenda", "alt", "Delete");
			String xpathExpression = "//img[@alt='" + new_value + "']";
			driver.findElement(By.xpath(xpathExpression)).click();

		}
		Alert alert = driver.switchTo().alert();
		alert.accept();

		try {

			Assert.assertTrue(driver.findElement(By.cssSelector("BODY")).getText()
					.matches("^[\\s\\S]*" + "Event deleted from the agenda." + "[\\s\\S]*$"));
		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("agenda", "id", "claroBody");
			String xpathExpression = "//*[@id='" + idValue + "']";
			AssertJUnit.assertEquals(driver.findElement(By.xpath(xpathExpression)).getText(),
					"Event deleted from the agenda.");

		}

		// logout

		try {
			driver.findElements(By.xpath("//*[@id=\"userBannerRight\"]/ul/li[3]/span/a")).get(0).click(); // click on
																											// logout

		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("agenda", "id", "userBannerRight");
			String xpathExpression = "//*[@id='" + idValue + "']";
			driver.findElements(By.xpath(xpathExpression)).get(0).click();
		}

	}

	@Test(priority = 4, groups = "regression")
	public void course__1() // testing Platform administration --> Course list --> Course title(e.g CNET)
								// --> Add a new portlet: Announcement
	{
		currrent_test="course__1";
		// logIn

		try {

			driver.findElement(By.id("login")).clear();

		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("authentication", "id", "login");
			String xpathExpression = "//*[@id='" + idValue + "']";
			driver.findElement(By.xpath(xpathExpression)).clear();
		}

		try {

			driver.findElement(By.name("login")).sendKeys("admin");

		} catch (NoSuchElementException e) {
			String nameValue = repairerObj.repair("authentication", "name", "login");
			String xpathExpression = "//*[@name='" + nameValue + "']";
			driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
		}

		try {

			driver.findElement(By.id("password")).clear();

		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("authentication", "id", "password");
			String xpathExpression = "//*[@id='" + idValue + "']";
			driver.findElement(By.xpath(xpathExpression)).clear();
		}

		try {

			driver.findElement(By.name("password")).sendKeys("admin");

		} catch (NoSuchElementException e) {
			String nameValue = repairerObj.repair("authentication", "name", "password");
			String xpathExpression = "//*[@name='" + nameValue + "']";
			driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
		}

		try {

			driver.findElement(By.xpath("//*[@id=\"loginBox\"]/form/fieldset/button")).click();

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("authentication", "text", "Enter");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();
		}

		try {

			driver.findElement(By.xpath("//*[@id=\"userBannerLeft\"]/ul/li[3]/span/a")).click();

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("admin", "text", "Platform administration");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();
		}

		try {

			driver.findElement(By.xpath("//*[@id=\"claroBody\"]/ul/li[2]/ul/li[2]/a")).click(); // click on Course list
			flag = 1;																			// button in Courses

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("admin", "text", "Course list");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();
			flag = 2;
		}

		try {

			driver.findElement(By.xpath("//*[@id=\"claroBody\"]/table[2]/tbody/tr/td[2]/a")).click(); // click on Course
																										// Title(e.g
																										// CNET)
		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("admin_courses", "text", "DATA STRUCTURE");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();

		}

		// Delete portlet

		try {

			driver.findElement(By.xpath("//*[@id=\"courseRightContent\"]/div/div/h1/span[2]/a[4]/img")).click(); // click
																													// on
																													// delete
																													// portlet

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("course", "alt", "Delete");
			String xpathExpression = "//img[@alt='" + new_value + "']";
			driver.findElement(By.xpath(xpathExpression)).click();

		}
		

		try {

			Assert.assertTrue(driver.findElement(By.cssSelector("BODY")).getText()
					.matches("^[\\s\\S]*" + "Portlet deleted" + "[\\s\\S]*$"));
		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("course", "id", "claroBody");
			String xpathExpression = "//*[@id='" + idValue + "']";
			AssertJUnit.assertEquals(driver.findElement(By.xpath(xpathExpression)).getText(), "Portlet deleted");

		}

		try {

			driver.findElement(By.linkText("Add a new portlet: Headlines")).click(); // Add a new portlet

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("course", "alt", "Add a new portlet: Headlines");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();

		}

		try {

			Assert.assertTrue(driver.findElement(By.cssSelector("BODY")).getText()
					.matches("^[\\s\\S]*" + "Portlet created" + "[\\s\\S]*$"));
		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("course", "id", "claroBody");
			String xpathExpression = "//*[@id='" + idValue + "']";
			AssertJUnit.assertEquals(driver.findElement(By.xpath(xpathExpression)).getText(), "Portlet created");

		}
		// events
		try {

			driver.findElement(By.xpath("//*[@id=\"courseRightContent\"]/div/div[2]/h1/a")).click(); // click on Manage
																										// Next course
																										// events

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("course", "text", " Manage");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();

		}
		try {

			driver.findElement(By.xpath("//*[@id=\"courseRightContent\"]/div[1]/table/tbody/tr/td[2]/ul/li[1]/a"))
					.click();

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("tool_intro", "text", " New headline");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();

		}

//		try {
//
//			driver.findElement(By.xpath("//*[@id=\"content_formatselect_open\"]")).click();
//
//		} catch (NoSuchElementException e) {
//			String new_value = repairerObj.repair("tool_intro", "id", "content_formatselect_open");
//			String xpathExpression = "//*[@id='" + new_value + "']";
//			driver.findElement(By.xpath(xpathExpression)).click();
//
//		}
//
//		try {
//
//			driver.findElement(By.linkText("Paragraph")).click();
//		} catch (NoSuchElementException e) {
//			String new_value = repairerObj.repair("tool_intro", "text", " Paragraph");
//			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
//			driver.findElement(By.xpath(xpathExpression)).click();
//
//		}

		try {

			WebElement ele = driver.findElement(By.xpath("//*[@id=\"courseRightContent\"]/form/input"));
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", ele);

		} catch (NoSuchElementException e) {
			String nameValue = repairerObj.repair("agenda", "name", "submitEvent");
			String xpathExpression = "//*[@name='" + nameValue + "']";
			WebElement ele = driver.findElement(By.xpath(xpathExpression));
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", ele);

		}

		try {

			Assert.assertTrue(driver.findElement(By.cssSelector("BODY")).getText()
					.matches("^[\\s\\S]*" + "Introduction added" + "[\\s\\S]*$"));
		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("agenda", "id", "claroBody");
			String xpathExpression = "//*[@id='" + idValue + "']";
			AssertJUnit.assertEquals(driver.findElement(By.xpath(xpathExpression)).getText(), "Introduction added");

		}

		try {

			driver.findElement(By.xpath("//*[@id=\"courseRightContent\"]/div[3]/div[2]/a[2]/img")).click();

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("tool_intro", "alt", "Delete");
			String xpathExpression = "//img[@alt='" + new_value + "']";
			driver.findElement(By.xpath(xpathExpression)).click();

		}
		Alert alert = driver.switchTo().alert();
		alert.accept();

		try {

			Assert.assertTrue(driver.findElement(By.cssSelector("BODY")).getText()
					.matches("^[\\s\\S]*" + "Introduction deleted" + "[\\s\\S]*$"));
		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("agenda", "id", "claroBody");
			String xpathExpression = "//*[@id='" + idValue + "']";
			AssertJUnit.assertEquals(driver.findElement(By.xpath(xpathExpression)).getText(), "Introduction deleted");

		}

		// logout

		try {
			driver.findElements(By.xpath("//*[@id=\"userBannerRight\"]/ul/li[3]/span/a")).get(0).click(); // click on
																											// logout

		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("agenda", "id", "userBannerRight");
			String xpathExpression = "//*[@id='" + idValue + "']";
			driver.findElements(By.xpath(xpathExpression)).get(0).click();
		}
	}

	@Test(priority = 5, groups = "regression")
	public void course_description__1() // Platform administration --> Course list --> Course title --> Course
										// description
	{
		currrent_test="course_description__1";
		// logIn

		try {

			driver.findElement(By.id("login")).clear();

		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("authentication", "id", "login");
			String xpathExpression = "//*[@id='" + idValue + "']";
			driver.findElement(By.xpath(xpathExpression)).clear();
		}

		try {

			driver.findElement(By.name("login")).sendKeys("admin");

		} catch (NoSuchElementException e) {
			String nameValue = repairerObj.repair("authentication", "name", "login");
			String xpathExpression = "//*[@name='" + nameValue + "']";
			driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
		}

		try {

			driver.findElement(By.id("password")).clear();

		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("authentication", "id", "password");
			String xpathExpression = "//*[@id='" + idValue + "']";
			driver.findElement(By.xpath(xpathExpression)).clear();
		}

		try {

			driver.findElement(By.name("password")).sendKeys("admin");

		} catch (NoSuchElementException e) {
			String nameValue = repairerObj.repair("authentication", "name", "password");
			String xpathExpression = "//*[@name='" + nameValue + "']";
			driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
		}

		try {

			driver.findElement(By.xpath("//*[@id=\"loginBox\"]/form/fieldset/button")).click();

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("authentication", "text", "Enter");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();
		}

		try {

			driver.findElement(By.xpath("//*[@id=\"userBannerLeft\"]/ul/li[3]/span/a")).click();

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("admin", "text", "Platform administration");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();
		}

		try {

			driver.findElement(By.xpath("//*[@id=\"claroBody\"]/ul/li[2]/ul/li[2]/a")).click(); // click on Course list
			flag = 1;																				// button in Courses

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("admin", "text", "Course list");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();
			flag = 2;
		}

		try {

			driver.findElement(By.xpath("//*[@id=\"claroBody\"]/table[2]/tbody/tr/td[2]/a")).click(); // click on Course
																										// Title(e.g
																										// CNET)
		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("admin_courses", "text", "DATA STRUCTURE");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();

		}

		try {

			driver.findElement(By.id("CLDSC")).click();
		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("course", "id", "CLDSC");
			String xpathExpression = "//*[@id='" + new_value + "']";
			driver.findElement(By.xpath(xpathExpression)).click();

		}

		try {

			driver.findElement(By.xpath("//*[@id=\"courseRightContent\"]/form/fieldset/input[4]")).click();
		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("course_description", "name", "add");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();

		}
		

		try {

			WebElement ele = driver.findElement(By.xpath("//*[@id=\"descContent_formatselect_open\"]"));
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", ele);

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("course_description", "id", "descContent_formatselect_open");
			String xpathExpression = "//*[@id='" + new_value + "']";
			WebElement ele = driver.findElement(By.xpath(xpathExpression));
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", ele);

		}
		
		try {

			driver.findElement(By.linkText("Heading 1")).click();
		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("course_description", "text", " Heading 1");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();

		}

		try {

			WebElement ele = driver.findElement(By.xpath("//*[@id=\"courseRightContent\"]/form/p[1]/input"));
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", ele);

		} catch (NoSuchElementException e) {
			String nameValue = repairerObj.repair("course_description", "name", "save");
			String xpathExpression = "//*[@name='" + nameValue + "']";
			WebElement ele = driver.findElement(By.xpath(xpathExpression));
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", ele);

		}

		try {

			Assert.assertTrue(driver.findElement(By.cssSelector("BODY")).getText()
					.matches("^[\\s\\S]*" + "Description added" + "[\\s\\S]*$"));
		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("agenda", "id", "claroBody");
			String xpathExpression = "//*[@id='" + idValue + "']";
			AssertJUnit.assertEquals(driver.findElement(By.xpath(xpathExpression)).getText(), "Description added");

		}

		try {
			driver.findElement(By.xpath("//*[@id=\"courseRightContent\"]/div[3]/div[2]/a[2]/img")).click();

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("tool_intro", "alt", "Delete");
			String xpathExpression = "//img[@alt='" + new_value + "']";
			driver.findElement(By.xpath(xpathExpression)).click();

		}
		Alert alert = driver.switchTo().alert();
		alert.accept();

		try {

			Assert.assertTrue(driver.findElement(By.cssSelector("BODY")).getText()
					.matches("^[\\s\\S]*" + "Description deleted." + "[\\s\\S]*$"));
		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("agenda", "id", "claroBody");
			String xpathExpression = "//*[@id='" + idValue + "']";
			AssertJUnit.assertEquals(driver.findElement(By.xpath(xpathExpression)).getText(), "Description deleted.");

		}

		// logout

		try {
			driver.findElements(By.xpath("//*[@id=\"userBannerRight\"]/ul/li[3]/span/a")).get(0).click(); // click on
																											// logout

		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("agenda", "id", "userBannerRight");
			String xpathExpression = "//*[@id='" + idValue + "']";
			driver.findElements(By.xpath(xpathExpression)).get(0).click();
		}

	}

	@Test(priority = 5, groups = "regression")
	public void document__1() // Platform administration --> Course list --> Course title --> Document
	{
		currrent_test="document__1";
		// logIn
		try {

			driver.findElement(By.id("login")).clear();

		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("authentication", "id", "login");
			String xpathExpression = "//*[@id='" + idValue + "']";
			driver.findElement(By.xpath(xpathExpression)).clear();
		}

		try {

			driver.findElement(By.name("login")).sendKeys("admin");

		} catch (NoSuchElementException e) {
			String nameValue = repairerObj.repair("authentication", "name", "login");
			String xpathExpression = "//*[@name='" + nameValue + "']";
			driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
		}

		try {

			driver.findElement(By.id("password")).clear();

		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("authentication", "id", "password");
			String xpathExpression = "//*[@id='" + idValue + "']";
			driver.findElement(By.xpath(xpathExpression)).clear();
		}

		try {

			driver.findElement(By.name("password")).sendKeys("admin");

		} catch (NoSuchElementException e) {
			String nameValue = repairerObj.repair("authentication", "name", "password");
			String xpathExpression = "//*[@name='" + nameValue + "']";
			driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
		}

		try {

			driver.findElement(By.xpath("//*[@id=\"loginBox\"]/form/fieldset/button")).click();

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("authentication", "text", "Enter");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();
		}

		try {

			driver.findElement(By.xpath("//*[@id=\"userBannerLeft\"]/ul/li[3]/span/a")).click();

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("admin", "text", "Platform administration");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();
		}

		try {

			driver.findElement(By.xpath("//*[@id=\"claroBody\"]/ul/li[2]/ul/li[2]/a")).click(); // click on Course list
			flag = 1;																				// button in Courses

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("admin", "text", "Course list");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();
			flag = 2;
		}

		try {

			driver.findElement(By.xpath("//*[@id=\"claroBody\"]/table[2]/tbody/tr/td[2]/a")).click(); // click on Course
																										// Title(e.g
																										// CNET)
		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("admin_courses", "text", "DATA STRUCTURE");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();

		}

		try {

			driver.findElement(By.id("CLDOC")).click();
		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("document", "id", "CLDOC");
			String xpathExpression = "//*[@id='" + new_value + "']";
			driver.findElement(By.xpath(xpathExpression)).click();

		}

		// File Upload
		try {
			
			driver.findElement(By.xpath("//*[@id=\"courseRightContent\"]/div/table/tbody/tr/td[2]/ul/li[4]/a")).click();
		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("document", "text", "Upload file");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();

		}

		try {
			driver.findElement(By.xpath("//*[@id=\"courseRightContent\"]/div[2]/div[2]/form/input")).click();
		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("document", "value", "Ok");
			String xpathExpression = "//input[@value='" + new_value + "']";
			driver.findElement(By.xpath(xpathExpression)).click();

		}

		try {

			Assert.assertTrue(driver.findElement(By.cssSelector("BODY")).getText()
					.matches("^[\\s\\S]*" + "No file uploaded" + "[\\s\\S]*$"));
		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("document", "id", "claroBody");
			String xpathExpression = "//*[@id='" + idValue + "']";
			AssertJUnit.assertEquals(driver.findElement(By.xpath(xpathExpression)).getText(), "No file uploaded");
			
		}
		// Hyperlink
		try {
			
			driver.findElement(By.xpath("//*[@id=\"courseRightContent\"]/div[1]/table/tbody/tr/td[2]/ul/li[6]/a"))
					.click();
		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("document", "text", "Create hyperlink");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();

		}
		try {

			driver.findElement(By.id("fileName")).clear();

		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("document", "id", "fileName");
			String xpathExpression = "//*[@id='" + idValue + "']";
			driver.findElement(By.xpath(xpathExpression)).clear();
		}

		try {

			driver.findElement(By.xpath("//*[@name=\"fileName\"]")).sendKeys("Slate");
		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("document", "name", "fileName");
			String xpathExpression = "//*[@name='" + new_value + "']";
			driver.findElement(By.xpath(xpathExpression)).sendKeys("Slate");
			
		}


		try {

			driver.findElement(By.xpath("//*[@id=\"url\"]")).sendKeys("http://slate.nu.edu.pk/portal");
		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("document", "id", "url");
			String xpathExpression = "//*[@id='" + new_value + "']";
			driver.findElement(By.xpath(xpathExpression)).sendKeys("http://slate.nu.edu.pk/portal");

		}
		try {

			driver.findElement(By.xpath("//*[@id=\"comment\"]")).sendKeys("This is slate.");
		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("document", "id", "comment");
			String xpathExpression = "//*[@id='" + new_value + "']";
			driver.findElement(By.xpath(xpathExpression)).sendKeys("This is slate.");

		}
		try {
			driver.findElement(By.xpath("//*[@id=\"courseRightContent\"]/div[2]/div[2]/form/input[7]")).click();
		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("document", "value", "Ok");
			String xpathExpression = "//input[@value='" + new_value + "']";
			driver.findElement(By.xpath(xpathExpression)).click();

		}

		try {

			Assert.assertTrue(driver.findElement(By.cssSelector("BODY")).getText()
					.matches("^[\\s\\S]*" + "This is slate." + "[\\s\\S]*$"));
		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("document", "id", "claroBody");
			String xpathExpression = "//*[@id='" + idValue + "']";
			AssertJUnit.assertEquals(driver.findElement(By.xpath(xpathExpression)).getText(), "This is slate.");

		}
		try {
			driver.findElement(By.xpath("//*[@id=\"courseRightContent\"]/table/tbody/tr[1]/td[5]/a/img")).click();
		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("document", "alt", "Delete");
			String xpathExpression = "//img[@alt='" + new_value + "']";
			driver.findElement(By.xpath(xpathExpression)).click();

		}
		Alert alert = driver.switchTo().alert();
		alert.accept();
		try {

			Assert.assertTrue(driver.findElement(By.cssSelector("BODY")).getText()
					.matches("^[\\s\\S]*" + "Document deleted" + "[\\s\\S]*$"));
		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("document", "id", "claroBody");
			String xpathExpression = "//*[@id='" + idValue + "']";
			AssertJUnit.assertEquals(driver.findElement(By.xpath(xpathExpression)).getText(), "Document deleted");

		}
		// Directory
		try {

			driver.findElement(By.xpath("//*[@id=\"courseRightContent\"]/div[1]/table/tbody/tr/td[2]/ul/li[5]/a")).click();
		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("document", "text", "Create Directory");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();

		}

		try {

			driver.findElement(By.xpath("//*[@id=\"newName\"]")).sendKeys("3D Objects");
		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("document", "id", "newName");
			String xpathExpression = "//*[@id='" + new_value + "']";
			driver.findElement(By.xpath(xpathExpression)).sendKeys("3D Objects");

		}
		try {

			driver.findElement(By.xpath("//*[@id=\"comment\"]")).sendKeys("This is my new directory.");
		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("document", "id", "comment");
			String xpathExpression = "//*[@id='" + new_value + "']";
			driver.findElement(By.xpath(xpathExpression)).sendKeys("This is my new directory.");

		}
		try {
			driver.findElement(By.xpath("//*[@id=\"courseRightContent\"]/div[2]/div[2]/form/input[6]")).click();
		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("document", "value", "Ok");
			String xpathExpression = "//input[@value='" + new_value + "']";
			driver.findElement(By.xpath(xpathExpression)).click();

		}

		try {

			Assert.assertTrue(driver.findElement(By.cssSelector("BODY")).getText()
					.matches("^[\\s\\S]*" + "Directory created" + "[\\s\\S]*$"));
		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("document", "id", "claroBody");
			String xpathExpression = "//*[@id='" + idValue + "']";
			AssertJUnit.assertEquals(driver.findElement(By.xpath(xpathExpression)).getText(), "Directory created");

		}
		// Document
		try {

			driver.findElement(By.xpath("//*[@id=\"courseRightContent\"]/div/table/tbody/tr/td[2]/ul/li[7]/a"))
					.click();
		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("document", "text", "Create Document");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();

		}

		try {

			driver.findElement(By.xpath("//*[@id=\"courseRightContent\"]/form/p[1]/input")).sendKeys("NewDocument");
		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("document", "name", "fileName");
			String xpathExpression = "//*[@name='" + new_value + "']";
			driver.findElement(By.xpath(xpathExpression)).sendKeys("NewDocument");

		}
		
		try {

			WebElement ele = driver.findElement(By.xpath("//*[@id=\"courseRightContent\"]/form/p[3]/input"));
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", ele);

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("document", "value", "Ok");
			String xpathExpression = "//input[@value='" + new_value + "']";
			WebElement ele = driver.findElement(By.xpath(xpathExpression));
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", ele);

		}
		try {

			Assert.assertTrue(driver.findElement(By.cssSelector("BODY")).getText()
					.matches("^[\\s\\S]*" + "File created" + "[\\s\\S]*$"));
		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("document", "id", "claroBody");
			String xpathExpression = "//*[@id='" + idValue + "']";
			AssertJUnit.assertEquals(driver.findElement(By.xpath(xpathExpression)).getText(), "File created");

		}
		// search
		try {

			driver.findElement(By.xpath("//*[@id=\"courseRightContent\"]/div[1]/table/tbody/tr/td[2]/ul/li[2]/a")).click();
		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("document", "text", "Search");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();

		}

		try {

			driver.findElement(By.xpath("//*[@id=\"searchPattern\"]")).sendKeys("Hello");
		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("document", "id", "searchPattern");
			String xpathExpression = "//*[@id='" + new_value + "']";
			driver.findElement(By.xpath(xpathExpression)).sendKeys("Hello");

		}
		try {
			driver.findElement(By.xpath("//*[@id=\"courseRightContent\"]/div[2]/div/form/input[6]")).click();
		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("document", "value", "Search");
			String xpathExpression = "//input[@value='" + new_value + "']";
			driver.findElement(By.xpath(xpathExpression)).click();

		}

		try {

			Assert.assertTrue(driver.findElement(By.cssSelector("BODY")).getText()
					.matches("^[\\s\\S]*" + "Nothing to display" + "[\\s\\S]*$"));
		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("document", "id", "claroBody");
			String xpathExpression = "//*[@id='" + idValue + "']";
			AssertJUnit.assertEquals(driver.findElement(By.xpath(xpathExpression)).getText(), "Nothing to display");

		}
		// logout

		try {
			driver.findElements(By.xpath("//*[@id=\"userBannerRight\"]/ul/li[3]/span/a")).get(0).click(); // click on
																											// logout

		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("document", "id", "userBannerRight");
			String xpathExpression = "//*[@id='" + idValue + "']";
			driver.findElements(By.xpath(xpathExpression)).get(0).click();
		}

	}

	@Test(priority = 6, groups = "regression")
	public void exercise__1() // testing Platform administration --> Course list --> Course title -->
								// Exercises
	{
		currrent_test="exercise__1";
		// logIn
		try {

			driver.findElement(By.id("login")).clear();

		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("authentication", "id", "login");
			String xpathExpression = "//*[@id='" + idValue + "']";
			driver.findElement(By.xpath(xpathExpression)).clear();
		}

		try {

			driver.findElement(By.name("login")).sendKeys("admin");

		} catch (NoSuchElementException e) {
			String nameValue = repairerObj.repair("authentication", "name", "login");
			String xpathExpression = "//*[@name='" + nameValue + "']";
			driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
		}

		try {

			driver.findElement(By.id("password")).clear();

		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("authentication", "id", "password");
			String xpathExpression = "//*[@id='" + idValue + "']";
			driver.findElement(By.xpath(xpathExpression)).clear();
		}

		try {

			driver.findElement(By.name("password")).sendKeys("admin");

		} catch (NoSuchElementException e) {
			String nameValue = repairerObj.repair("authentication", "name", "password");
			String xpathExpression = "//*[@name='" + nameValue + "']";
			driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
		}

		try {

			driver.findElement(By.xpath("//*[@id=\"loginBox\"]/form/fieldset/button")).click();

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("authentication", "text", "Enter");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();
		}

		try {

			driver.findElement(By.xpath("//*[@id=\"userBannerLeft\"]/ul/li[3]/span/a")).click();

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("admin", "text", "Platform administration");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();
		}

		try {

			driver.findElement(By.xpath("//*[@id=\"claroBody\"]/ul/li[2]/ul/li[2]/a")).click(); // click on Course list
			flag = 1;																			// button in Courses

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("admin", "text", "Course list");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();
			flag = 2;
		}

		try {

			driver.findElement(By.xpath("//*[@id=\"claroBody\"]/table[2]/tbody/tr/td[2]/a")).click(); // click on Course
																										// Title(e.g
																										// CNET)
		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("admin_courses", "text", "DATA STRUCTURE");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();

		}

		try {

			driver.findElement(By.id("CLQWZ")).click();
		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("exercise", "id", "CLQWZ");
			String xpathExpression = "//*[@id='" + new_value + "']";
			driver.findElement(By.xpath(xpathExpression)).click();

		}

		// New Exercise
		try {

			driver.findElement(By.xpath("//*[@id=\"courseRightContent\"]/div[1]/table/tbody/tr/td[2]/ul/li[2]/a"))
					.click();
		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("exercise", "text", "New exercise");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();

		}

		try {

			driver.findElement(By.xpath("//*[@id=\"title\"]")).sendKeys("Exercise No.1");
		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("exercise", "id", "title");
			String xpathExpression = "//*[@id='" + new_value + "']";
			driver.findElement(By.xpath(xpathExpression)).sendKeys("Exercise No.1");

		}
		
		try {

			WebElement ele = driver.findElement(By.xpath("//*[@id=\"courseRightContent\"]/form/div[2]/input"));
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", ele);

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("exercise", "value", "Ok");
			String xpathExpression = "//input[@value='" + new_value + "']";
			WebElement ele = driver.findElement(By.xpath(xpathExpression));
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", ele);

		}
		try {

			Assert.assertTrue(driver.findElement(By.cssSelector("BODY")).getText()
					.matches("^[\\s\\S]*" + "Exercise added" + "[\\s\\S]*$"));
		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("exercise", "id", "claroBody");
			String xpathExpression = "//*[@id='" + idValue + "']";
			AssertJUnit.assertEquals(driver.findElement(By.xpath(xpathExpression)).getText(), "Exercise added");

		}
		try {
			driver.findElement(By.xpath("//*[@id=\"courseRightContent\"]/div[1]/table/tbody/tr/td[2]/ul/li[1]/a"))
					.click();
		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("exercise", "text", "Back to the exercise list");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();

		}
		// Import exercise
		try {
			driver.findElement(By.xpath("//*[@id=\"courseRightContent\"]/div[1]/table/tbody/tr/td[2]/ul/li[6]/a"))
					.click();
		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("exercise", "text", "Import exercise");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();

		}
		try {
			driver.findElement(By.xpath("//*[@id=\"courseRightContent\"]/div[2]/div/form/p/input")).click();
		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("exercise", "value", "Import exercise");
			String xpathExpression = "//input[@value='" + new_value + "']";
			driver.findElement(By.xpath(xpathExpression)).click();

		}
		try {

			Assert.assertTrue(driver.findElement(By.cssSelector("BODY")).getText()
					.matches("^[\\s\\S]*" + "Import failed" + "[\\s\\S]*$"));
		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("exercise", "id", "claroBody");
			String xpathExpression = "//*[@id='" + idValue + "']";
			AssertJUnit.assertEquals(driver.findElement(By.xpath(xpathExpression)).getText(), "Import failed");

		}
		try {

			driver.findElement(By.id("CLQWZ")).click();
		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("exercise", "id", "CLQWZ");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();

		}
		// Question Pool
		try {
			driver.findElement(By.xpath("//*[@id=\"courseRightContent\"]/div[1]/table/tbody/tr/td[2]/ul/li[4]/a"))
					.click();
		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("exercise", "text", "Question pool");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();

		}
		try {
			driver.findElement(By.xpath("//*[@id=\"courseRightContent\"]/div[1]/table/tbody/tr/td[2]/ul/li/a")).click();
		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("question_pool", "text", "New question");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();

		}

		try {

			driver.findElement(By.xpath("//*[@id=\"title\"]"))
					.sendKeys("Do you think living in New York City has become expensive?");
		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("edit_question", "id", "title");
			String xpathExpression = "//*[@id='" + new_value + "']";
			driver.findElement(By.xpath(xpathExpression))
					.sendKeys("Do you think living in New York City has become expensive?");

		}
		
		try {

			WebElement ele = driver.findElement(By.xpath("//*[@id=\"TF\"]"));
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", ele);

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("edit_question", "id", "TF");
			String xpathExpression = "//*[@id='" + new_value + "']";
			WebElement ele = driver.findElement(By.xpath(xpathExpression));
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", ele);

		}
		
		try {

			WebElement ele = driver.findElement(By.xpath("//*[@id=\"courseRightContent\"]/form/div[2]/input"));
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", ele);

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("edit_question", "value", "Ok");
			String xpathExpression = "//input[@value='" + new_value + "']";
			WebElement ele = driver.findElement(By.xpath(xpathExpression));
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", ele);

		}
		
		try {

			WebElement ele = driver.findElement(By.xpath("//*[@id=\"trueCorrect\"]"));
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", ele);

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("edit_answers", "id", "trueCorrect");
			String xpathExpression = "//input[@id='" + new_value + "']";
			WebElement ele = driver.findElement(By.xpath(xpathExpression));
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", ele);

		}
		try {

			driver.findElement(By.xpath("//*[@id=\"courseRightContent\"]/form/table/tbody/tr[1]/td[4]/input"))
					.sendKeys("1");
		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("edit_answers", "name", "trueGrade");
			String xpathExpression = "//*[@name='" + new_value + "']";
			driver.findElement(By.xpath(xpathExpression)).sendKeys("1");

		}
		
		
		try {

			WebElement ele = driver.findElement(By.xpath("//*[@id=\"courseRightContent\"]/form/table/tbody/tr[3]/td/input"));
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", ele);

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("edit_answers", "name", "cmdOk");
			String xpathExpression = "//input[@name='" + new_value + "']";
			WebElement ele = driver.findElement(By.xpath(xpathExpression));
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", ele);

		}
		try {

			Assert.assertTrue(driver.findElement(By.cssSelector("BODY")).getText().matches(
					"^[\\s\\S]*" + "Do you think living in New York City has become expensive?" + "[\\s\\S]*$"));
		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("edit_question", "id", "claroBody");
			String xpathExpression = "//*[@id='" + idValue + "']";
			AssertJUnit.assertEquals(driver.findElement(By.xpath(xpathExpression)).getText(),
					"Do you think living in New York City has become expensive?");

		}
		try {

			driver.findElement(By.id("CLQWZ")).click();
		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("edit_question", "id", "CLQWZ");
			String xpathExpression = "//*[@id='" + new_value + "']";
			driver.findElement(By.xpath(xpathExpression)).click();

		}
		// Question categories
		try {
			driver.findElement(By.xpath("//*[@id=\"courseRightContent\"]/div[1]/table/tbody/tr/td[2]/ul/li[5]/a"))
					.click();
		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("exercise", "text", "Question categories");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();

		}
		try {
			driver.findElement(By.xpath("//*[@id=\"courseRightContent\"]/div[1]/table/tbody/tr/td[2]/ul/li/a")).click();
		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("question_category", "text", "New category");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();

		}

		try {

			driver.findElement(By.xpath("//*[@id=\"title\"]")).sendKeys("Cat1");

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("question_category", "id", "title");
			String xpathExpression = "//*[@id='" + new_value + "']";
			driver.findElement(By.xpath(xpathExpression)).sendKeys("Cat1");

		}
		
		try {

			WebElement ele = driver.findElement(By.xpath("//*[@id=\"courseRightContent\"]/form/table/tbody/tr[4]/td[2]/input"));
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", ele);

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("question_category", "value", "Ok");
			String xpathExpression = "//input[@value='" + new_value + "']";
			WebElement ele = driver.findElement(By.xpath(xpathExpression));
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", ele);

		}
		try {

			Assert.assertTrue(driver.findElement(By.cssSelector("BODY")).getText()
					.matches("^[\\s\\S]*" + "Category created" + "[\\s\\S]*$"));
		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("question_category", "id", "claroBody");
			String xpathExpression = "//*[@id='" + idValue + "']";
			AssertJUnit.assertEquals(driver.findElement(By.xpath(xpathExpression)).getText(), "Category created");

		}

		try {
			driver.findElement(By.xpath("//*[@id=\"courseRightContent\"]/table/tbody/tr/td[3]/a/img")).click();
		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("question_category", "alt", "Delete");
			String xpathExpression = "//img[@alt='" + new_value + "']";
			driver.findElement(By.xpath(xpathExpression)).click();

		}
		Alert alert = driver.switchTo().alert();
		alert.accept();
		try {

			Assert.assertTrue(driver.findElement(By.cssSelector("BODY")).getText()
					.matches("^[\\s\\S]*" + "Category deleted" + "[\\s\\S]*$"));
		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("question_category", "id", "claroBody");
			String xpathExpression = "//*[@id='" + idValue + "']";
			AssertJUnit.assertEquals(driver.findElement(By.xpath(xpathExpression)).getText(), "Category deleted");

		}
		try {

			driver.findElement(By.id("CLQWZ")).click();
		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("edit_question", "id", "CLQWZ");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();

		}

		// My results
		try {
			driver.findElement(By.xpath("//*[@id=\"courseRightContent\"]/div[1]/table/tbody/tr/td[2]/ul/li[3]/a"))
					.click();
		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("exercise", "text", "My results");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();

		}
		try {
			driver.findElement(By.xpath("//*[@id=\"leftContent\"]/div[1]/table/tbody/tr/td[2]/ul/li/a")).click();
		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("userReport", "text", "View platform statistics");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();

		}
		try {

			Assert.assertTrue(driver.findElement(By.cssSelector("BODY")).getText()
					.matches("^[\\s\\S]*" + "Month" + "[\\s\\S]*$"));
		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("userReport", "id", "claroBody");
			String xpathExpression = "//*[@id='" + idValue + "']";
			AssertJUnit.assertEquals(driver.findElement(By.xpath(xpathExpression)).getText(), "Month");

		}
		// logout

		try {
			driver.findElements(By.xpath("//*[@id=\"userBannerRight\"]/ul/li[3]/span/a")).get(0).click(); // click on
																											// logout

		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("exercise", "id", "userBannerRight");
			String xpathExpression = "//*[@id='" + idValue + "']";
			driver.findElements(By.xpath(xpathExpression)).get(0).click();
		}

	}

	@Test(priority = 7, groups = "regression")
	public void learning_Path_List__1() // testing Platform administration --> Course list --> Course title --> Learning
										// Path
	{
		currrent_test="learning_Path_List__1";
		// logIn
		try {

			driver.findElement(By.id("login")).clear();

		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("authentication", "id", "login");
			String xpathExpression = "//*[@id='" + idValue + "']";
			driver.findElement(By.xpath(xpathExpression)).clear();
		}

		try {

			driver.findElement(By.name("login")).sendKeys("admin");

		} catch (NoSuchElementException e) {
			String nameValue = repairerObj.repair("authentication", "name", "login");
			String xpathExpression = "//*[@name='" + nameValue + "']";
			driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
		}

		try {

			driver.findElement(By.id("password")).clear();

		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("authentication", "id", "password");
			String xpathExpression = "//*[@id='" + idValue + "']";
			driver.findElement(By.xpath(xpathExpression)).clear();
		}

		try {

			driver.findElement(By.name("password")).sendKeys("admin");

		} catch (NoSuchElementException e) {
			String nameValue = repairerObj.repair("authentication", "name", "password");
			String xpathExpression = "//*[@name='" + nameValue + "']";
			driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
		}

		try {

			driver.findElement(By.xpath("//*[@id=\"loginBox\"]/form/fieldset/button")).click();

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("authentication", "text", "Enter");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();
		}

		try {

			driver.findElement(By.xpath("//*[@id=\"userBannerLeft\"]/ul/li[3]/span/a")).click();

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("admin", "text", "Platform administration");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();
		}

		try {

			driver.findElement(By.xpath("//*[@id=\"claroBody\"]/ul/li[2]/ul/li[2]/a")).click(); // click on Course list
			flag = 1;																			// button in Courses

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("admin", "text", "Course list");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();
			flag = 2;
		}

		try {

			driver.findElement(By.xpath("//*[@id=\"claroBody\"]/table[2]/tbody/tr/td[2]/a")).click(); // click on Course
																										// Title(e.g
																										// CNET)
		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("admin_courses", "text", "DATA STRUCTURE");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();

		}

		try {

			driver.findElement(By.id("CLLNP")).click();
		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("exercise", "id", "CLLNP");
			String xpathExpression = "//*[@id='" + new_value + "']";
			driver.findElement(By.xpath(xpathExpression)).click();

		}

		// Create a new learning path
		
		try {

			driver.findElement(By.xpath("//*[@id=\"courseRightContent\"]/div/table/tbody/tr/td[2]/ul/li[1]/a")).click();
		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("learningPathList", "text", "Create a new learning path");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();

		}
		try {

			driver.findElement(By.xpath("//*[@id=\"newPathName\"]")).sendKeys("HTML to React");
		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("learningPathList", "id", "newPathName");
			String xpathExpression = "//*[@id='" + new_value + "']";
			driver.findElement(By.xpath(xpathExpression)).sendKeys("HTML to React");

		}
		
		try {

			WebElement ele = driver.findElement(By.xpath("//*[@id=\"courseRightContent\"]/div[2]/div/form/input[2]"));
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", ele);

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("learningPathList", "value", "Ok");
			String xpathExpression = "//input[@value='" + new_value + "']";
			WebElement ele = driver.findElement(By.xpath(xpathExpression));
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", ele);

		}
		try {

			Assert.assertTrue(driver.findElement(By.cssSelector("BODY")).getText()
					.matches("^[\\s\\S]*" + "HTML to React" + "[\\s\\S]*$"));
		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("userReport", "id", "claroBody");
			String xpathExpression = "//*[@id='" + idValue + "']";
			AssertJUnit.assertEquals(driver.findElement(By.xpath(xpathExpression)).getText(), "HTML to React");

		}
		// Import a learning path
		try {

			driver.findElement(By.xpath("//*[@id=\"courseRightContent\"]/div[1]/table/tbody/tr/td[2]/ul/li[2]/a")).click();
		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("learningPathList", "text", "Import a learning path");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();

		}
		try {

			driver.findElement(By.xpath("//*[@id=\"courseRightContent\"]/form/p/input")).click();
		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("importLearningPath", "value", "Import");
			String xpathExpression = "//input[@value='" + new_value + "']";
			driver.findElement(By.xpath(xpathExpression)).click();

		}
		
		try {

			Assert.assertTrue(driver.findElement(By.cssSelector("BODY")).getText()
					.matches("^[\\s\\S]*" + "An error occurred. Learning Path import failed." + "[\\s\\S]*$"));
		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("userReport", "id", "claroBody");
			String xpathExpression = "//*[@id='" + idValue + "']";
			AssertJUnit.assertEquals(driver.findElement(By.xpath(xpathExpression)).getText(), "An error occurred. Learning Path import failed.");

		}
		
		try {

			driver.findElement(By.xpath("//*[@id=\"courseRightContent\"]/a")).click();
		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("importLearningPath", "value", "<< Back");
			String xpathExpression = "//input[@value='" + new_value + "']";
			driver.findElement(By.xpath(xpathExpression)).click();

		}
		// Pool of modules
		try {

			driver.findElement(By.xpath("//*[@id=\"courseRightContent\"]/div/table/tbody/tr/td[2]/ul/li[3]/a")).click();
		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("learningPathList", "text", "Pool of modules");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();

		}
		try {

			Assert.assertTrue(driver.findElement(By.cssSelector("BODY")).getText()
					.matches("^[\\s\\S]*" + "Sample exercise" + "[\\s\\S]*$"));
		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("learningPathList", "id", "claroBody");
			String xpathExpression = "//*[@id='" + idValue + "']";
			AssertJUnit.assertEquals(driver.findElement(By.xpath(xpathExpression)).getText(), "Sample exercise");

		}
		try {

			driver.findElement(By.id("CLLNP")).click();
		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("learningPathList", "id", "CLLNP");
			String xpathExpression = "//*[@id='" + new_value + "']";
			driver.findElement(By.xpath(xpathExpression)).click();

		}

		// User tracking
		try {

			driver.findElement(By.xpath("//*[@id=\"courseRightContent\"]/div/table/tbody/tr/td[2]/ul/li[4]/a")).click();
		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("learningPathList", "text", "User tracking");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();

		}
		try {

			Assert.assertTrue(driver.findElement(By.cssSelector("BODY")).getText()
					.matches("^[\\s\\S]*" + "0%" + "[\\s\\S]*$"));
		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("learningPathList", "id", "claroBody");
			String xpathExpression = "//*[@id='" + idValue + "']";
			AssertJUnit.assertEquals(driver.findElement(By.xpath(xpathExpression)).getText(), "0%");

		}
		// logout
		try {
			driver.findElements(By.xpath("//*[@id=\"userBannerRight\"]/ul/li[3]/span/a")).get(0).click(); // click on
																											// logout

		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("learningPathList", "id", "userBannerRight");
			String xpathExpression = "//*[@id='" + idValue + "']";
			driver.findElements(By.xpath(xpathExpression)).get(0).click();
		}

	}

	@Test(priority = 8, groups = "regression")
	public void work__1() // testing Platform administration --> Course list --> Course title --> Document
	{
		currrent_test="work__1";
		// logIn
		try {

			driver.findElement(By.id("login")).clear();

		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("authentication", "id", "login");
			String xpathExpression = "//*[@id='" + idValue + "']";
			driver.findElement(By.xpath(xpathExpression)).clear();
		}

		try {

			driver.findElement(By.name("login")).sendKeys("admin");

		} catch (NoSuchElementException e) {
			String nameValue = repairerObj.repair("authentication", "name", "login");
			String xpathExpression = "//*[@name='" + nameValue + "']";
			driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
		}

		try {

			driver.findElement(By.id("password")).clear();

		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("authentication", "id", "password");
			String xpathExpression = "//*[@id='" + idValue + "']";
			driver.findElement(By.xpath(xpathExpression)).clear();
		}

		try {

			driver.findElement(By.name("password")).sendKeys("admin");

		} catch (NoSuchElementException e) {
			String nameValue = repairerObj.repair("authentication", "name", "password");
			String xpathExpression = "//*[@name='" + nameValue + "']";
			driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
		}

		try {

			driver.findElement(By.xpath("//*[@id=\"loginBox\"]/form/fieldset/button")).click();

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("authentication", "text", "Enter");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();
		}

		try {

			driver.findElement(By.xpath("//*[@id=\"userBannerLeft\"]/ul/li[3]/span/a")).click();

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("admin", "text", "Platform administration");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();
		}

		try {

			driver.findElement(By.xpath("//*[@id=\"claroBody\"]/ul/li[2]/ul/li[2]/a")).click(); // click on Course list
			flag = 1;																				// button in Courses

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("admin", "text", "Course list");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();
			flag = 2;
		}

		try {

			driver.findElement(By.xpath("//*[@id=\"claroBody\"]/table[2]/tbody/tr/td[2]/a")).click(); // click on Course
																										// Title(e.g
																										// CNET)
		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("admin_courses", "text", "DATA STRUCTURE");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();

		}

		try {

			driver.findElement(By.id("CLWRK")).click();
		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("work", "id", "CLWRK");
			String xpathExpression = "//*[@id='" + new_value + "']";
			driver.findElement(By.xpath(xpathExpression)).click();

		}
		// Assignment Creation and Deletion

		
		try {

			driver.findElement(By.xpath("//*[@id=\"courseRightContent\"]/div[1]/table/tbody/tr/td[2]/ul/li[2]/a")).click();
		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("work", "text", "Create a new assignment");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();

		}
		try {

			driver.findElement(By.xpath("//*[@id=\"title\"]")).sendKeys("CNET Assignment.1");
		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("work", "id", "title");
			String xpathExpression = "//*[@id='" + new_value + "']";
			driver.findElement(By.xpath(xpathExpression)).sendKeys("CNET Assignment.1");

		}
	
		try {
			
			WebElement ele = driver.findElement(By.xpath("//*[@id=\"courseRightContent\"]/form/fieldset/dl/dd[9]/input"));
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", ele);

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("work", "value", "Ok");
			String xpathExpression = "//input[@value='" + new_value + "']";
			WebElement ele = driver.findElement(By.xpath(xpathExpression));
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", ele);

		}
		try {

			Assert.assertTrue(driver.findElement(By.cssSelector("BODY")).getText()
					.matches("^[\\s\\S]*" + "New assignment created" + "[\\s\\S]*$"));
		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("work", "id", "claroBody");
			String xpathExpression = "//*[@id='" + idValue + "']";
			AssertJUnit.assertEquals(driver.findElement(By.xpath(xpathExpression)).getText(), "New assignment created");

		}
		try {

			driver.findElement(By.xpath("//*[@id=\"courseRightContent\"]/table/tbody[2]/tr/td[6]/a/img")).click();
		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("work", "alt", "Delete");
			String xpathExpression = "//img[@alt='" + new_value + "']";
			driver.findElement(By.xpath(xpathExpression)).click();

		}
		Alert alert = driver.switchTo().alert();
		alert.accept();
		try {

			Assert.assertTrue(driver.findElement(By.cssSelector("BODY")).getText()
					.matches("^[\\s\\S]*" + "Assignment deleted" + "[\\s\\S]*$"));
		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("work", "id", "claroBody");
			String xpathExpression = "//*[@id='" + idValue + "']";
			AssertJUnit.assertEquals(driver.findElement(By.xpath(xpathExpression)).getText(), "Assignment deleted");

		}
		// Download Submissions
		try {

			driver.findElement(By.xpath("//*[@id=\"courseRightContent\"]/div[1]/table/tbody/tr/td[2]/ul/li[3]/a")).click();
		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("work", "text", "Download submissions");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();

		}
		
try {
			
			WebElement ele = driver.findElement(By.xpath("//*[@id=\"courseRightContent\"]/div[2]/div[2]/form/input[8]"));

			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", ele);

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("work", "value", "Ok");
			String xpathExpression = "//input[@value='" + new_value + "']";
			WebElement ele = driver.findElement(By.xpath(xpathExpression));
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", ele);

		}
			try {

			Assert.assertTrue(driver.findElement(By.cssSelector("BODY")).getText()
					.matches("^[\\s\\S]*" + "There is no submission available for download with these settings." + "[\\s\\S]*$"));
		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("work", "id", "claroBody");
			String xpathExpression = "//*[@id='" + idValue + "']";
			AssertJUnit.assertEquals(driver.findElement(By.xpath(xpathExpression)).getText(), "There is no submission available for download with these settings.");

		}
		// logout
			try {
				driver.findElements(By.xpath("//*[@id=\"userBannerRight\"]/ul/li[3]/span/a")).get(0).click(); // click on
																												// logout

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("work", "id", "userBannerRight");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElements(By.xpath(xpathExpression)).get(0).click();
			}
	}

	@Test(priority = 9, groups = "regression")
	public void forms_1() // testing Platform administration --> Course list --> Course title--> Forums
	{
		currrent_test="forms_1";
		// logIn
		try {

			driver.findElement(By.id("login")).clear();

		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("authentication", "id", "login");
			String xpathExpression = "//*[@id='" + idValue + "']";
			driver.findElement(By.xpath(xpathExpression)).clear();
		}

		try {

			driver.findElement(By.name("login")).sendKeys("admin");

		} catch (NoSuchElementException e) {
			String nameValue = repairerObj.repair("authentication", "name", "login");
			String xpathExpression = "//*[@name='" + nameValue + "']";
			driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
		}

		try {

			driver.findElement(By.id("password")).clear();

		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("authentication", "id", "password");
			String xpathExpression = "//*[@id='" + idValue + "']";
			driver.findElement(By.xpath(xpathExpression)).clear();
		}

		try {

			driver.findElement(By.name("password")).sendKeys("admin");

		} catch (NoSuchElementException e) {
			String nameValue = repairerObj.repair("authentication", "name", "password");
			String xpathExpression = "//*[@name='" + nameValue + "']";
			driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
		}

		try {

			driver.findElement(By.xpath("//*[@id=\"loginBox\"]/form/fieldset/button")).click();

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("authentication", "text", "Enter");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();
		}

		try {

			driver.findElement(By.xpath("//*[@id=\"userBannerLeft\"]/ul/li[3]/span/a")).click();

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("admin", "text", "Platform administration");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();
		}

		try {

			driver.findElement(By.xpath("//*[@id=\"claroBody\"]/ul/li[2]/ul/li[2]/a")).click(); // click on Course list
			flag = 1;																					// button in Courses

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("admin", "text", "Course list");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();
			flag = 2;
		}

		try {

			driver.findElement(By.xpath("//*[@id=\"claroBody\"]/table[2]/tbody/tr/td[2]/a")).click(); // click on Course
																										// Title(e.g
																										// CNET)
		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("admin_courses", "text", "DATA STRUCTURE");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();

		}

		try {

			driver.findElement(By.id("CLFRM")).click();
		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("forms", "id", "CLFRM");
			String xpathExpression = "//*[@id='" + new_value + "']";
			driver.findElement(By.xpath(xpathExpression)).click();

		}

		// Create Category
		try {

			driver.findElement(By.xpath("//*[@id=\"courseRightContent\"]/div/table/tbody/tr/td[2]/ul/li[2]/a")).click();
		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("forms", "text", "Create category");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();

		}
		try {

			driver.findElement(By.xpath("//*[@id=\"catName\"]")).sendKeys("Category 2");
		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("forms", "id", "catName");
			String xpathExpression = "//*[@id='" + new_value + "']";
			driver.findElement(By.xpath(xpathExpression)).sendKeys("Category 2");

		}
		
		try {

			WebElement ele = driver.findElement(By.xpath("//*[@id=\"courseRightContent\"]/div[2]/div/form/input[5]"));
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", ele);

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("forms", "value", "Ok");
			String xpathExpression = "//input[@value='" + new_value + "']";
			WebElement ele = driver.findElement(By.xpath(xpathExpression));
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", ele);

		}
	
		try {

			Assert.assertTrue(driver.findElement(By.cssSelector("BODY")).getText()
					.matches("^[\\s\\S]*" + "The new category has been created." + "[\\s\\S]*$"));
		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("work", "id", "claroBody");
			String xpathExpression = "//*[@id='" + idValue + "']";
			AssertJUnit.assertEquals(driver.findElement(By.xpath(xpathExpression)).getText(), "The new category has been created.");

		}
		// Create forum
		try {

			driver.findElement(By.xpath("//*[@id=\"courseRightContent\"]/div[1]/table/tbody/tr/td[2]/ul/li[3]/a")).click();
		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("forms", "text", "Create forum");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();

		}
		try {

			driver.findElement(By.xpath("//*[@id=\"forumName\"]")).sendKeys("Forum 2");
		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("forms", "id", "forumName");
			String xpathExpression = "//*[@id='" + new_value + "']";
			driver.findElement(By.xpath(xpathExpression)).sendKeys("Forum 2");

		}
		try {

			driver.findElement(By.xpath("//*[@id=\"forumDesc\"]")).sendKeys("This is my forum 2.");
		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("forms", "id", "forumDesc");
			String xpathExpression = "//*[@id='" + new_value + "']";
			driver.findElement(By.xpath(xpathExpression)).sendKeys("This is my forum 2.");

		}
		
		try {

			WebElement ele = driver.findElement(By.xpath("//*[@id=\"courseRightContent\"]/div[2]/div/form/input[11]"));
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", ele);

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("forms", "value", "Ok");
			String xpathExpression = "//input[@value='" + new_value + "']";
			WebElement ele = driver.findElement(By.xpath(xpathExpression));
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", ele);

		}
		try {

			Assert.assertTrue(driver.findElement(By.cssSelector("BODY")).getText()
					.matches("^[\\s\\S]*" + "Forum created." + "[\\s\\S]*$"));
		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("forms", "id", "claroBody");
			String xpathExpression = "//*[@id='" + idValue + "']";
			AssertJUnit.assertEquals(driver.findElement(By.xpath(xpathExpression)).getText(), "Forum created.");

		}
		// Search
		try {

			driver.findElement(By.xpath("//*[@id=\"courseRightContent\"]/div[1]/table/tbody/tr/td[2]/ul/li[4]/a")).click();
		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("forms", "text", "Search");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();

		}
		try {

			driver.findElement(By.xpath("//*[@id=\"courseRightContent\"]/div[2]/div/form/input[3]")).sendKeys("Forum 2");
		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("forms", "name", "searchPattern");
			String xpathExpression = "//*[@name='" + new_value + "']";
			driver.findElement(By.xpath(xpathExpression)).sendKeys("Forum 2");

		}
	
		try {

			WebElement ele = driver.findElement(By.xpath("//*[@id=\"courseRightContent\"]/div[2]/div/form/input[4]"));
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", ele);

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("forms", "value", "Ok");
			String xpathExpression = "//input[@value='" + new_value + "']";
			WebElement ele = driver.findElement(By.xpath(xpathExpression));
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", ele);

		}
		try {

			Assert.assertTrue(driver.findElement(By.cssSelector("BODY")).getText()
					.matches("^[\\s\\S]*" + "Search result : Forum 2" + "[\\s\\S]*$"));
		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("forms", "id", "claroBody");
			String xpathExpression = "//*[@id='" + idValue + "']";
			AssertJUnit.assertEquals(driver.findElement(By.xpath(xpathExpression)).getText(), "Search result : Forum 2");

		}
		// logout
		try {
			driver.findElements(By.xpath("//*[@id=\"userBannerRight\"]/ul/li[3]/span/a")).get(0).click(); // click on
																											// logout

		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("forms", "id", "userBannerRight");
			String xpathExpression = "//*[@id='" + idValue + "']";
			driver.findElements(By.xpath(xpathExpression)).get(0).click();
		}
	}

	@Test(priority = 10, groups = "regression")
	public void group_1() // testing Platform administration --> Course list --> Course title--> Groups
	{
		currrent_test="group_1";
		// logIn
		try {

			driver.findElement(By.id("login")).clear();

		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("authentication", "id", "login");
			String xpathExpression = "//*[@id='" + idValue + "']";
			driver.findElement(By.xpath(xpathExpression)).clear();
		}

		try {

			driver.findElement(By.name("login")).sendKeys("admin");

		} catch (NoSuchElementException e) {
			String nameValue = repairerObj.repair("authentication", "name", "login");
			String xpathExpression = "//*[@name='" + nameValue + "']";
			driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
		}

		try {

			driver.findElement(By.id("password")).clear();

		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("authentication", "id", "password");
			String xpathExpression = "//*[@id='" + idValue + "']";
			driver.findElement(By.xpath(xpathExpression)).clear();
		}

		try {

			driver.findElement(By.name("password")).sendKeys("admin");

		} catch (NoSuchElementException e) {
			String nameValue = repairerObj.repair("authentication", "name", "password");
			String xpathExpression = "//*[@name='" + nameValue + "']";
			driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
		}

		try {

			driver.findElement(By.xpath("//*[@id=\"loginBox\"]/form/fieldset/button")).click();

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("authentication", "text", "Enter");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();
		}

		try {

			driver.findElement(By.xpath("//*[@id=\"userBannerLeft\"]/ul/li[3]/span/a")).click();

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("admin", "text", "Platform administration");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();
		}

		try {

			driver.findElement(By.xpath("//*[@id=\"claroBody\"]/ul/li[2]/ul/li[2]/a")).click(); // click on Course list
			flag = 1;																			// button in Courses

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("admin", "text", "Course list");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();
			flag = 2;
		}

		try {

			driver.findElement(By.xpath("//*[@id=\"claroBody\"]/table[2]/tbody/tr/td[2]/a")).click(); // click on Course
																										// Title(e.g
																										// CNET)
		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("admin_courses", "text", "DATA STRUCTURE");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();

		}

		try {

			driver.findElement(By.id("CLGRP")).click();
		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("forms", "id", "CLGRP");
			String xpathExpression = "//*[@id='" + new_value + "']";
			driver.findElement(By.xpath(xpathExpression)).click();

		}
		

		// Create new Group(s)
		try {

			driver.findElement(By.xpath("//*[@id=\"courseRightContent\"]/div[1]/table/tbody/tr/td[2]/ul/li[1]/a")).click();
		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("group", "text", "Create new group(s)");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();

		}
		try {

			driver.findElement(By.xpath("//*[@id=\"creation\"]")).click();
		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("group", "id", "creation");
			String xpathExpression = "//*[@id='" + new_value + "']";
			driver.findElement(By.xpath(xpathExpression)).click();

		}
		try {

			Assert.assertTrue(driver.findElement(By.cssSelector("BODY")).getText()
					.matches("^[\\s\\S]*" + "1 group\\(s\\) has \\(have\\) been added" + "[\\s\\S]*$"));
		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("group", "id", "claroBody");
			String xpathExpression = "//*[@id='" + idValue + "']";
			AssertJUnit.assertEquals(driver.findElement(By.xpath(xpathExpression)).getText(), "1 group\\(s\\) has \\(have\\) been added");

		}
		// Delete all groups
		try {

			driver.findElement(By.xpath("//*[@id=\"courseRightContent\"]/div[1]/table/tbody/tr/td[2]/ul/li[2]/a")).click();
		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("group", "text", "Delete all groups");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();

		}
		Alert alert = driver.switchTo().alert();
		alert.accept();
		try {

			Assert.assertTrue(driver.findElement(By.cssSelector("BODY")).getText()
					.matches("^[\\s\\S]*" + "Empty" + "[\\s\\S]*$"));
		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("group", "id", "claroBody");
			String xpathExpression = "//*[@id='" + idValue + "']";
			AssertJUnit.assertEquals(driver.findElement(By.xpath(xpathExpression)).getText(), "Empty");

		}
		// Main Group Settings
		
		try {

			driver.findElement(By.xpath("//*[@id=\"courseRightContent\"]/div[1]/table/tbody/tr/td[2]/ul/li[3]/a")).click();
		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("group", "text", "Main Group Settings");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();

		}
		
		try {

			WebElement ele = driver.findElement(By.xpath("//*[@id=\"courseRightContent\"]/form/table/tbody/tr[15]/td/input"));
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", ele);

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("group", "value", "Ok");
			String xpathExpression = "//input[@value='" + new_value + "']";
			WebElement ele = driver.findElement(By.xpath(xpathExpression));
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", ele);

		}

		try {

			Assert.assertTrue(driver.findElement(By.cssSelector("BODY")).getText()
					.matches("^[\\s\\S]*" + "Group settings have been modified" + "[\\s\\S]*$"));
		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("group", "id", "claroBody");
			String xpathExpression = "//*[@id='" + idValue + "']";
			AssertJUnit.assertEquals(driver.findElement(By.xpath(xpathExpression)).getText(), "Group settings have been modified");

		}
		// Fill groups (automatically)
		try {

			driver.findElement(By.xpath("//*[@id=\"courseRightContent\"]/div[1]/table/tbody/tr/td[2]/ul/li[4]/a")).click();
		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("group", "text", "Fill groups (automatically)");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();

		}
		
		try {

			Assert.assertTrue(driver.findElement(By.cssSelector("BODY")).getText()
					.matches("^[\\s\\S]*" + "Groups have been filled \\(or completed\\) by students present in the 'Users' list." + "[\\s\\S]*$"));
		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("group", "id", "claroBody");
			String xpathExpression = "//*[@id='" + idValue + "']";
			AssertJUnit.assertEquals(driver.findElement(By.xpath(xpathExpression)).getText(), "Groups have been filled \\(or completed\\) by students present in the 'Users' list.");

		}
		// Empty all groups
		try {

			driver.findElement(By.xpath("//*[@id=\"courseRightContent\"]/div[1]/table/tbody/tr/td[2]/ul/li[5]/a")).click();
		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("group", "text", "Empty all groups");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();

		}
		Alert alert1 = driver.switchTo().alert();
		alert1.accept();
	
		try {

			Assert.assertTrue(driver.findElement(By.cssSelector("BODY")).getText()
					.matches("^[\\s\\S]*" + "All groups are now empty" + "[\\s\\S]*$"));
		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("group", "id", "claroBody");
			String xpathExpression = "//*[@id='" + idValue + "']";
			AssertJUnit.assertEquals(driver.findElement(By.xpath(xpathExpression)).getText(), "All groups are now empty");

		}
		// logout
		try {
			driver.findElements(By.xpath("//*[@id=\"userBannerRight\"]/ul/li[3]/span/a")).get(0).click(); // click on
																											// logout

		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("group", "id", "userBannerRight");
			String xpathExpression = "//*[@id='" + idValue + "']";
			driver.findElements(By.xpath(xpathExpression)).get(0).click();
		}
	}

	@Test(priority = 11, groups = "regression")
	public void tools__1() // testing Platform administration --> Course list --> Course title --> Edit
							// Tool List
	{
		currrent_test="tools__1";
		// logIn
		try {

			driver.findElement(By.id("login")).clear();

		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("authentication", "id", "login");
			String xpathExpression = "//*[@id='" + idValue + "']";
			driver.findElement(By.xpath(xpathExpression)).clear();
		}

		try {

			driver.findElement(By.name("login")).sendKeys("admin");

		} catch (NoSuchElementException e) {
			String nameValue = repairerObj.repair("authentication", "name", "login");
			String xpathExpression = "//*[@name='" + nameValue + "']";
			driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
		}

		try {

			driver.findElement(By.id("password")).clear();

		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("authentication", "id", "password");
			String xpathExpression = "//*[@id='" + idValue + "']";
			driver.findElement(By.xpath(xpathExpression)).clear();
		}

		try {

			driver.findElement(By.name("password")).sendKeys("admin");

		} catch (NoSuchElementException e) {
			String nameValue = repairerObj.repair("authentication", "name", "password");
			String xpathExpression = "//*[@name='" + nameValue + "']";
			driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
		}

		try {

			driver.findElement(By.xpath("//*[@id=\"loginBox\"]/form/fieldset/button")).click();

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("authentication", "text", "Enter");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();
		}

		try {

			driver.findElement(By.xpath("//*[@id=\"userBannerLeft\"]/ul/li[3]/span/a")).click();

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("admin", "text", "Platform administration");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();
		}

		try {

			driver.findElement(By.xpath("//*[@id=\"claroBody\"]/ul/li[2]/ul/li[2]/a")).click(); // click on Course list
			flag = 1;																				// button in Courses

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("admin", "text", "Course list");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();
			flag = 2;
		}

		try {

			driver.findElement(By.xpath("//*[@id=\"claroBody\"]/table[2]/tbody/tr/td[2]/a")).click(); // click on Course
																										// Title(e.g
																										// CNET)
		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("admin_courses", "text", "DATA STRUCTURE");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();

		}
		
		try {

			WebElement ele = driver.findElement(By.xpath("//*[@id=\"courseManageToolList\"]/li[1]/a"));
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", ele);

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("course", "text", " Edit Tool list");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			WebElement ele = driver.findElement(By.xpath(xpathExpression));
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", ele);

		}
		// Manage tool access rights
		// Anonymous

		try {

			driver.findElement(By.xpath("//*[@id=\"courseRightContent\"]/blockquote/table/tbody/tr[1]/td[3]/a/span"))
			.click();																										
																									
		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("tools", "text", "No access");
			String xpathExpression = "//span[text()='"+new_value+"']";
			driver.findElement(By.xpath(xpathExpression)).click();

		}
			try {

			Assert.assertTrue(driver.findElement(By.cssSelector("BODY")).getText()
					.matches("^[\\s\\S]*" + "Access allowed" + "[\\s\\S]*$"));
		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("tools", "id", "claroBody");
			String xpathExpression = "//*[@id='" + idValue + "']";
			AssertJUnit.assertEquals(driver.findElement(By.xpath(xpathExpression)).getText(), "Access allowed");

		}
		// Guest
		try {
			
			driver.findElement(By.xpath("//*[@id=\"courseRightContent\"]/blockquote/table/tbody/tr[1]/td[4]/a/span"))
			.click();																										
																									
		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("tools", "text", "Access allowed");
			String xpathExpression = "//span[text()='"+new_value+"']";
			driver.findElement(By.xpath(xpathExpression)).click();

		}
			try {

			Assert.assertTrue(driver.findElement(By.cssSelector("BODY")).getText()
					.matches("^[\\s\\S]*" + "No access" + "[\\s\\S]*$"));
		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("tools", "id", "claroBody");
			String xpathExpression = "//*[@id='" + idValue + "']";
			AssertJUnit.assertEquals(driver.findElement(By.xpath(xpathExpression)).getText(), "No access");

		}
		// User
		try {

			driver.findElement(By.xpath("//*[@id=\"courseRightContent\"]/blockquote/table/tbody/tr[1]/td[5]/a/span"))
			.click();																										
																									
		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("tools", "text", "Access allowed");
			String xpathExpression = "//span[text()='"+new_value+"']";
			driver.findElement(By.xpath(xpathExpression)).click();

		}
			try {

			Assert.assertTrue(driver.findElement(By.cssSelector("BODY")).getText()
					.matches("^[\\s\\S]*" + "Edition allowed" + "[\\s\\S]*$"));
		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("tools", "id", "claroBody");
			String xpathExpression = "//*[@id='" + idValue + "']";
			AssertJUnit.assertEquals(driver.findElement(By.xpath(xpathExpression)).getText(), "Edition allowed");

		}
		// Manager
		
	try {

			driver.findElement(By.xpath("//*[@id=\"courseRightContent\"]/blockquote/table/tbody/tr[1]/td[6]/a/span"))
			.click();																										
																									
		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("tools", "text", "Edition allowed");
			String xpathExpression = "//span[text()='"+new_value+"']";
			driver.findElement(By.xpath(xpathExpression)).click();

		}
			try {

			Assert.assertTrue(driver.findElement(By.cssSelector("BODY")).getText()
					.matches("^[\\s\\S]*" + "No access" + "[\\s\\S]*$"));
		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("tools", "id", "claroBody");
			String xpathExpression = "//*[@id='" + idValue + "']";
			AssertJUnit.assertEquals(driver.findElement(By.xpath(xpathExpression)).getText(), "No access");

		}
		// Manage External Links   Manage external links
		try {

			driver.findElement(By.xpath("//*[@id=\"extLinks\"]")).click();
																									
		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("tools", "id", "extLinks");
			String xpathExpression = "//*[@id='" + idValue + "']";
			driver.findElement(By.xpath(xpathExpression)).click();

		}
		try {

			driver.findElement(By.xpath("//*[@id=\"courseRightContent\"]/blockquote/p/a")).click();
																									
		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("tools", "text", "Add external link");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();

		}
		try {

			driver.findElement(By.xpath("//*[@id=\"toolName\"]")).sendKeys("Slate");

		} catch (NoSuchElementException e) {
			String nameValue = repairerObj.repair("tools", "id", "toolName");
			String xpathExpression = "//*[@id='" + nameValue + "']";
			driver.findElement(By.xpath(xpathExpression)).sendKeys("Slate");
		}
		try {

			driver.findElement(By.xpath("//*[@id=\"toolUrl\"]")).sendKeys("http://slate.nu.edu.pk/portal");

		} catch (NoSuchElementException e) {
			String nameValue = repairerObj.repair("tools", "id", "toolUrl");
			String xpathExpression = "//*[@id='" + nameValue + "']";
			driver.findElement(By.xpath(xpathExpression)).sendKeys("http://slate.nu.edu.pk/portal");
		}
		try {

			WebElement ele = driver.findElement(By.xpath("//*[@id=\"courseRightContent\"]/div[3]/div/form/input[8]"));
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", ele);

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("tools", "value", "Ok");
			String xpathExpression = "//input[@value='" + new_value + "']";
			WebElement ele = driver.findElement(By.xpath(xpathExpression));
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", ele);

		}

		try {

			Assert.assertTrue(driver.findElement(By.cssSelector("BODY")).getText()
					.matches("^[\\s\\S]*" + "External Tool added." + "[\\s\\S]*$"));
		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("tools", "id", "claroBody");
			String xpathExpression = "//*[@id='" + idValue + "']";
			AssertJUnit.assertEquals(driver.findElement(By.xpath(xpathExpression)).getText(), "External Tool added.");

		}
		try {

			driver.findElement(By.xpath("//*[@id=\"courseRightContent\"]/blockquote/table/tbody/tr/td[4]/a/img")).click();
		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("tools", "alt", "Delete");
			String xpathExpression = "//img[@alt='" + new_value + "']";
			driver.findElement(By.xpath(xpathExpression)).click();

		}
		Alert alert1 = driver.switchTo().alert();
		alert1.accept();

		try {

			Assert.assertTrue(driver.findElement(By.cssSelector("BODY")).getText()
					.matches("^[\\s\\S]*" + "External tool deleted" + "[\\s\\S]*$"));
		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("tools", "id", "claroBody");
			String xpathExpression = "//*[@id='" + idValue + "']";
			AssertJUnit.assertEquals(driver.findElement(By.xpath(xpathExpression)).getText(), "External tool deleted");

		}
		// Add or remove tool
		try {

			driver.findElement(By.xpath("//*[@id=\"toolList\"]")).click();
																									
		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("tools", "id", "toolList");
			String xpathExpression = "//*[@id='" + idValue + "']";
			driver.findElement(By.xpath(xpathExpression)).click();

		}

		try {

			driver.findElement(By.xpath("//*[@id=\"courseRightContent\"]/blockquote[1]/table/tbody/tr[1]/td[2]/a/img"))
			.click();
			} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("tools", "alt", "Remove");
			String xpathExpression = "//img[@alt='" + new_value + "']";
			driver.findElement(By.xpath(xpathExpression)).click();

		}
	
		try {

			Assert.assertTrue(driver.findElement(By.cssSelector("BODY")).getText()
					.matches("^[\\s\\S]*" + "Tool removed from course" + "[\\s\\S]*$"));
		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("tools", "id", "claroBody");
			String xpathExpression = "//*[@id='" + idValue + "']";
			AssertJUnit.assertEquals(driver.findElement(By.xpath(xpathExpression)).getText(), "Tool removed from course");

		}
		// logout
		try {
			driver.findElements(By.xpath("//*[@id=\"userBannerRight\"]/ul/li[3]/span/a")).get(0).click(); // click on
																											// logout

		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("tools", "id", "userBannerRight");
			String xpathExpression = "//*[@id='" + idValue + "']";
			driver.findElements(By.xpath(xpathExpression)).get(0).click();
		}
	}

	@Test(priority = 12, groups = "regression")
	public void course_Report__1() // testing Platform administration --> Course list --> Course title -->
									// Statistics
	{
		currrent_test="course_Report__1";
		// logIn
		try {

			driver.findElement(By.id("login")).clear();

		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("authentication", "id", "login");
			String xpathExpression = "//*[@id='" + idValue + "']";
			driver.findElement(By.xpath(xpathExpression)).clear();
		}

		try {

			driver.findElement(By.name("login")).sendKeys("admin");

		} catch (NoSuchElementException e) {
			String nameValue = repairerObj.repair("authentication", "name", "login");
			String xpathExpression = "//*[@name='" + nameValue + "']";
			driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
		}

		try {

			driver.findElement(By.id("password")).clear();

		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("authentication", "id", "password");
			String xpathExpression = "//*[@id='" + idValue + "']";
			driver.findElement(By.xpath(xpathExpression)).clear();
		}

		try {

			driver.findElement(By.name("password")).sendKeys("admin");

		} catch (NoSuchElementException e) {
			String nameValue = repairerObj.repair("authentication", "name", "password");
			String xpathExpression = "//*[@name='" + nameValue + "']";
			driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
		}

		try {

			driver.findElement(By.xpath("//*[@id=\"loginBox\"]/form/fieldset/button")).click();

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("authentication", "text", "Enter");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();
		}

		try {

			driver.findElement(By.xpath("//*[@id=\"userBannerLeft\"]/ul/li[3]/span/a")).click();
			
		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("admin", "text", "Platform administration");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();
		}

		try {

			driver.findElement(By.xpath("//*[@id=\"claroBody\"]/ul/li[2]/ul/li[2]/a")).click(); // click on Course list
			flag = 1;																		// button in Courses

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("admin", "text", "Course list");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();
			flag = 2;
		}

		try {

			driver.findElement(By.xpath("//*[@id=\"claroBody\"]/table[2]/tbody/tr/td[2]/a")).click(); // click on Course
																										// Title(e.g
																										// CNET)
		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("admin_courses", "text", "DATA STRUCTURE");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();

		}
		
		try {

			WebElement ele = driver.findElement(By.xpath("//*[@id=\"courseManageToolList\"]/li[4]/a"));
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", ele);

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("course", "text", " Statistics");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			WebElement ele = driver.findElement(By.xpath(xpathExpression));
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", ele);

		}
		

		try {

			driver.findElement(By.xpath("//*[@id=\"courseRightContent\"]/div[1]/table/tbody/tr/td[2]/ul/li/a")).click();
		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("courseReport", "text", "Delete all course statistics");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();

		}
		try {

			driver.findElement(By.xpath("//*[@id=\"scope_all\"]")).click();
		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("courseReport", "id", "scope_all");
			String xpathExpression = "//*[@id='" + idValue + "']";
			driver.findElement(By.xpath(xpathExpression)).click();
		}
		
		try {

			WebElement ele = driver.findElement(By.xpath("//*[@id=\"courseRightContent\"]/div[2]/div[2]/form/input[6]"));
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", ele);

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("delete_course_stats", "value", "Ok");
			String xpathExpression = "//input[@value='" + new_value + "']";
			WebElement ele = driver.findElement(By.xpath(xpathExpression));
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", ele);

		}
	
		try {

			Assert.assertTrue(driver.findElement(By.cssSelector("BODY")).getText()
					.matches("^[\\s\\S]*" + "Course statistics are now empty" + "[\\s\\S]*$"));
		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("tools", "id", "claroBody");
			String xpathExpression = "//*[@id='" + idValue + "']";
			AssertJUnit.assertEquals(driver.findElement(By.xpath(xpathExpression)).getText(), "Course statistics are now empty");

		}
		// logout
		try {
			driver.findElements(By.xpath("//*[@id=\"userBannerRight\"]/ul/li[3]/span/a")).get(0).click(); // click on
																											// logout

		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("tools", "id", "userBannerRight");
			String xpathExpression = "//*[@id='" + idValue + "']";
			driver.findElements(By.xpath(xpathExpression)).get(0).click();
		}
	}

}
