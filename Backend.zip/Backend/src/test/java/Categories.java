
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.testng.AssertJUnit;
import org.testng.annotations.Test;

public class Categories extends DriverIntializor {

	@Test(priority = 1, groups = "regression")
	public void admin_category__1() throws Exception, NoSuchElementException {
		currrent_test="admin_category__1";
		try {

			driver.findElement(By.id("login")).clear();
			

		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("authentication", "id", "login");
			String xpathExpression = "//*[@id='" + idValue + "']";
			driver.findElement(By.xpath(xpathExpression)).clear();
		}

		try {

			driver.findElement(By.name("login")).sendKeys("admin");

		} catch (NoSuchElementException e) {
			String nameValue = repairerObj.repair("authentication", "name", "login");
			String xpathExpression = "//*[@name='" + nameValue + "']";
			driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
		}

		try {

			driver.findElement(By.id("password")).clear();

		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("authentication", "id", "password");
			String xpathExpression = "//*[@id='" + idValue + "']";
			driver.findElement(By.xpath(xpathExpression)).clear();
		}

		try {

			driver.findElement(By.name("password")).sendKeys("admin");

		} catch (NoSuchElementException e) {
			String nameValue = repairerObj.repair("authentication", "name", "password");
			String xpathExpression = "//*[@name='" + nameValue + "']";
			driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
		}

		try {

			driver.findElement(By.xpath("//*[@id=\"loginBox\"]/form/fieldset/button")).click();

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("authentication", "text", "Enter");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();
		}

		// **********************************Categories*****************************

		try {

			driver.findElement(By.xpath("//*[@id=\"userBannerLeft\"]/ul/li[3]/span/a")).click();

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("admin", "text", "Platform administration");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();
		}

		try {

			driver.findElement(By.xpath("//*[@id=\"claroBody\"]/ul/li[2]/ul/li[4]/a")).click();
			flag = 1;
		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("admin", "text", "Manage course categories");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();
			flag = 2;
			
			System.out.println("in catch =================================================================");
		}

		try {

			driver.findElement(By.xpath("//*[@id=\"claroBody\"]/div[1]/table/tbody/tr/td[2]/ul/li/a")).click();

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("admin_category", "text", "Create a category");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();

		}

		try {

			driver.findElement(By.name("category_name")).sendKeys("Non-Social Sciences");

		} catch (NoSuchElementException e) {
			String nameValue = repairerObj.repair("admin_category", "name", "category_name");
			String xpathExpression = "//*[@name='" + nameValue + "']";
			driver.findElement(By.xpath(xpathExpression)).sendKeys("Non-Social Sciences");
		}

		try {

			driver.findElement(By.name("category_code")).sendKeys("NSC2003");

		} catch (NoSuchElementException e) {
			String nameValue = repairerObj.repair("admin_category", "name", "category_code");
			String xpathExpression = "//*[@name='" + nameValue + "']";
			driver.findElement(By.xpath(xpathExpression)).sendKeys("NSC2003");
		}

		try {

			driver.findElement(By.name("category_parent")).click();

		} catch (NoSuchElementException e) {
			String nameValue = repairerObj.repair("admin_category", "name", "category_parent");
			String xpathExpression = "//*[@name='" + nameValue + "']";
			driver.findElement(By.xpath(xpathExpression)).click();
		}

		try {

			driver.findElement(By.xpath("//*[@id=\"category_parent\"]/option[4]")).click();

		} catch (NoSuchElementException e) {
			String optionValue = repairerObj.repair("admin_category", "value", "category_parent");
			String xpathExpression = "//option[@value='" + optionValue + "']";
			driver.findElement(By.xpath(xpathExpression)).click();
		}

		try {

			driver.findElement(By.id("visible")).click();

		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("admin_category", "id", "visible");
			String xpathExpression = "//*[@id='" + idValue + "']";
			driver.findElement(By.xpath(xpathExpression)).click();
		}

		try {

			driver.findElement(By.id("can_have_courses")).click();

		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("admin_category", "id", "can_have_courses");
			String xpathExpression = "//*[@id='" + idValue + "']";
			driver.findElement(By.xpath(xpathExpression)).click();
		}

		try {

			driver.findElement(By.xpath("//*[@id=\"categorySettings\"]/input[3]")).click();

		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("admin_category", "id", "categorySettings");
			String xpathExpression = "//*[@id='" + idValue + "']";
			driver.findElement(By.xpath(xpathExpression)).click();
		}

		try {
			AssertJUnit.assertEquals(driver.findElement(By.xpath("//*[@id=\"claroBody\"]/div[2]/div")).getText(),
					"Category created");

		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("admin_category", "id", "claroBody");
			String xpathExpression = "//*[@id='" + idValue + "']";
			AssertJUnit.assertEquals(driver.findElement(By.xpath(xpathExpression)).getText(), "Category created");

		}

		try {

			driver.findElements(By.xpath("//*[@id=\"userBannerRight\"]/ul/li[3]/span/a")).get(0).click(); // click on
																											// logout

		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("admin_category", "id", "userBannerRight");
			String xpathExpression = "//*[@id='" + idValue + "']";
			driver.findElements(By.xpath(xpathExpression)).get(0).click();
		}

	}

	@Test(priority = 2, groups = "regression")
	public void admin_category__2() throws Exception {
		try {
			currrent_test="admin_category__2";
			driver.findElement(By.id("login")).clear();

		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("authentication", "id", "login");
			String xpathExpression = "//*[@id='" + idValue + "']";
			driver.findElement(By.xpath(xpathExpression)).clear();
		}

		try {

			driver.findElement(By.name("login")).sendKeys("admin");

		} catch (NoSuchElementException e) {
			String nameValue = repairerObj.repair("authentication", "name", "login");
			String xpathExpression = "//*[@name='" + nameValue + "']";
			driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
		}

		try {

			driver.findElement(By.id("password")).clear();

		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("authentication", "id", "password");
			String xpathExpression = "//*[@id='" + idValue + "']";
			driver.findElement(By.xpath(xpathExpression)).clear();
		}

		try {

			driver.findElement(By.name("password")).sendKeys("admin");

		} catch (NoSuchElementException e) {
			String nameValue = repairerObj.repair("authentication", "name", "password");
			String xpathExpression = "//*[@name='" + nameValue + "']";
			driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
		}

		try {

			driver.findElement(By.xpath("//*[@id=\"loginBox\"]/form/fieldset/button")).click();

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("authentication", "text", "Enter");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();
		}

		// **********************************Categories*****************************

		try {

			driver.findElement(By.xpath("//*[@id=\"userBannerLeft\"]/ul/li[3]/span/a")).click();

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("admin", "text", "Platform administration");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();
		}

		try {

			driver.findElement(By.xpath("//*[@id=\"claroBody\"]/ul/li[2]/ul/li[4]/a")).click();
			flag = 1;
		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("admin", "text", "Manage course categories");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();
			flag = 2;
			System.out.println("in catch =================================================================");
		}
		try {

			driver.findElement(By.xpath("//*[@id=\"claroBody\"]/table/tbody/tr[4]/td[5]/a/img")).click();

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("admin_category", "alt", "Edit category");
			String xpathExpression = "//img[@alt='" + new_value + "']";
			driver.findElement(By.xpath(xpathExpression)).click();
		}

		try {

			driver.findElement(By.name("category_name")).clear();

		} catch (NoSuchElementException e) {
			String nameValue = repairerObj.repair("admin_category", "name", "category_name");
			String xpathExpression = "//*[@name='" + nameValue + "']";
			driver.findElement(By.xpath(xpathExpression)).clear();
		}

		try {

			driver.findElement(By.name("category_name")).sendKeys("Marketing");

		} catch (NoSuchElementException e) {
			String nameValue = repairerObj.repair("admin_category", "name", "category_name");
			String xpathExpression = "//*[@name='" + nameValue + "']";
			driver.findElement(By.xpath(xpathExpression)).sendKeys("Marketing");
		}

		try {

			driver.findElement(By.name("category_code")).clear();

		} catch (NoSuchElementException e) {
			String nameValue = repairerObj.repair("admin_category", "name", "category_code");
			String xpathExpression = "//*[@name='" + nameValue + "']";
			driver.findElement(By.xpath(xpathExpression)).clear();
		}

		try {

			driver.findElement(By.name("category_code")).sendKeys("MG205");

		} catch (NoSuchElementException e) {
			String nameValue = repairerObj.repair("admin_category", "name", "category_code");
			String xpathExpression = "//*[@name='" + nameValue + "']";
			driver.findElement(By.xpath(xpathExpression)).sendKeys("MG205");
		}

		try {

			driver.findElement(By.name("category_parent")).click();

		} catch (NoSuchElementException e) {
			String nameValue = repairerObj.repair("admin_category", "name", "category_parent");
			String xpathExpression = "//*[@name='" + nameValue + "']";
			driver.findElement(By.xpath(xpathExpression)).click();
		}

		try {

			driver.findElement(By.xpath("//*[@id=\"category_parent\"]/option[4]")).click();

		} catch (NoSuchElementException e) {
			String optionValue = repairerObj.repair("admin_category", "value", "category_parent");
			String xpathExpression = "//option[@value='" + optionValue + "']";
			driver.findElement(By.xpath(xpathExpression)).click();
		}

		try {

			driver.findElement(By.id("visible")).click();

		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("admin_category", "id", "visible");
			String xpathExpression = "//*[@id='" + idValue + "']";
			driver.findElement(By.xpath(xpathExpression)).click();
		}

		try {

			driver.findElement(By.id("can_have_courses")).click();

		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("admin_category", "id", "can_have_courses");
			String xpathExpression = "//*[@id='" + idValue + "']";
			driver.findElement(By.xpath(xpathExpression)).click();
		}

		try {

			driver.findElement(By.xpath("//*[@id=\"categorySettings\"]/input[3]")).click();

		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("admin_category", "id", "categorySettings");
			String xpathExpression = "//*[@id='" + idValue + "']";
			driver.findElement(By.xpath(xpathExpression)).click();
		}

		// AssertJUnit.assertTrue(driver.findElement(By.cssSelector("BODY")).getText().matches("^[\\s\\S]*Category
		// modified[\\s\\S]*$"));

		try {
			AssertJUnit.assertEquals(driver.findElement(By.xpath("//*[@id=\"claroBody\"]/div[2]/div")).getText(),
					"Category modified");

		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("admin_category", "id", "claroBody");
			String xpathExpression = "//*[@id='" + idValue + "']";
			AssertJUnit.assertEquals(driver.findElement(By.xpath(xpathExpression)).getText(), "Category modified");

		}

		try {
			driver.findElements(By.xpath("//*[@id=\"userBannerRight\"]/ul/li[3]/span/a")).get(0).click(); // click on
																											// logout

		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("admin_category", "id", "userBannerRight");
			String xpathExpression = "//*[@id='" + idValue + "']";
			driver.findElements(By.xpath(xpathExpression)).get(0).click();
		}
	}

	@Test(priority = 3, groups = "regression")
	public void admin_category__3() throws Exception {
		currrent_test="admin_category__3";
		try {

			driver.findElement(By.id("login")).clear();

		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("authentication", "id", "login");
			String xpathExpression = "//*[@id='" + idValue + "']";
			driver.findElement(By.xpath(xpathExpression)).clear();
		}

		try {

			driver.findElement(By.name("login")).sendKeys("admin");

		} catch (NoSuchElementException e) {
			String nameValue = repairerObj.repair("authentication", "name", "login");
			String xpathExpression = "//*[@name='" + nameValue + "']";
			driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
		}

		try {

			driver.findElement(By.id("password")).clear();

		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("authentication", "id", "password");
			String xpathExpression = "//*[@id='" + idValue + "']";
			driver.findElement(By.xpath(xpathExpression)).clear();
		}

		try {

			driver.findElement(By.name("password")).sendKeys("admin");

		} catch (NoSuchElementException e) {
			String nameValue = repairerObj.repair("authentication", "name", "password");
			String xpathExpression = "//*[@name='" + nameValue + "']";
			driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
		}

		try {

			driver.findElement(By.xpath("//*[@id=\"loginBox\"]/form/fieldset/button")).click();

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("authentication", "text", "Enter");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();
		}

		// **********************************Categories*****************************

		try {

			driver.findElement(By.xpath("//*[@id=\"userBannerLeft\"]/ul/li[3]/span/a")).click();

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("admin", "text", "Platform administration");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();
		}

		try {

			driver.findElement(By.xpath("//*[@id=\"claroBody\"]/ul/li[2]/ul/li[4]/a")).click();
			flag = 1;
		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("admin", "text", "Manage course categories");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();
			flag = 2;
			System.out.println("in catch =================================================================");
		}
		try {

			driver.findElement(By.xpath("//*[@id=\"claroBody\"]/table/tbody/tr[4]/td[4]/a/img")).click();

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("admin_category", "alt", "Change visibility");
			String xpathExpression = "//img[@alt='" + new_value + "']";
			driver.findElement(By.xpath(xpathExpression)).click();
		}
		// AssertJUnit.assertTrue(driver.findElement(By.cssSelector("BODY")).getText().matches("^[\\s\\S]*Category's
		// visibility modified[\\s\\S]*$"));

		try {
			AssertJUnit.assertEquals(driver.findElement(By.xpath("//*[@id=\"claroBody\"]/div[2]/div")).getText(),
					"Category's visibility modified");

		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("admin_category", "id", "claroBody");
			String xpathExpression = "//*[@id='" + idValue + "']";
			AssertJUnit.assertEquals(driver.findElement(By.xpath(xpathExpression)).getText(),
					"Category's visibility modified");

		}

		try {
			driver.findElements(By.xpath("//*[@id=\"userBannerRight\"]/ul/li[3]/span/a")).get(0).click(); // click on
																											// logout

		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("admin_category", "id", "userBannerRight");
			String xpathExpression = "//*[@id='" + idValue + "']";
			driver.findElements(By.xpath(xpathExpression)).get(0).click();
		}

	}

	@Test(priority = 4, groups = "regression")
	public void delete_course_stats__1() throws Exception {
		currrent_test="delete_course_stats__1";
		try {

			driver.findElement(By.id("login")).clear();

		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("authentication", "id", "login");
			String xpathExpression = "//*[@id='" + idValue + "']";
			driver.findElement(By.xpath(xpathExpression)).clear();
		}

		try {

			driver.findElement(By.name("login")).sendKeys("admin");

		} catch (NoSuchElementException e) {
			String nameValue = repairerObj.repair("authentication", "name", "login");
			String xpathExpression = "//*[@name='" + nameValue + "']";
			driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
		}

		try {

			driver.findElement(By.id("password")).clear();

		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("authentication", "id", "password");
			String xpathExpression = "//*[@id='" + idValue + "']";
			driver.findElement(By.xpath(xpathExpression)).clear();
		}

		try {

			driver.findElement(By.name("password")).sendKeys("admin");

		} catch (NoSuchElementException e) {
			String nameValue = repairerObj.repair("authentication", "name", "password");
			String xpathExpression = "//*[@name='" + nameValue + "']";
			driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
		}

		try {

			driver.findElement(By.xpath("//*[@id=\"loginBox\"]/form/fieldset/button")).click();

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("authentication", "text", "Enter");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();
		}

		// **********************************Categories*****************************

		try {

			driver.findElement(By.xpath("//*[@id=\"userBannerLeft\"]/ul/li[3]/span/a")).click();

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("admin", "text", "Platform administration");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();
		}

		try {

			driver.findElement(By.xpath("//*[@id=\"claroBody\"]/ul/li[2]/ul/li[4]/a")).click();
			flag = 1;
		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("admin", "text", "Manage course categories");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();
			flag = 2;
			System.out.println("in catch =================================================================");
		}
		try {

			driver.findElement(By.xpath("//*[@id=\"claroBody\"]/table/tbody/tr[4]/td[6]/a/img")).click();

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("admin_category", "alt", "Delete category");
			String xpathExpression = "//img[@alt='" + new_value + "']";
			driver.findElement(By.xpath(xpathExpression)).click();
		}

		Alert alert = driver.switchTo().alert();
		alert.accept();
		// AssertJUnit.assertTrue(driver.findElement(By.cssSelector("BODY")).getText().matches("^[\\s\\S]*Category
		// deleted. Courses linked to this category have been linked to the root
		// category.[\\s\\S]*$"));

		try {
			AssertJUnit.assertEquals(driver.findElement(By.xpath("//*[@id=\"claroBody\"]/div[2]/div")).getText(),
					"Category deleted. Courses linked to this category have been linked to the root category.");

		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("admin_category", "id", "claroBody");
			String xpathExpression = "//*[@id='" + idValue + "']";
			AssertJUnit.assertEquals(driver.findElement(By.xpath(xpathExpression)).getText(),
					"Category deleted. Courses linked to this category have been linked to the root category.");

		}

		try {
			driver.findElements(By.xpath("//*[@id=\"userBannerRight\"]/ul/li[3]/span/a")).get(0).click(); // click on
																											// logout

		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("admin_category", "id", "userBannerRight");
			String xpathExpression = "//*[@id='" + idValue + "']";
			driver.findElements(By.xpath(xpathExpression)).get(0).click();
		}

	}
	 

}
