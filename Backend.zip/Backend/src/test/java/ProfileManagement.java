

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.testng.AssertJUnit;
import org.testng.annotations.Test;
public class ProfileManagement extends DriverIntializor{

	  @Test(priority =1 ,groups= "regression")
		public void profile__1()throws Exception
		{
		  currrent_test="profile__1";
		  try {

				driver.findElement(By.id("login")).clear();

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("authentication", "id", "login");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElement(By.xpath(xpathExpression)).clear();
			}

			try {

				driver.findElement(By.name("login")).sendKeys("admin");

			} catch (NoSuchElementException e) {
				String nameValue = repairerObj.repair("authentication", "name", "login");
				String xpathExpression = "//*[@name='" + nameValue + "']";
				driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
			}

			try {

				driver.findElement(By.id("password")).clear();

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("authentication", "id", "password");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElement(By.xpath(xpathExpression)).clear();
			}

			try {

				driver.findElement(By.name("password")).sendKeys("admin");

			} catch (NoSuchElementException e) {
				String nameValue = repairerObj.repair("authentication", "name", "password");
				String xpathExpression = "//*[@name='" + nameValue + "']";
				driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
			}

			try {

				driver.findElement(By.xpath("//*[@id=\"loginBox\"]/form/fieldset/button")).click();

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("authentication", "text", "Enter");
				String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
				driver.findElement(By.xpath(xpathExpression)).click();
			}

			try {

				driver.findElement(By.xpath("//*[@id=\"userBannerLeft\"]/ul/li[3]/span/a")).click();

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("admin", "text", "Platform administration");
				String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
				driver.findElement(By.xpath(xpathExpression)).click();
			}

			try {

				driver.findElement(By.xpath("//*[@id=\"claroBody\"]/ul/li[1]/ul/li[7]/a")).click();   //click on Right Profile list
				flag = 1;																			

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("admin", "text", "Right profile list");
				String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
				driver.findElement(By.xpath(xpathExpression)).click();
				flag = 2;
			}

			try {

				driver.findElement(By.xpath("//*[@id=\"claroBody\"]/div[1]/table/tbody/tr/td[2]/ul/li/a")).click();   //click to add new profile
																									

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("profile_list", "text", "Add new profile");
				String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
				driver.findElement(By.xpath(xpathExpression)).click();

			}
			 try {

				 driver.findElement(By.id("name")).clear();        //clear the field

				} catch (NoSuchElementException e) {
					String idValue = repairerObj.repair("profile_list", "id", "name");
					String xpathExpression = "//*[@id='" + idValue + "']";
					driver.findElement(By.xpath(xpathExpression)).clear();
				}

				try {

					 driver.findElement(By.id("name")).sendKeys("Admistrator"); //set the value

				} catch (NoSuchElementException e) {
					String nameValue = repairerObj.repair("profile_list", "id", "name");
					String xpathExpression = "//*[@id='" + nameValue + "']";
					driver.findElement(By.xpath(xpathExpression)).sendKeys("Admistrator");
				}
			 try {

				 driver.findElement(By.id("description")).clear();        //clear the field

				} catch (NoSuchElementException e) {
					String idValue = repairerObj.repair("profile_list", "id", "description");
					String xpathExpression = "//*[@id='" + idValue + "']";
					driver.findElement(By.xpath(xpathExpression)).clear();
				}

				try {

					 driver.findElement(By.id("description")).sendKeys("System Administrator"); //set the value

				} catch (NoSuchElementException e) {
					String nameValue = repairerObj.repair("profile_list", "id", "description");
					String xpathExpression = "//*[@id='" + nameValue + "']";
					driver.findElement(By.xpath(xpathExpression)).sendKeys("System Administrator");
				}
			 try {

				 driver.findElement(By.id("isLocked")).click(); //click to luck the profile
																										

				} catch (NoSuchElementException e) {
					String nameValue = repairerObj.repair("profile_list", "id", "isLocked");
					String xpathExpression = "//*[@id='" + nameValue + "']";
					driver.findElement(By.xpath(xpathExpression)).click();

				}
			 try {

				 driver.findElement(By.name("submitProfile")).click(); //click to submit the profile
																										

				} catch (NoSuchElementException e) {
					String nameValue = repairerObj.repair("profile_list", "name", "submitProfile");
					String xpathExpression = "//*[@name='" + nameValue + "']";
					driver.findElement(By.xpath(xpathExpression)).click();

				}
			 
		
			 try {

					Assert.assertTrue(driver.findElement(By.cssSelector("BODY")).getText()
							.matches("^[\\s\\S]*" + "Admistrator" + "[\\s\\S]*$"));
				} catch (NoSuchElementException e) {
					String idValue = repairerObj.repair("profile_list", "id", "claroBody");
					String xpathExpression = "//*[@id='" + idValue + "']";
					AssertJUnit.assertEquals(driver.findElement(By.xpath(xpathExpression)).getText(), "Admistrator");

				}
				try {
					driver.findElements(By.xpath("//*[@id=\"userBannerRight\"]/ul/li[3]/span/a")).get(0).click(); // click on
																													// logout

				} catch (NoSuchElementException e) {
					String idValue = repairerObj.repair("profile_list", "id", "userBannerRight");
					String xpathExpression = "//*[@id='" + idValue + "']";
					driver.findElements(By.xpath(xpathExpression)).get(0).click();
				}
			
		}
	  
	  
	  @Test(priority =2 ,groups= "regression")
			public void admin_delete__1()throws Exception
			{
		  currrent_test="admin_delete__1";
		  try {

				driver.findElement(By.id("login")).clear();

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("authentication", "id", "login");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElement(By.xpath(xpathExpression)).clear();
			}

			try {

				driver.findElement(By.name("login")).sendKeys("admin");

			} catch (NoSuchElementException e) {
				String nameValue = repairerObj.repair("authentication", "name", "login");
				String xpathExpression = "//*[@name='" + nameValue + "']";
				driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
			}

			try {

				driver.findElement(By.id("password")).clear();

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("authentication", "id", "password");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElement(By.xpath(xpathExpression)).clear();
			}

			try {

				driver.findElement(By.name("password")).sendKeys("admin");

			} catch (NoSuchElementException e) {
				String nameValue = repairerObj.repair("authentication", "name", "password");
				String xpathExpression = "//*[@name='" + nameValue + "']";
				driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
			}

			try {

				driver.findElement(By.xpath("//*[@id=\"loginBox\"]/form/fieldset/button")).click();

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("authentication", "text", "Enter");
				String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
				driver.findElement(By.xpath(xpathExpression)).click();
			}

			try {

				driver.findElement(By.xpath("//*[@id=\"userBannerLeft\"]/ul/li[3]/span/a")).click();

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("admin", "text", "Platform administration");
				String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
				driver.findElement(By.xpath(xpathExpression)).click();
			}

			try {

				driver.findElement(By.xpath("//*[@id=\"claroBody\"]/ul/li[1]/ul/li[7]/a")).click();   //click on Right Profile list
				flag = 1;																					

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("admin", "text", "Right profile list");
				String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
				driver.findElement(By.xpath(xpathExpression)).click();
				flag = 2;
			}

			try {

				driver.findElements(By.xpath("//*[@id=\"claroBody\"]/table/tbody/tr[5]/td[5]/a/img")).get(0).click();   //click to delete the profile
																									

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("profile_list", "alt", "Delete");
				String xpathExpression = "//img[@alt='" + new_value + "']";
				driver.findElement(By.xpath(xpathExpression)).click();

			}
				
			
				 try {

						Assert.assertTrue(driver.findElement(By.cssSelector("BODY")).getText()
								.matches("^[\\s\\S]*" + "Manager" + "[\\s\\S]*$"));
					} catch (NoSuchElementException e) {
						String idValue = repairerObj.repair("profile_list", "id", "claroBody");
						String xpathExpression = "//*[@id='" + idValue + "']";
						AssertJUnit.assertEquals(driver.findElement(By.xpath(xpathExpression)).getText(), "Manager");

					}
					try {
						driver.findElements(By.xpath("//*[@id=\"userBannerRight\"]/ul/li[3]/span/a")).get(0).click(); // click on
																														// logout

					} catch (NoSuchElementException e) {
						String idValue = repairerObj.repair("profile_list", "id", "userBannerRight");
						String xpathExpression = "//*[@id='" + idValue + "']";
						driver.findElements(By.xpath(xpathExpression)).get(0).click();
					}
				
			}
	  
	  @Test(priority =3 ,groups= "regression")
		public void admin_profile__1()throws Exception
		{
		  currrent_test="admin_profile__1";
		  try {

				driver.findElement(By.id("login")).clear();

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("authentication", "id", "login");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElement(By.xpath(xpathExpression)).clear();
			}

			try {

				driver.findElement(By.name("login")).sendKeys("admin");

			} catch (NoSuchElementException e) {
				String nameValue = repairerObj.repair("authentication", "name", "login");
				String xpathExpression = "//*[@name='" + nameValue + "']";
				driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
			}

			try {

				driver.findElement(By.id("password")).clear();

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("authentication", "id", "password");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElement(By.xpath(xpathExpression)).clear();
			}

			try {

				driver.findElement(By.name("password")).sendKeys("admin");

			} catch (NoSuchElementException e) {
				String nameValue = repairerObj.repair("authentication", "name", "password");
				String xpathExpression = "//*[@name='" + nameValue + "']";
				driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
			}

			try {

				driver.findElement(By.xpath("//*[@id=\"loginBox\"]/form/fieldset/button")).click();

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("authentication", "text", "Enter");
				String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
				driver.findElement(By.xpath(xpathExpression)).click();
			}

			try {

				driver.findElement(By.xpath("//*[@id=\"userBannerLeft\"]/ul/li[3]/span/a")).click();

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("admin", "text", "Platform administration");
				String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
				driver.findElement(By.xpath(xpathExpression)).click();
			}

			try {

				driver.findElement(By.xpath("//*[@id=\"claroBody\"]/ul/li[1]/ul/li[7]/a")).click();   //click on Right Profile list
				flag = 1;																					

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("admin", "text", "Right profile list");
				String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
				driver.findElement(By.xpath(xpathExpression)).click();
				flag = 2;
			}
			String str2 = "",str1 ="";
			try {

				 str2=driver.findElement(By.xpath("//*[@id=\"claroBody\"]/table/tbody/tr[1]/td[6]/a/img")).getAttribute("alt");// get text
																									

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("profile_list", "alt", "Unlock");
				String xpathExpression = "//img[@alt='" + new_value + "']";
				 str2=driver.findElement(By.xpath(xpathExpression)).getAttribute("alt");// get text

			}
			try {

				driver.findElement(By.xpath("//*[@id=\"claroBody\"]/table/tbody/tr[1]/td[6]/a/img")).click();   //click  on lock
																									

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("profile_list", "alt", "Unlock");
				String xpathExpression = "//img[@alt='" + new_value + "']";
				driver.findElement(By.xpath(xpathExpression)).click();

			}
			try {

				 str1=driver.findElement(By.xpath("//*[@id=\"claroBody\"]/table/tbody/tr[1]/td[6]/a/img")).getAttribute("alt");// get text
																									

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("profile_list", "alt", "lock");
				String xpathExpression = "//img[@alt='" + new_value + "']";
				 str1=driver.findElement(By.xpath(xpathExpression)).getAttribute("alt");// get text

			}		
			Assert.assertNotEquals(str1,str2);  //comparision
		
			try {
				driver.findElement(By.xpath("//*[@id=\"userBannerRight\"]/ul/li[3]/span/a")).click(); // click on
																												// logout

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("profile_list", "id", "userBannerRight");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElement(By.xpath(xpathExpression)).click();
			}		}
	  
	  @Test(priority =4 ,groups= "regression")
		public void admin_profile__2()throws Exception
		{
		  currrent_test="admin_profile__2";
		  try {

				driver.findElement(By.id("login")).clear();

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("authentication", "id", "login");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElement(By.xpath(xpathExpression)).clear();
			}

			try {

				driver.findElement(By.name("login")).sendKeys("admin");

			} catch (NoSuchElementException e) {
				String nameValue = repairerObj.repair("authentication", "name", "login");
				String xpathExpression = "//*[@name='" + nameValue + "']";
				driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
			}

			try {

				driver.findElement(By.id("password")).clear();

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("authentication", "id", "password");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElement(By.xpath(xpathExpression)).clear();
			}

			try {

				driver.findElement(By.name("password")).sendKeys("admin");

			} catch (NoSuchElementException e) {
				String nameValue = repairerObj.repair("authentication", "name", "password");
				String xpathExpression = "//*[@name='" + nameValue + "']";
				driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
			}

			try {

				driver.findElement(By.xpath("//*[@id=\"loginBox\"]/form/fieldset/button")).click();

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("authentication", "text", "Enter");
				String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
				driver.findElement(By.xpath(xpathExpression)).click();
			}

			try {

				driver.findElement(By.xpath("//*[@id=\"userBannerLeft\"]/ul/li[3]/span/a")).click();

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("admin", "text", "Platform administration");
				String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
				driver.findElement(By.xpath(xpathExpression)).click();
			}

			try {

				driver.findElement(By.xpath("//*[@id=\"claroBody\"]/ul/li[1]/ul/li[7]/a")).click();   //click on Right Profile list
				flag = 1;																				

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("admin", "text", "Right profile list");
				String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
				driver.findElement(By.xpath(xpathExpression)).click();
				flag = 2;
			}
			String str2 = "",str1 ="";
			try {

				 str1=driver.findElement(By.xpath("//*[@id=\"claroBody\"]/table/tbody/tr[1]/td[6]/a/img")).getAttribute("alt");// get text
																									

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("profile_list", "alt", "Unlock");
				String xpathExpression = "//img[@alt='" + new_value + "']";
				 str1=driver.findElement(By.xpath(xpathExpression)).getAttribute("alt");// get text

			}
			try {

				driver.findElement(By.xpath("//*[@id=\"claroBody\"]/table/tbody/tr[1]/td[3]/a/img")).click();   //click to Edit profile
																									

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("profile_list", "alt", "Edit");
				String xpathExpression = "//img[@alt='" + new_value + "']";
				driver.findElement(By.xpath(xpathExpression)).click();

			}
			 try {

				 driver.findElement(By.id("isLocked")).click(); //click to luck or unluck the profile
																										

				} catch (NoSuchElementException e) {
					String new_value = repairerObj.repair("profile_list", "id", "isLocked");
					String xpathExpression = "//*[@id='" + new_value + "']";
					driver.findElement(By.xpath(xpathExpression)).click();

				}
			 try {

				 driver.findElement(By.name("submitProfile")).click(); //click to submit the profile
																										

				} catch (NoSuchElementException e) {
					String new_value = repairerObj.repair("profile_list", "name", "submitProfile");
					String xpathExpression = "//*[@name='" + new_value + "']";
					driver.findElement(By.xpath(xpathExpression)).click();

				}
			try {

				 str2=driver.findElement(By.xpath("//*[@id=\"claroBody\"]/table/tbody/tr[1]/td[6]/a/img")).getAttribute("alt");// get text
																									

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("profile_list", "alt", "Unlock");
				String xpathExpression = "//img[@alt='" + new_value + "']";
				 str2=driver.findElement(By.xpath(xpathExpression)).getAttribute("alt");// get text

			}
			Assert.assertNotEquals(str1,str2);  //comparision

			try {
				driver.findElements(By.xpath("//*[@id=\"userBannerRight\"]/ul/li[3]/span/a")).get(0).click(); // click on
																												// logout

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("profile_list", "id", "userBannerRight");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElements(By.xpath(xpathExpression)).get(0).click();
			}		
		}
	  
	  
	  @Test(priority =5 ,groups= "regression")
		public void profile_list__1()throws Exception
		{
		  currrent_test="profile_list__1";
		  try {

				driver.findElement(By.id("login")).clear();

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("authentication", "id", "login");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElement(By.xpath(xpathExpression)).clear();
			}

			try {

				driver.findElement(By.name("login")).sendKeys("admin");

			} catch (NoSuchElementException e) {
				String nameValue = repairerObj.repair("authentication", "name", "login");
				String xpathExpression = "//*[@name='" + nameValue + "']";
				driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
			}

			try {

				driver.findElement(By.id("password")).clear();

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("authentication", "id", "password");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElement(By.xpath(xpathExpression)).clear();
			}

			try {

				driver.findElement(By.name("password")).sendKeys("admin");

			} catch (NoSuchElementException e) {
				String nameValue = repairerObj.repair("authentication", "name", "password");
				String xpathExpression = "//*[@name='" + nameValue + "']";
				driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
			}

			try {

				driver.findElement(By.xpath("//*[@id=\"loginBox\"]/form/fieldset/button")).click();

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("authentication", "text", "Enter");
				String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
				driver.findElement(By.xpath(xpathExpression)).click();
			}

			try {

				driver.findElement(By.xpath("//*[@id=\"userBannerLeft\"]/ul/li[3]/span/a")).click();

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("admin", "text", "Platform administration");
				String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
				driver.findElement(By.xpath(xpathExpression)).click();
			}

			try {

				driver.findElement(By.xpath("//*[@id=\"claroBody\"]/ul/li[1]/ul/li[7]/a")).click();   //click on Right Profile list
				flag = 1;																				

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("admin", "text", "Right profile list");
				String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
				driver.findElement(By.xpath(xpathExpression)).click();
				flag = 2;
			}
			try {

				driver.findElement(By.xpath("//*[@id=\"claroBody\"]/table/tbody/tr[1]/td[4]/a/img")).click();   //click to alter rights
																									

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("profile_list", "alt", "Edit");
				String xpathExpression = "//img[@alt='" + new_value + "']";
				driver.findElement(By.xpath(xpathExpression)).click();

			}
			String str1 ="", str2 = "";
			try {

				 str1=driver.findElement(By.xpath("//*[@id=\"claroBody\"]/table/tbody/tr[1]/td[2]/a/span")).getText();  // get text
																									

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("profile", "span", "No access");
				String xpathExpression = "//span[text()='" + new_value + "']";
				str1=driver.findElement(By.xpath(xpathExpression)).getText();
				
			}
			try {

				driver.findElement(By.xpath("//*[@id=\"claroBody\"]/table/tbody/tr[1]/td[2]/a/span")).click();   //click to change rights
																									

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("profile", "span", "No access");
				String xpathExpression = "//span[text()='" + new_value + "']";
				driver.findElement(By.xpath(xpathExpression)).click();
				
			}
			try {

				 str2=driver.findElement(By.xpath("//*[@id=\"claroBody\"]/table/tbody/tr[1]/td[2]/a/span")).getText();  // get text
																									

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("profile", "span", "No access");
				String xpathExpression = "//span[text()='" + new_value + "']";
				str2=driver.findElement(By.xpath(xpathExpression)).getText();
				
			}		
			Assert.assertNotEquals(str1,str2);  //comparision

			try {
				driver.findElements(By.xpath("//*[@id=\"userBannerRight\"]/ul/li[3]/span/a")).get(0).click(); // click on
																												// logout

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("profile_list", "id", "userBannerRight");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElements(By.xpath(xpathExpression)).get(0).click();
			}	
		}

}
