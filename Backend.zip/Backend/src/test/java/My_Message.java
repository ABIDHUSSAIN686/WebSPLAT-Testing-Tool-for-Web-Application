

import org.junit.Assert;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.testng.AssertJUnit;
import org.testng.annotations.Test;



public class My_Message extends DriverIntializor{

	@Test(priority =2 ,groups= "regression")
	public void message_box__2()throws Exception
	{
		currrent_test="message_box__2";
		try {

			driver.findElement(By.id("login")).clear();

		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("authentication", "id", "login");
			String xpathExpression = "//*[@id='" + idValue + "']";
			driver.findElement(By.xpath(xpathExpression)).clear();
		}

		try {

			driver.findElement(By.name("login")).sendKeys("admin");

		} catch (NoSuchElementException e) {
			String nameValue = repairerObj.repair("authentication", "name", "login");
			String xpathExpression = "//*[@name='" + nameValue + "']";
			driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
		}

		try {

			driver.findElement(By.id("password")).clear();

		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("authentication", "id", "password");
			String xpathExpression = "//*[@id='" + idValue + "']";
			driver.findElement(By.xpath(xpathExpression)).clear();
		}

		try {

			driver.findElement(By.name("password")).sendKeys("admin");

		} catch (NoSuchElementException e) {
			String nameValue = repairerObj.repair("authentication", "name", "password");
			String xpathExpression = "//*[@name='" + nameValue + "']";
			driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
		}

		try {

			driver.findElement(By.xpath("//*[@id=\"loginBox\"]/form/fieldset/button")).click();

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("authentication", "text", "Enter");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();
		}

		try {

			driver.findElement(By.xpath("//*[@id=\"userBannerLeft\"]/ul/li[2]/span/a")).click();
			flag = 1;
		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("admin", "text", "My messages");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();
			flag = 2;
		}

		
		try {

			driver.findElement(By.name("search")).sendKeys("Programming Fundamentals");

		} catch (NoSuchElementException e) {
			String nameValue = repairerObj.repair("messagebox", "name", "search");
			String xpathExpression = "//*[@name='" + nameValue + "']";
			driver.findElement(By.xpath(xpathExpression)).sendKeys("Programming Fundamentals");
		}
		try {

			WebElement ele = driver.findElement(By.xpath("//*[@id=\"claroBody\"]/div[3]/div/form/input[2]"));//click on search
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", ele);

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("messagebox", "value", "Search");
			String xpathExpression = "//input[@value='" + new_value + "']";
			WebElement ele = driver.findElement(By.xpath(xpathExpression));
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", ele);
		}
		try {

			driver.findElement(By.xpath("//*[@id=\"claroBody\"]/table/tbody/tr[1]/td[4]/a/img")).click();
																								

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("profile_list", "alt", "");
			String xpathExpression = "//img[@alt='" + new_value + "']";
			 driver.findElement(By.xpath(xpathExpression)).click();

		}		
		Alert alert = driver.switchTo().alert();
        alert.accept();
        try {

			Assert.assertTrue(driver.findElement(By.cssSelector("BODY")).getText()
					.matches("^[\\s\\S]*" + "The message in now in your trashbox" + "[\\s\\S]*$"));
		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("authentication", "id", "claroBody");
			String xpathExpression = "//*[@id='" + idValue + "']";
			AssertJUnit.assertEquals(driver.findElement(By.xpath(xpathExpression)).getText(), "The message in now in your trashbox");

		}
		try {
			driver.findElements(By.xpath("//*[@id=\"userBannerRight\"]/ul/li[3]/span/a")).get(0).click(); // click on
																											// logout

		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("authentication", "id", "userBannerRight");
			String xpathExpression = "//*[@id='" + idValue + "']";
			driver.findElements(By.xpath(xpathExpression)).get(0).click();
		}
		}

	@Test(priority =3 ,groups= "regression")
	public void message_box__3()throws Exception
	{
		currrent_test="message_box__3";
		try {

			driver.findElement(By.id("login")).clear();

		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("authentication", "id", "login");
			String xpathExpression = "//*[@id='" + idValue + "']";
			driver.findElement(By.xpath(xpathExpression)).clear();
		}

		try {

			driver.findElement(By.name("login")).sendKeys("admin");

		} catch (NoSuchElementException e) {
			String nameValue = repairerObj.repair("authentication", "name", "login");
			String xpathExpression = "//*[@name='" + nameValue + "']";
			driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
		}

		try {

			driver.findElement(By.id("password")).clear();

		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("authentication", "id", "password");
			String xpathExpression = "//*[@id='" + idValue + "']";
			driver.findElement(By.xpath(xpathExpression)).clear();
		}

		try {

			driver.findElement(By.name("password")).sendKeys("admin");

		} catch (NoSuchElementException e) {
			String nameValue = repairerObj.repair("authentication", "name", "password");
			String xpathExpression = "//*[@name='" + nameValue + "']";
			driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
		}

		try {

			driver.findElement(By.xpath("//*[@id=\"loginBox\"]/form/fieldset/button")).click();

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("authentication", "text", "Enter");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();
		}

		try {

			driver.findElement(By.xpath("//*[@id=\"userBannerLeft\"]/ul/li[2]/span/a")).click();
			flag = 1;
		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("admin", "text", "My messages");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();
			flag = 2;
		}


		try {

			driver.findElement(By.xpath("//*[@id=\"trashbox\"]")).click();

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("messagebox", "text", "trashbox");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();
		}
		try {

			driver.findElement(By.name("search")).sendKeys("Hello");

		} catch (NoSuchElementException e) {
			String nameValue = repairerObj.repair("messagebox", "name", "search");
			String xpathExpression = "//*[@name='" + nameValue + "']";
			driver.findElement(By.xpath(xpathExpression)).sendKeys("Hello");
		}
		try {

			WebElement ele = driver.findElement(By.xpath("//*[@id=\"claroBody\"]/div[3]/div/form/input[2]"));//click on search
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", ele);

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("messagebox", "value", "Search");
			String xpathExpression = "//input[@value='" + new_value + "']";
			WebElement ele = driver.findElement(By.xpath(xpathExpression));
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", ele);
		}
//		driver.findElement(By.xpath("//*[@id=\"claroBody\"]/table/tbody/tr[1]/td[4]/a")).click();	
//		Alert alert = driver.switchTo().alert();
//        alert.accept();
		try {

			Assert.assertTrue(driver.findElement(By.cssSelector("BODY")).getText()
					.matches("^[\\s\\S]*" + "Empty trashbox" + "[\\s\\S]*$"));
		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("authentication", "id", "claroBody");
			String xpathExpression = "//*[@id='" + idValue + "']";
			AssertJUnit.assertEquals(driver.findElement(By.xpath(xpathExpression)).getText(), "Empty trashbox");

		}
		try {
			driver.findElements(By.xpath("//*[@id=\"userBannerRight\"]/ul/li[3]/span/a")).get(0).click(); // click on
																											// logout

		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("authentication", "id", "userBannerRight");
			String xpathExpression = "//*[@id='" + idValue + "']";
			driver.findElements(By.xpath(xpathExpression)).get(0).click();
		}
	}

	@Test(priority =4 ,groups= "regression")
	public void messages_course__1()throws Exception
	{
		currrent_test="messages_course__1";
		try {

			driver.findElement(By.id("login")).clear();

		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("authentication", "id", "login");
			String xpathExpression = "//*[@id='" + idValue + "']";
			driver.findElement(By.xpath(xpathExpression)).clear();
		}

		try {

			driver.findElement(By.name("login")).sendKeys("admin");

		} catch (NoSuchElementException e) {
			String nameValue = repairerObj.repair("authentication", "name", "login");
			String xpathExpression = "//*[@name='" + nameValue + "']";
			driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
		}

		try {

			driver.findElement(By.id("password")).clear();

		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("authentication", "id", "password");
			String xpathExpression = "//*[@id='" + idValue + "']";
			driver.findElement(By.xpath(xpathExpression)).clear();
		}

		try {

			driver.findElement(By.name("password")).sendKeys("admin");

		} catch (NoSuchElementException e) {
			String nameValue = repairerObj.repair("authentication", "name", "password");
			String xpathExpression = "//*[@name='" + nameValue + "']";
			driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
		}

		try {

			driver.findElement(By.xpath("//*[@id=\"loginBox\"]/form/fieldset/button")).click();

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("authentication", "text", "Enter");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();
		}

		try {

			driver.findElement(By.xpath("//*[@id=\"userBannerLeft\"]/ul/li[2]/span/a")).click();
			flag = 1;
		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("admin", "text", "My messages");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();
			flag = 2;
		}


		try {

			driver.findElement(By.xpath("//*[@id=\"trashbox\"]")).click();

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("messagebox", "text", "trashbox");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();
		}
		try {

			driver.findElement(By.xpath("//*[@id=\"claroBody\"]/span/a")).click();

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("messagebox", "value", "Empty trashbox");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();
		}
		
			
		Alert alert = driver.switchTo().alert();
        alert.accept();
    
		try {

			Assert.assertTrue(driver.findElement(By.cssSelector("BODY")).getText()
					.matches("^[\\s\\S]*" + "No message" + "[\\s\\S]*$"));
		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("authentication", "id", "claroBody");
			String xpathExpression = "//*[@id='" + idValue + "']";
			AssertJUnit.assertEquals(driver.findElement(By.xpath(xpathExpression)).getText(), "No message");

		}
		try {
			driver.findElements(By.xpath("//*[@id=\"userBannerRight\"]/ul/li[3]/span/a")).get(0).click(); // click on
																											// logout

		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("authentication", "id", "userBannerRight");
			String xpathExpression = "//*[@id='" + idValue + "']";
			driver.findElements(By.xpath(xpathExpression)).get(0).click();
		}
	}
	
}
