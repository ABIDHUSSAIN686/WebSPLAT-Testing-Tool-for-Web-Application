
import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.AssertJUnit;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import com.example.demo.Repairer;


public class miniSuite  {
	protected static WebDriver  driver;
	protected WebDriverWait wait;
	protected static JavascriptExecutor js;
	protected static Repairer repairerObj;
	protected boolean acceptNextAlert = true;
	protected StringBuffer verificationErrors = new StringBuffer();
	protected JavascriptExecutor jse;
	
	
	@BeforeSuite
	public static void invokeBrowser()
	{
		
		System.setProperty("webdriver.chrome.driver", "F:\\eclipes_workspace3\\fyp2\\chromedriver.exe");
		driver = new ChromeDriver();   									//for Chrome driver
		driver.manage().deleteAllCookies(); 							 //deleteitng all cookies
		driver.manage().window().maximize();  							 //screen maxmixing
		driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS);   //setting timout
		driver.manage().timeouts().pageLoadTimeout(5, TimeUnit.SECONDS);
	//	driver.get("http://localhost/parent/claroline/index.php?logout=true");    //base
		driver.get("http://localhost/parent3/vtwo/index.php?logout=true");    //new
		repairerObj = new Repairer();
		js = (JavascriptExecutor)driver;
		System.out.println("x");
		
	}
	
	
	@Test(priority = 1, groups = "regression")
	public void attribute_Text() throws Exception, NoSuchElementException {
		driver.findElement(By.id("login")).clear();
		driver.findElement(By.id("login")).sendKeys("admin");
		driver.findElement(By.id("password")).clear();
		driver.findElement(By.id("password")).sendKeys("admin");
		driver.findElement(By.xpath("//*[@id=\"loginBox\"]/form/fieldset/button")).click();
		driver.findElement(By.xpath("//*[@id=\"userBannerLeft\"]/ul/li[3]/span/a")).click(); // click on Platform
		driver.findElement(By.linkText("Manage course categories")).click(); // click on manage course category
	}
	
	@Test(priority = 1, groups = "regression")
		public void attribute_Text_repaired() throws Exception, NoSuchElementException {
			driver.findElement(By.id("login")).clear();
			driver.findElement(By.id("login")).sendKeys("admin");
			driver.findElement(By.id("password")).clear();
			driver.findElement(By.id("password")).sendKeys("admin");
			driver.findElement(By.xpath("//*[@id=\"loginBox\"]/form/fieldset/button")).click();
			driver.findElement(By.xpath("//*[@id=\"userBannerLeft\"]/ul/li[3]/span/a")).click(); // click on Platform																					// administration
			try {

				driver.findElement(By.linkText("Manage course categories")).click(); // click on manage course category
			
			} catch (NoSuchElementException e) {
				driver.findElement(By.xpath("//a[contains(text(),'" + repairerObj.repair("admin", "text", "Manage course categories") + "')]")).click();

			}

					}
	@Test(priority = 1, groups = "regression")
	public void attribute_ID() throws Exception, NoSuchElementException {
		driver.findElement(By.id("login")).clear();
		driver.findElement(By.id("login")).sendKeys("admin");
		driver.findElement(By.id("password")).clear();
		driver.findElement(By.id("password")).sendKeys("admin");
		driver.findElement(By.xpath("//*[@id=\"loginBox\"]/form/fieldset/button")).click();
		driver.findElement(By.xpath("//*[@id=\"userBannerLeft\"]/ul/li[3]/span/a")).click(); // click on Platform																					// administration
		driver.findElement(By.xpath("//*[@id=\"claroBody\"]/ul/li[2]/ul/li[2]/a")).click(); // click on Course list
		driver.findElement(By.id("search")).sendKeys("Data Structure"); // search course e.g Data Structure
		driver.findElement(By.xpath("//*[@id=\"claroBody\"]/table[1]/tbody/tr/td/form/input[2]")).click(); // click Ok
		driver.findElement(By.xpath("//*[@id=\"claroBody\"]/table[2]/tbody/tr/td[2]/a/b")).click(); // click name
	}
	
	@Test(priority = 1, groups = "regression")
		public void attribute_ID_repaired() throws Exception, NoSuchElementException {
			driver.findElement(By.id("login")).clear();
			driver.findElement(By.id("login")).sendKeys("admin");
			driver.findElement(By.id("password")).clear();
			driver.findElement(By.id("password")).sendKeys("admin");
			driver.findElement(By.xpath("//*[@id=\"loginBox\"]/form/fieldset/button")).click();
			driver.findElement(By.xpath("//*[@id=\"userBannerLeft\"]/ul/li[3]/span/a")).click(); // click on Platform																						// administration
			driver.findElement(By.xpath("//a[contains(text(),'" + repairerObj.repair("admin", "text", "User list") + "')]")).click();
			try {

				driver.findElement(By.id("search")).sendKeys("Data Structure"); // search course e.g Data Structure

			} catch (NoSuchElementException e) {
				driver.findElement(By.xpath("//*[@id='" + repairerObj.repair_mini("course_search_v1.html.txt", "id", "search") + "']")).sendKeys("Data Structure");
			}
			driver.findElement(By.xpath("//*[@id=\"claroBody\"]/table[1]/tbody/tr/td/form/input[2]")).click(); // click Ok
			driver.findElement(By.xpath("//*[@id=\"claroBody\"]/table[2]/tbody/tr/td[2]/a/b")).click(); // click name
		}
	
	@Test(priority = 1, groups = "regression")
	public void attribute_Name() throws Exception, NoSuchElementException {
		driver.findElement(By.id("login")).clear();
		driver.findElement(By.id("login")).sendKeys("admin");
		driver.findElement(By.id("password")).clear();
		driver.findElement(By.id("password")).sendKeys("admin");
		driver.findElement(By.xpath("//*[@id=\"loginBox\"]/form/fieldset/button")).click();
		driver.findElement(By.xpath("//*[@id=\"userBannerLeft\"]/ul/li[3]/span/a")).click(); // click on Platform																					// administration
		driver.findElement(By.xpath("//*[@id=\"claroBody\"]/ul/li[1]/ul/li[2]/a")).click(); // click on Course list
		driver.findElement(By.name("search")).sendKeys("aqeel"); // search user e.g aqeel
		driver.findElement(By.xpath("//*[@id=\"claroBody\"]/table[1]/tbody/tr[1]/td/form/input[2]")).click(); // click ok
		driver.findElement(By.xpath("//*[@id=\"claroBody\"]/table[2]/tbody/tr[1]/td[7]/a/img")).click(); // click user setting
	}
	@Test(priority = 1, groups = "regression")
	public void attribute_Name_repaired() throws Exception, NoSuchElementException {
		driver.findElement(By.id("login")).clear();
		driver.findElement(By.id("login")).sendKeys("admin");
		driver.findElement(By.id("password")).clear();
		driver.findElement(By.id("password")).sendKeys("admin");
		driver.findElement(By.xpath("//*[@id=\"loginBox\"]/form/fieldset/button")).click();
		driver.findElement(By.xpath("//*[@id=\"userBannerLeft\"]/ul/li[3]/span/a")).click(); // click on Platform
		driver.findElement(By.xpath("//a[contains(text(),'" + repairerObj.repair("admin", "text", "User list") + "')]")).click();
		try {

			driver.findElement(By.name("search")).sendKeys("aqeel"); // search user e.g aqeel

		} catch (NoSuchElementException e) {
			driver.findElement(By.xpath("//*[@name='" + repairerObj.repair_mini("user_search_v1.html.txt", "name", "search") + "']")).sendKeys("aqeel");
		}
		driver.findElement(By.xpath("//*[@id=\"claroBody\"]/table[1]/tbody/tr[1]/td/form/input[2]")).click(); // click ok 
		driver.findElement(By.xpath("//*[@id=\"claroBody\"]/table[2]/tbody/tr[1]/td[7]/a/img")).click(); // click user settings
	}
	
	@Test(priority = 1, groups = "regression")
	public void attribute_Class() throws Exception, NoSuchElementException {
		driver.findElement(By.id("login")).clear();
		driver.findElement(By.id("login")).sendKeys("admin");
		driver.findElement(By.id("password")).clear();
		driver.findElement(By.id("password")).sendKeys("admin");
		driver.findElement(By.xpath("//*[@id=\"loginBox\"]/form/fieldset/button")).click();
		driver.findElement(By.xpath("//*[@id=\"userBannerLeft\"]/ul/li[3]/span/a")).click(); // click on Platform																					// administration
		driver.findElement(By.xpath("//*[@id=\"claroBody\"]/ul/li[1]/ul/li[2]/a")).click(); // click on Course list
		driver.findElement(By.className("claroCmd")).click(); // click of advance
	}
	@Test(priority = 1, groups = "regression")
	public void attribute_Class_repaired() throws Exception, NoSuchElementException {
		driver.findElement(By.id("login")).clear();
		driver.findElement(By.id("login")).sendKeys("admin");
		driver.findElement(By.id("password")).clear();
		driver.findElement(By.id("password")).sendKeys("admin");
		driver.findElement(By.xpath("//*[@id=\"loginBox\"]/form/fieldset/button")).click();
		driver.findElement(By.xpath("//*[@id=\"userBannerLeft\"]/ul/li[3]/span/a")).click(); // click on Platform
		driver.findElement(By.xpath("//a[contains(text(),'" + repairerObj.repair("admin", "text", "User list") + "')]")).click();
		try {

			driver.findElement(By.className("claroCmd")).click(); // click of advance

		} catch (NoSuchElementException e) {
			driver.findElement(By.xpath("//*[@class='" + repairerObj.repair_mini("user_search_v1.html.txt", "class", "claroCmd") + "']")).click();
		}
	
	}
	
	
	
	@Test(priority = 1, groups = "regression")
	public void attribute_Href() throws Exception, NoSuchElementException {
		driver.findElement(By.id("login")).clear();
		driver.findElement(By.id("login")).sendKeys("admin");
		driver.findElement(By.id("password")).clear();
		driver.findElement(By.id("password")).sendKeys("admin");
		driver.findElement(By.xpath("//*[@id=\"loginBox\"]/form/fieldset/button")).click();
		driver.findElement(By.xpath("//*[@href='/parent/claroline/claroline/admin/']")).click(); // click on Platform
	}
	@Test(priority = 1, groups = "regression")
	public void attribute_Href_repaired() throws Exception, NoSuchElementException {
		driver.findElement(By.id("login")).clear();
		driver.findElement(By.id("login")).sendKeys("admin");
		driver.findElement(By.id("password")).clear();
		driver.findElement(By.id("password")).sendKeys("admin");
		driver.findElement(By.xpath("//*[@id=\"loginBox\"]/form/fieldset/button")).click();
		try {

			driver.findElement(By.xpath("//*[@href='/parent/claroline/claroline/admin/']")).click(); // click on Platform

		} catch (NoSuchElementException e) {
			driver.findElement(By.xpath("//*[@href='" + repairerObj.repair_mini("user_search_v1.html.txt", "href", "/parent/claroline/claroline/admin/") + "']")).click();
		}
	
	}
	
	@Test(priority = 1, groups = "regression")
	public void attribute_Alt() throws Exception, NoSuchElementException {
		driver.findElement(By.id("login")).clear();
		driver.findElement(By.id("login")).sendKeys("admin");
		driver.findElement(By.id("password")).clear();
		driver.findElement(By.id("password")).sendKeys("admin");
		driver.findElement(By.xpath("//*[@id=\"loginBox\"]/form/fieldset/button")).click();
		driver.findElement(By.xpath("//*[@href='/parent/claroline/claroline/admin/']")).click(); // click on Platform
	}
	@Test(priority = 1, groups = "regression")
	public void attribute_Alt_repaired() throws Exception, NoSuchElementException {
		driver.findElement(By.id("login")).clear();
		driver.findElement(By.id("login")).sendKeys("admin");
		driver.findElement(By.id("password")).clear();
		driver.findElement(By.id("password")).sendKeys("admin");
		driver.findElement(By.xpath("//*[@id=\"loginBox\"]/form/fieldset/button")).click();
		try {

			driver.findElement(By.xpath("//*[@href='/parent/claroline/claroline/admin/']")).click(); // click on Platform

		} catch (NoSuchElementException e) {
			driver.findElement(By.xpath("//*[@href='" + repairerObj.repair_mini("user_search_v1.html.txt", "href", "/parent/claroline/claroline/admin/") + "']")).click();
		}
	
	}

}
