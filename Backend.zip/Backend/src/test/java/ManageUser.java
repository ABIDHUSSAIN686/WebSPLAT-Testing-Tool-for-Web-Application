

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.testng.AssertJUnit;
import org.testng.annotations.Test;

	public class ManageUser extends DriverIntializor {

		@Test(priority =1 ,groups= "regression")
		public void authentication__2()throws Exception  //login
		{
			currrent_test="authentication__2";
			 try {

					driver.findElement(By.id("login")).clear();

				} catch (NoSuchElementException e) {
					String idValue = repairerObj.repair("authentication", "id", "login");
					String xpathExpression = "//*[@id='" + idValue + "']";
					driver.findElement(By.xpath(xpathExpression)).clear();
				}
			
				try {

					driver.findElement(By.name("login")).sendKeys("admin");

				} catch (NoSuchElementException e) {
					String nameValue = repairerObj.repair("authentication", "name", "login");
					String xpathExpression = "//*[@name='" + nameValue + "']";
					driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
				}

				try {

					driver.findElement(By.id("password")).clear();

				} catch (NoSuchElementException e) {
					String idValue = repairerObj.repair("authentication", "id", "password");
					String xpathExpression = "//*[@id='" + idValue + "']";
					driver.findElement(By.xpath(xpathExpression)).clear();
				}

				try {

					driver.findElement(By.name("password")).sendKeys("admin");

				} catch (NoSuchElementException e) {
					String nameValue = repairerObj.repair("authentication", "name", "password");
					String xpathExpression = "//*[@name='" + nameValue + "']";
					driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
				}

				try {

					driver.findElement(By.xpath("//*[@id=\"loginBox\"]/form/fieldset/button")).click();

				} catch (NoSuchElementException e) {
					String new_value = repairerObj.repair("authentication", "text", "Enter");
					String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
					driver.findElement(By.xpath(xpathExpression)).click();
				}

		
			 try {

					Assert.assertTrue(driver.findElement(By.cssSelector("BODY")).getText()
							.matches("^[\\s\\S]*" + "Manage my courses" + "[\\s\\S]*$"));
				} catch (NoSuchElementException e) {
					String idValue = repairerObj.repair("authentication", "id", "claroBody");
					String xpathExpression = "//*[@id='" + idValue + "']";
					AssertJUnit.assertEquals(driver.findElement(By.xpath(xpathExpression)).getText(), "Manage my courses");

				}
				try {
					driver.findElements(By.xpath("//*[@id=\"userBannerRight\"]/ul/li[3]/span/a")).get(0).click(); // click on
																													// logout

				} catch (NoSuchElementException e) {
					String idValue = repairerObj.repair("authentication", "id", "userBannerRight");
					String xpathExpression = "//*[@id='" + idValue + "']";
					driver.findElements(By.xpath(xpathExpression)).get(0).click();
				}
				flag = 1;
		}
		
		@Test(priority =2 ,groups= "regression")
		public void user_Report__1()throws Exception //logout
		{
			currrent_test="user_Report__1";
			try {

				driver.findElement(By.id("login")).clear();

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("authentication", "id", "login");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElement(By.xpath(xpathExpression)).clear();
			}

			try {

				driver.findElement(By.name("login")).sendKeys("admin");

			} catch (NoSuchElementException e) {
				String nameValue = repairerObj.repair("authentication", "name", "login");
				String xpathExpression = "//*[@name='" + nameValue + "']";
				driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
			}

			try {

				driver.findElement(By.id("password")).clear();

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("authentication", "id", "password");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElement(By.xpath(xpathExpression)).clear();
			}

			try {

				driver.findElement(By.name("password")).sendKeys("admin");

			} catch (NoSuchElementException e) {
				String nameValue = repairerObj.repair("authentication", "name", "password");
				String xpathExpression = "//*[@name='" + nameValue + "']";
				driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
			}

			try {

				driver.findElement(By.xpath("//*[@id=\"loginBox\"]/form/fieldset/button")).click();

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("authentication", "text", "Enter");
				String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
				driver.findElement(By.xpath(xpathExpression)).click();
			}

			try {
				driver.findElements(By.xpath("//*[@id=\"userBannerRight\"]/ul/li[3]/span/a")).get(0).click(); // click on
																												// logout

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("authentication", "id", "userBannerRight");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElements(By.xpath(xpathExpression)).get(0).click();
			}
		 try {

				Assert.assertTrue(driver.findElement(By.cssSelector("BODY")).getText()
						.matches("^[\\s\\S]*" + "Authentication" + "[\\s\\S]*$"));
			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("authentication", "id", "claroBody");
				String xpathExpression = "//*[@id='" + idValue + "']";
				AssertJUnit.assertEquals(driver.findElement(By.xpath(xpathExpression)).getText(), "Authentication");

			}
			
		 flag = 1;
		}
		
		@Test(priority =3 ,groups= "regression")
		public void user__1 ()throws Exception
		{
			currrent_test="user__1";
			try {

				driver.findElement(By.id("login")).clear();

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("authentication", "id", "login");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElement(By.xpath(xpathExpression)).clear();
			}

			try {

				driver.findElement(By.name("login")).sendKeys("admin");

			} catch (NoSuchElementException e) {
				String nameValue = repairerObj.repair("authentication", "name", "login");
				String xpathExpression = "//*[@name='" + nameValue + "']";
				driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
			}

			try {

				driver.findElement(By.id("password")).clear();

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("authentication", "id", "password");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElement(By.xpath(xpathExpression)).clear();
			}

			try {

				driver.findElement(By.name("password")).sendKeys("admin");

			} catch (NoSuchElementException e) {
				String nameValue = repairerObj.repair("authentication", "name", "password");
				String xpathExpression = "//*[@name='" + nameValue + "']";
				driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
			}

			try {

				driver.findElement(By.xpath("//*[@id=\"loginBox\"]/form/fieldset/button")).click();

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("authentication", "text", "Enter");
				String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
				driver.findElement(By.xpath(xpathExpression)).click();
			}

			try {

				driver.findElement(By.xpath("//*[@id=\"userBannerLeft\"]/ul/li[3]/span/a")).click();

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("admin", "text", "Platform administration");
				String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
				driver.findElement(By.xpath(xpathExpression)).click();
			}

			try {

				driver.findElement(By.xpath("//*[@id=\"claroBody\"]/ul/li[1]/ul/li[4]/a")).click();   //click on create user
				flag = 1;																			

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("admin", "text", "Create user");
				String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
				driver.findElement(By.xpath(xpathExpression)).click();
				flag = 2;
			}

			 try {

				    driver.findElement(By.id("firstname")).clear();        //clear the field

				} catch (NoSuchElementException e) {
					String idValue = repairerObj.repair("adminaddnewuser", "id", "firstname");
					String xpathExpression = "//*[@id='" + idValue + "']";
					driver.findElement(By.xpath(xpathExpression)).clear();
				}

				try {

				    driver.findElement(By.id("firstname")).sendKeys("Abid"); //set the value

				} catch (NoSuchElementException e) {
					String Value = repairerObj.repair("adminaddnewuser", "id", "firstname");
					String xpathExpression = "//*[@id='" + Value + "']";
					driver.findElement(By.xpath(xpathExpression)).sendKeys("Abid");
				}
				
		    try {

			    driver.findElement(By.id("lastname")).clear();        //clear the field

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("adminaddnewuser", "id", "lastname");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElement(By.xpath(xpathExpression)).clear();
			}

			try {

			    driver.findElement(By.id("lastname")).sendKeys("Hussain"); //set the value

			} catch (NoSuchElementException e) {
				String Value = repairerObj.repair("adminaddnewuser", "id", "lastname");
				String xpathExpression = "//*[@id='" + Value + "']";
				driver.findElement(By.xpath(xpathExpression)).sendKeys("Hussain");
			}
		    try {

			    driver.findElement(By.id("officialCode")).clear();        //clear the field

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("adminaddnewuser", "id", "officialCode");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElement(By.xpath(xpathExpression)).clear();
			}

			try {

			    driver.findElement(By.id("officialCode")).sendKeys("1234"); //set the value

			} catch (NoSuchElementException e) {
				String Value = repairerObj.repair("adminaddnewuser", "id", "officialCode");
				String xpathExpression = "//*[@id='" + Value + "']";
				driver.findElement(By.xpath(xpathExpression)).sendKeys("1234");
			}
		    try {

			    driver.findElement(By.id("username")).clear();        //clear the field

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("adminaddnewuser", "id", "username");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElement(By.xpath(xpathExpression)).clear();
			}

			try {

			    driver.findElement(By.id("username")).sendKeys("nam"); //set the value

			} catch (NoSuchElementException e) {
				String Value = repairerObj.repair("adminaddnewuser", "id", "username");
				String xpathExpression = "//*[@id='" + Value + "']";
				driver.findElement(By.xpath(xpathExpression)).sendKeys("nam");
			}
		    try {

			    driver.findElement(By.id("username")).clear();        //clear the field

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("adminaddnewuser", "id", "username");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElement(By.xpath(xpathExpression)).clear();
			}

			try {

			    driver.findElement(By.id("username")).sendKeys("abid"); //set the value

			} catch (NoSuchElementException e) {
				String Value = repairerObj.repair("adminaddnewuser", "id", "username");
				String xpathExpression = "//*[@id='" + Value + "']";
				driver.findElement(By.xpath(xpathExpression)).sendKeys("abid");
			}
		    try {

			    driver.findElement(By.id("password")).clear();        //clear the field

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("adminaddnewuser", "id", "password");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElement(By.xpath(xpathExpression)).clear();
			}

			try {

			    driver.findElement(By.id("password")).sendKeys("123456"); //set the value

			} catch (NoSuchElementException e) {
				String Value = repairerObj.repair("adminaddnewuser", "id", "password");
				String xpathExpression = "//*[@id='" + Value + "']";
				driver.findElement(By.xpath(xpathExpression)).sendKeys("123456");
			}
		    try {

			    driver.findElement(By.id("password_conf")).clear();        //clear the field

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("adminaddnewuser", "id", "password_conf");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElement(By.xpath(xpathExpression)).clear();
			}

			try {

			    driver.findElement(By.id("password_conf")).sendKeys("123456"); //set the value

			} catch (NoSuchElementException e) {
				String Value = repairerObj.repair("adminaddnewuser", "id", "password_conf");
				String xpathExpression = "//*[@id='" + Value + "']";
				driver.findElement(By.xpath(xpathExpression)).sendKeys("123456");
			}
		  
		    try {

				WebElement ele = driver.findElement(By.id("student"));
				JavascriptExecutor executor = (JavascriptExecutor) driver;
				executor.executeScript("arguments[0].click();", ele);

			} catch (NoSuchElementException e) {
				String nameValue = repairerObj.repair("adminaddnewuser", "id", "student");
				String xpathExpression = "//*[@id='" + nameValue + "']";
				WebElement ele = driver.findElement(By.xpath(xpathExpression));
				JavascriptExecutor executor = (JavascriptExecutor) driver;
				executor.executeScript("arguments[0].click();", ele);
			}

		    try {

				WebElement ele = driver.findElement(By.id("applyChange"));
				JavascriptExecutor executor = (JavascriptExecutor) driver;
				executor.executeScript("arguments[0].click();", ele);

			} catch (NoSuchElementException e) {
				String nameValue = repairerObj.repair("adminaddnewuser", "id", "applyChange");
				String xpathExpression = "//*[@id='" + nameValue + "']";
				WebElement ele = driver.findElement(By.xpath(xpathExpression));
				JavascriptExecutor executor = (JavascriptExecutor) driver;
				executor.executeScript("arguments[0].click();", ele);
			}
		    try {

				Assert.assertTrue(driver.findElement(By.cssSelector("BODY")).getText()
						.matches("^[\\s\\S]*" + "The new user has been sucessfully created" + "[\\s\\S]*$"));
			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("authentication", "id", "claroBody");
				String xpathExpression = "//*[@id='" + idValue + "']";
				AssertJUnit.assertEquals(driver.findElement(By.xpath(xpathExpression)).getText(), "The new user has been sucessfully created");

			}
			try {
				driver.findElements(By.xpath("//*[@id=\"userBannerRight\"]/ul/li[3]/span/a")).get(0).click(); // click on
																												// logout

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("authentication", "id", "userBannerRight");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElements(By.xpath(xpathExpression)).get(0).click();
			}
		  
		}
		
		@Test(priority =4 ,groups= "regression")
		public void admin_user_courses__1()throws Exception
		{
			currrent_test="admin_user_courses__1";
			
			try {

				driver.findElement(By.id("login")).clear();

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("authentication", "id", "login");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElement(By.xpath(xpathExpression)).clear();
			}

			try {

				driver.findElement(By.name("login")).sendKeys("admin");

			} catch (NoSuchElementException e) {
				String nameValue = repairerObj.repair("authentication", "name", "login");
				String xpathExpression = "//*[@name='" + nameValue + "']";
				driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
			}

			try {

				driver.findElement(By.id("password")).clear();

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("authentication", "id", "password");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElement(By.xpath(xpathExpression)).clear();
			}

			try {

				driver.findElement(By.name("password")).sendKeys("admin");

			} catch (NoSuchElementException e) {
				String nameValue = repairerObj.repair("authentication", "name", "password");
				String xpathExpression = "//*[@name='" + nameValue + "']";
				driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
			}

			try {

				driver.findElement(By.xpath("//*[@id=\"loginBox\"]/form/fieldset/button")).click();

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("authentication", "text", "Enter");
				String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
				driver.findElement(By.xpath(xpathExpression)).click();
			}

			try {

				driver.findElement(By.xpath("//*[@id=\"userBannerLeft\"]/ul/li[3]/span/a")).click();

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("admin", "text", "Platform administration");
				String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
				driver.findElement(By.xpath(xpathExpression)).click();
			}

			try {

				driver.findElement(By.xpath("//*[@id=\"claroBody\"]/ul/li[1]/ul/li[4]/a")).click();   //click on create user
																									
				flag = 1;
			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("admin", "text", "Create user");
				String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
				driver.findElement(By.xpath(xpathExpression)).click();
				flag = 2;
			}
			try {
				driver.findElements(By.xpath("//*[@id=\"userBannerRight\"]/ul/li[3]/span/a")).get(0).click(); // click on
																												// logout

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("authentication", "id", "userBannerRight");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElements(By.xpath(xpathExpression)).get(0).click();
			}
		 try {

				Assert.assertTrue(driver.findElement(By.cssSelector("BODY")).getText()
						.matches("^[\\s\\S]*" + "Authentication" + "[\\s\\S]*$"));
			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("authentication", "id", "claroBody");
				String xpathExpression = "//*[@id='" + idValue + "']";
				AssertJUnit.assertEquals(driver.findElement(By.xpath(xpathExpression)).getText(), "authenticationentication");

			}
			
		}
		
		
		@Test(priority =7 ,groups= "regression")
		public void user__2 ()throws Exception
		{
			currrent_test="user__2";
			try {

				driver.findElement(By.id("login")).clear();

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("authentication", "id", "login");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElement(By.xpath(xpathExpression)).clear();
			}

			try {

				driver.findElement(By.name("login")).sendKeys("admin");

			} catch (NoSuchElementException e) {
				String nameValue = repairerObj.repair("authentication", "name", "login");
				String xpathExpression = "//*[@name='" + nameValue + "']";
				driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
			}

			try {

				driver.findElement(By.id("password")).clear();

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("authentication", "id", "password");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElement(By.xpath(xpathExpression)).clear();
			}

			try {

				driver.findElement(By.name("password")).sendKeys("admin");

			} catch (NoSuchElementException e) {
				String nameValue = repairerObj.repair("authentication", "name", "password");
				String xpathExpression = "//*[@name='" + nameValue + "']";
				driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
			}

			try {

				driver.findElement(By.xpath("//*[@id=\"loginBox\"]/form/fieldset/button")).click();

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("authentication", "text", "Enter");
				String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
				driver.findElement(By.xpath(xpathExpression)).click();
			}

			try {

				driver.findElement(By.xpath("//*[@id=\"userBannerLeft\"]/ul/li[3]/span/a")).click();

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("admin", "text", "Platform administration");
				String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
				driver.findElement(By.xpath(xpathExpression)).click();
			}

			try {

				driver.findElement(By.xpath("//*[@id=\"claroBody\"]/ul/li[1]/ul/li[4]/a")).click();   //click on create user
				flag = 1;																				

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("admin", "text", "Create user");
				String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
				driver.findElement(By.xpath(xpathExpression)).click();
				flag = 2;
			}

			 try {

				    driver.findElement(By.id("firstname")).clear();        //clear the field

				} catch (NoSuchElementException e) {
					String idValue = repairerObj.repair("adminaddnewuser", "id", "firstname");
					String xpathExpression = "//*[@id='" + idValue + "']";
					driver.findElement(By.xpath(xpathExpression)).clear();
				}

				try {

				    driver.findElement(By.id("firstname")).sendKeys("Abid"); //set the value

				} catch (NoSuchElementException e) {
					String Value = repairerObj.repair("adminaddnewuser", "id", "firstname");
					String xpathExpression = "//*[@id='" + Value + "']";
					driver.findElement(By.xpath(xpathExpression)).sendKeys("Abid");
				}
				
		    try {

			    driver.findElement(By.id("lastname")).clear();        //clear the field

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("adminaddnewuser", "id", "lastname");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElement(By.xpath(xpathExpression)).clear();
			}

			try {

			    driver.findElement(By.id("lastname")).sendKeys("Hussain"); //set the value

			} catch (NoSuchElementException e) {
				String Value = repairerObj.repair("adminaddnewuser", "id", "lastname");
				String xpathExpression = "//*[@id='" + Value + "']";
				driver.findElement(By.xpath(xpathExpression)).sendKeys("Hussain");
			}
		    try {

			    driver.findElement(By.id("officialCode")).clear();        //clear the field

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("adminaddnewuser", "id", "officialCode");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElement(By.xpath(xpathExpression)).clear();
			}

			try {

			    driver.findElement(By.id("officialCode")).sendKeys("1234"); //set the value

			} catch (NoSuchElementException e) {
				String Value = repairerObj.repair("adminaddnewuser", "id", "officialCode");
				String xpathExpression = "//*[@id='" + Value + "']";
				driver.findElement(By.xpath(xpathExpression)).sendKeys("1234");
			}
		    try {

			    driver.findElement(By.id("username")).clear();        //clear the field

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("adminaddnewuser", "id", "username");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElement(By.xpath(xpathExpression)).clear();
			}

			try {

			    driver.findElement(By.id("username")).sendKeys("nam"); //set the value

			} catch (NoSuchElementException e) {
				String Value = repairerObj.repair("adminaddnewuser", "id", "username");
				String xpathExpression = "//*[@id='" + Value + "']";
				driver.findElement(By.xpath(xpathExpression)).sendKeys("nam");
			}
		    try {

			    driver.findElement(By.id("username")).clear();        //clear the field

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("adminaddnewuser", "id", "username");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElement(By.xpath(xpathExpression)).clear();
			}

			try {

			    driver.findElement(By.id("username")).sendKeys("abid"); //set the value

			} catch (NoSuchElementException e) {
				String Value = repairerObj.repair("adminaddnewuser", "id", "username");
				String xpathExpression = "//*[@id='" + Value + "']";
				driver.findElement(By.xpath(xpathExpression)).sendKeys("abid");
			}
		    try {

			    driver.findElement(By.id("password")).clear();        //clear the field

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("adminaddnewuser", "id", "password");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElement(By.xpath(xpathExpression)).clear();
			}

			try {

			    driver.findElement(By.id("password")).sendKeys("123456"); //set the value

			} catch (NoSuchElementException e) {
				String Value = repairerObj.repair("adminaddnewuser", "id", "password");
				String xpathExpression = "//*[@id='" + Value + "']";
				driver.findElement(By.xpath(xpathExpression)).sendKeys("123456");
			}
		    try {

			    driver.findElement(By.id("password_conf")).clear();        //clear the field

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("adminaddnewuser", "id", "password_conf");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElement(By.xpath(xpathExpression)).clear();
			}

			try {

			    driver.findElement(By.id("password_conf")).sendKeys("123456"); //set the value

			} catch (NoSuchElementException e) {
				String Value = repairerObj.repair("adminaddnewuser", "id", "password_conf");
				String xpathExpression = "//*[@id='" + Value + "']";
				driver.findElement(By.xpath(xpathExpression)).sendKeys("123456");
			}
		  
		    try {

				WebElement ele = driver.findElement(By.id("student"));
				JavascriptExecutor executor = (JavascriptExecutor) driver;
				executor.executeScript("arguments[0].click();", ele);

			} catch (NoSuchElementException e) {
				String nameValue = repairerObj.repair("adminaddnewuser", "id", "student");
				String xpathExpression = "//*[@id='" + nameValue + "']";
				WebElement ele = driver.findElement(By.xpath(xpathExpression));
				JavascriptExecutor executor = (JavascriptExecutor) driver;
				executor.executeScript("arguments[0].click();", ele);
			}

		    try {

				WebElement ele = driver.findElement(By.id("applyChange"));
				JavascriptExecutor executor = (JavascriptExecutor) driver;
				executor.executeScript("arguments[0].click();", ele);

			} catch (NoSuchElementException e) {
				String nameValue = repairerObj.repair("adminaddnewuser", "id", "applyChange");
				String xpathExpression = "//*[@id='" + nameValue + "']";
				WebElement ele = driver.findElement(By.xpath(xpathExpression));
				JavascriptExecutor executor = (JavascriptExecutor) driver;
				executor.executeScript("arguments[0].click();", ele);
			}
		    try {

				Assert.assertTrue(driver.findElement(By.cssSelector("BODY")).getText()
						.matches("^[\\s\\S]*" + "This username is already taken" + "[\\s\\S]*$"));
			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("authentication", "id", "claroBody");
				String xpathExpression = "//*[@id='" + idValue + "']";
				AssertJUnit.assertEquals(driver.findElement(By.xpath(xpathExpression)).getText(), "This username is already taken");

			}
			try {
				driver.findElements(By.xpath("//*[@id=\"userBannerRight\"]/ul/li[3]/span/a")).get(0).click(); // click on
																												// logout

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("authentication", "id", "userBannerRight");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElements(By.xpath(xpathExpression)).get(0).click();
			}
		  
		}

		@Test(priority =8 ,groups= "regression")
		public void admin_users__1()throws Exception
		{
			currrent_test="admin_users__1";
			try {

				driver.findElement(By.id("login")).clear();

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("authentication", "id", "login");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElement(By.xpath(xpathExpression)).clear();
			}

			try {

				driver.findElement(By.name("login")).sendKeys("admin");

			} catch (NoSuchElementException e) {
				String nameValue = repairerObj.repair("authentication", "name", "login");
				String xpathExpression = "//*[@name='" + nameValue + "']";
				driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
			}

			try {

				driver.findElement(By.id("password")).clear();

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("authentication", "id", "password");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElement(By.xpath(xpathExpression)).clear();
			}

			try {

				driver.findElement(By.name("password")).sendKeys("admin");

			} catch (NoSuchElementException e) {
				String nameValue = repairerObj.repair("authentication", "name", "password");
				String xpathExpression = "//*[@name='" + nameValue + "']";
				driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
			}

			try {

				driver.findElement(By.xpath("//*[@id=\"loginBox\"]/form/fieldset/button")).click();

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("authentication", "text", "Enter");
				String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
				driver.findElement(By.xpath(xpathExpression)).click();
			}

			

			try {

				driver.findElement(By.xpath("//*[@id=\"userBannerLeft\"]/ul/li[3]/span/a")).click();

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("admin", "text", "Platform administration");
				String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
				driver.findElement(By.xpath(xpathExpression)).click();
			}

			try {

				driver.findElement(By.xpath("//*[@id=\"claroBody\"]/ul/li[1]/ul/li[2]/a")).click();   //click on USer List tab
				flag = 1;
			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("admin", "text", "User list");
				String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
				driver.findElement(By.xpath(xpathExpression)).click();
				flag = 2;
			}
			try {

				Assert.assertTrue(driver.findElement(By.cssSelector("BODY")).getText()
						.matches("^[\\s\\S]*" + "USER LIST" + "[\\s\\S]*$"));
			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("admin_users", "id", "claroBody");
				String xpathExpression = "//*[@id='" + idValue + "']";
				AssertJUnit.assertEquals(driver.findElement(By.xpath(xpathExpression)).getText(), "USER LIST");

			}

			// logout

			try {
				driver.findElement(By.xpath("//*[@id=\"userBannerRight\"]/ul/li[3]/span/a")).click(); // click on
																												// logout

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("admin_users", "id", "userBannerRight");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElements(By.xpath(xpathExpression)).get(0).click();
			}
			
		
		}
		@Test(priority =9 ,groups= "regression")
		public void send_message__1()throws Exception
		{
			currrent_test="send_message__1";
			try {

				driver.findElement(By.id("login")).clear();

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("authentication", "id", "login");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElement(By.xpath(xpathExpression)).clear();
			}

			try {

				driver.findElement(By.name("login")).sendKeys("admin");

			} catch (NoSuchElementException e) {
				String nameValue = repairerObj.repair("authentication", "name", "login");
				String xpathExpression = "//*[@name='" + nameValue + "']";
				driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
			}

			try {

				driver.findElement(By.id("password")).clear();

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("authentication", "id", "password");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElement(By.xpath(xpathExpression)).clear();
			}

			try {

				driver.findElement(By.name("password")).sendKeys("admin");

			} catch (NoSuchElementException e) {
				String nameValue = repairerObj.repair("authentication", "name", "password");
				String xpathExpression = "//*[@name='" + nameValue + "']";
				driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
			}

			try {

				driver.findElement(By.xpath("//*[@id=\"loginBox\"]/form/fieldset/button")).click();

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("authentication", "text", "Enter");
				String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
				driver.findElement(By.xpath(xpathExpression)).click();
			}

			

			try {

				driver.findElement(By.xpath("//*[@id=\"userBannerLeft\"]/ul/li[3]/span/a")).click();

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("admin", "text", "Platform administration");
				String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
				driver.findElement(By.xpath(xpathExpression)).click();
			}

			try {

				driver.findElement(By.xpath("//*[@id=\"claroBody\"]/ul/li[1]/ul/li[3]/a")).click();   //click on Send a message to all users
				flag = 1;
			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("admin", "text", "Send a message to all users");
				String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
				driver.findElement(By.xpath(xpathExpression)).click();
				flag = 2;
			}
		    try {

				driver.findElement(By.id("message_subject")).clear(); //clearing subject field

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("sendmessage", "id", "message_subject");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElement(By.xpath(xpathExpression)).clear();
			}

			try {

			    driver.findElement(By.id("message_subject")).sendKeys("Hello");  //setting subject to hello

			} catch (NoSuchElementException e) {
				String Value = repairerObj.repair("sendmessage", "id", "message_subject");
				String xpathExpression = "//*[@id='" + Value + "']";
				driver.findElement(By.xpath(xpathExpression)).sendKeys("Hello");
			}
		   
		
		   
		    
		    try {

				WebElement ele = driver.findElement(By.name("send")); //click to send message
				JavascriptExecutor executor = (JavascriptExecutor) driver;
				executor.executeScript("arguments[0].click();", ele);

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("sendmessage", "name", "send");
				String xpathExpression = "//*[@name='" + new_value + "']";
				WebElement ele = driver.findElement(By.xpath(xpathExpression));
				JavascriptExecutor executor = (JavascriptExecutor) driver;
				executor.executeScript("arguments[0].click();", ele);
			}
		    try {

				Assert.assertTrue(driver.findElement(By.cssSelector("BODY")).getText()
						.matches("^[\\s\\S]*" + "Message sent" + "[\\s\\S]*$"));
			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("admin_users", "id", "claroBody");
				String xpathExpression = "//*[@id='" + idValue + "']";
				AssertJUnit.assertEquals(driver.findElement(By.xpath(xpathExpression)).getText(), "Message sent");

			}

			// logout

			try {
				driver.findElement(By.xpath("//*[@id=\"userBannerRight\"]/ul/li[3]/span/a")).click(); // click on
																												// logout

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("admin_users", "id", "userBannerRight");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElement(By.xpath(xpathExpression)).click();
			}
		}
		

		
		@Test(priority =10 ,groups= "regression")
		public void add_csv_users__1()throws Exception
		{
			currrent_test="add_csv_users__1";
			try {

				driver.findElement(By.id("login")).clear();

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("authentication", "id", "login");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElement(By.xpath(xpathExpression)).clear();
			}

			try {

				driver.findElement(By.name("login")).sendKeys("admin");

			} catch (NoSuchElementException e) {
				String nameValue = repairerObj.repair("authentication", "name", "login");
				String xpathExpression = "//*[@name='" + nameValue + "']";
				driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
			}

			try {

				driver.findElement(By.id("password")).clear();

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("authentication", "id", "password");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElement(By.xpath(xpathExpression)).clear();
			}

			try {

				driver.findElement(By.name("password")).sendKeys("admin");

			} catch (NoSuchElementException e) {
				String nameValue = repairerObj.repair("authentication", "name", "password");
				String xpathExpression = "//*[@name='" + nameValue + "']";
				driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
			}

			try {

				driver.findElement(By.xpath("//*[@id=\"loginBox\"]/form/fieldset/button")).click();

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("authentication", "text", "Enter");
				String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
				driver.findElement(By.xpath(xpathExpression)).click();
			}

			

			try {

				driver.findElement(By.xpath("//*[@id=\"userBannerLeft\"]/ul/li[3]/span/a")).click();

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("admin", "text", "Platform administration");
				String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
				driver.findElement(By.xpath(xpathExpression)).click();
			}

			try {

				driver.findElement(By.xpath("//*[@id=\"claroBody\"]/ul/li[1]/ul/li[5]/a")).click();   //click on add user list
				flag = 1;
			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("admin", "text", "Add a user list");
				String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
				driver.findElement(By.xpath(xpathExpression)).click();
				flag = 2;
			}
			try {

				driver.findElement(By.xpath("//*[@id=\"firstLineFormat_NO\"]")).click();   //click  to select default file format

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("addcsvusers", "id", "firstLineFormat_NO");
				String xpathExpression = "//*[@id='" + new_value + "']";
				driver.findElement(By.xpath(xpathExpression)).click();
			}
			try {

				driver.findElement(By.xpath("//*[@id=\"sendEmailToUserCreated\"]")).click();   //click to to select to send email to all users

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("addcsvusers", "id", "sendEmailToUserCreated");
				String xpathExpression = "//*[@id='" + new_value + "']";
				driver.findElement(By.xpath(xpathExpression)).click();
			}
			try {

				driver.findElement(By.xpath("//*[@id=\"claroBody\"]/form/input[7]")).click();   //click to add users

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("addcsvusers", "value", "Add user list");
				String xpathExpression = "//input[@value='" + new_value + "']";
				driver.findElement(By.xpath(xpathExpression)).click();
			}
			
			  try {

					Assert.assertTrue(driver.findElement(By.cssSelector("BODY")).getText()
							.matches("^[\\s\\S]*" + "You must select a file" + "[\\s\\S]*$"));
				} catch (NoSuchElementException e) {
					String idValue = repairerObj.repair("admin_users", "id", "claroBody");
					String xpathExpression = "//*[@id='" + idValue + "']";
					AssertJUnit.assertEquals(driver.findElement(By.xpath(xpathExpression)).getText(), "You must select a file");

				}

				// logout

				try {
					driver.findElement(By.xpath("//*[@id=\"userBannerRight\"]/ul/li[3]/span/a")).click(); // click on
																													// logout

				} catch (NoSuchElementException e) {
					String idValue = repairerObj.repair("admin_users", "id", "userBannerRight");
					String xpathExpression = "//*[@id='" + idValue + "']";
					driver.findElement(By.xpath(xpathExpression)).click();
				}
		}
		
		@Test(priority =11 ,groups= "regression")
		public void lost_Password__1 ()throws Exception
		{
			currrent_test="lost_Password__1";
			try {

				driver.findElement(By.id("login")).clear();

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("authentication", "id", "login");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElement(By.xpath(xpathExpression)).clear();
			}

			try {

				driver.findElement(By.name("login")).sendKeys("admin");

			} catch (NoSuchElementException e) {
				String nameValue = repairerObj.repair("authentication", "name", "login");
				String xpathExpression = "//*[@name='" + nameValue + "']";
				driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
			}

			try {

				driver.findElement(By.id("password")).clear();

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("authentication", "id", "password");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElement(By.xpath(xpathExpression)).clear();
			}

			try {

				driver.findElement(By.name("password")).sendKeys("admin");

			} catch (NoSuchElementException e) {
				String nameValue = repairerObj.repair("authentication", "name", "password");
				String xpathExpression = "//*[@name='" + nameValue + "']";
				driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
			}

			try {

				driver.findElement(By.xpath("//*[@id=\"loginBox\"]/form/fieldset/button")).click();

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("authentication", "text", "Enter");
				String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
				driver.findElement(By.xpath(xpathExpression)).click();
			}

			try {

				driver.findElement(By.xpath("//*[@id=\"userBannerLeft\"]/ul/li[3]/span/a")).click();

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("admin", "text", "Platform administration");
				String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
				driver.findElement(By.xpath(xpathExpression)).click();
			}

			try {

				driver.findElement(By.xpath("//*[@id=\"claroBody\"]/ul/li[1]/ul/li[4]/a")).click();   //click on create user
				flag = 1;																				

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("admin", "text", "Create user");
				String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
				driver.findElement(By.xpath(xpathExpression)).click();
				flag = 2;
			}

			 try {

				    driver.findElement(By.id("firstname")).clear();        //clear the field

				} catch (NoSuchElementException e) {
					String idValue = repairerObj.repair("adminaddnewuser", "id", "firstname");
					String xpathExpression = "//*[@id='" + idValue + "']";
					driver.findElement(By.xpath(xpathExpression)).clear();
				}

				try {

				    driver.findElement(By.id("firstname")).sendKeys("Abid"); //set the value

				} catch (NoSuchElementException e) {
					String Value = repairerObj.repair("adminaddnewuser", "id", "firstname");
					String xpathExpression = "//*[@id='" + Value + "']";
					driver.findElement(By.xpath(xpathExpression)).sendKeys("Abid");
				}
				
		    try {

			    driver.findElement(By.id("lastname")).clear();        //clear the field

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("adminaddnewuser", "id", "lastname");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElement(By.xpath(xpathExpression)).clear();
			}

			try {

			    driver.findElement(By.id("lastname")).sendKeys("Hussain"); //set the value

			} catch (NoSuchElementException e) {
				String Value = repairerObj.repair("adminaddnewuser", "id", "lastname");
				String xpathExpression = "//*[@id='" + Value + "']";
				driver.findElement(By.xpath(xpathExpression)).sendKeys("Hussain");
			}
		    try {

			    driver.findElement(By.id("officialCode")).clear();        //clear the field

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("adminaddnewuser", "id", "officialCode");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElement(By.xpath(xpathExpression)).clear();
			}

			try {

			    driver.findElement(By.id("officialCode")).sendKeys("1234"); //set the value

			} catch (NoSuchElementException e) {
				String Value = repairerObj.repair("adminaddnewuser", "id", "officialCode");
				String xpathExpression = "//*[@id='" + Value + "']";
				driver.findElement(By.xpath(xpathExpression)).sendKeys("1234");
			}
		    try {

			    driver.findElement(By.id("username")).clear();        //clear the field

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("adminaddnewuser", "id", "username");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElement(By.xpath(xpathExpression)).clear();
			}

			try {

			    driver.findElement(By.id("username")).sendKeys("nam"); //set the value

			} catch (NoSuchElementException e) {
				String Value = repairerObj.repair("adminaddnewuser", "id", "username");
				String xpathExpression = "//*[@id='" + Value + "']";
				driver.findElement(By.xpath(xpathExpression)).sendKeys("nam");
			}
		    try {

			    driver.findElement(By.id("username")).clear();        //clear the field

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("adminaddnewuser", "id", "username");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElement(By.xpath(xpathExpression)).clear();
			}

			try {

			    driver.findElement(By.id("username")).sendKeys("abid"); //set the value

			} catch (NoSuchElementException e) {
				String Value = repairerObj.repair("adminaddnewuser", "id", "username");
				String xpathExpression = "//*[@id='" + Value + "']";
				driver.findElement(By.xpath(xpathExpression)).sendKeys("abid");
			}
		    try {

			    driver.findElement(By.id("password")).clear();        //clear the field

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("adminaddnewuser", "id", "password");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElement(By.xpath(xpathExpression)).clear();
			}

			try {

			    driver.findElement(By.id("password")).sendKeys("123456"); //set the value

			} catch (NoSuchElementException e) {
				String Value = repairerObj.repair("adminaddnewuser", "id", "password");
				String xpathExpression = "//*[@id='" + Value + "']";
				driver.findElement(By.xpath(xpathExpression)).sendKeys("123456");
			}
		    try {

			    driver.findElement(By.id("password_conf")).clear();        //clear the field

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("adminaddnewuser", "id", "password_conf");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElement(By.xpath(xpathExpression)).clear();
			}

			try {

			    driver.findElement(By.id("password_conf")).sendKeys("1234567"); //set the value

			} catch (NoSuchElementException e) {
				String Value = repairerObj.repair("adminaddnewuser", "id", "password_conf");
				String xpathExpression = "//*[@id='" + Value + "']";
				driver.findElement(By.xpath(xpathExpression)).sendKeys("1234567");
			}
		  
		    try {

				WebElement ele = driver.findElement(By.id("student"));
				JavascriptExecutor executor = (JavascriptExecutor) driver;
				executor.executeScript("arguments[0].click();", ele);

			} catch (NoSuchElementException e) {
				String nameValue = repairerObj.repair("adminaddnewuser", "id", "student");
				String xpathExpression = "//*[@id='" + nameValue + "']";
				WebElement ele = driver.findElement(By.xpath(xpathExpression));
				JavascriptExecutor executor = (JavascriptExecutor) driver;
				executor.executeScript("arguments[0].click();", ele);
			}

		    try {

				WebElement ele = driver.findElement(By.id("applyChange"));
				JavascriptExecutor executor = (JavascriptExecutor) driver;
				executor.executeScript("arguments[0].click();", ele);

			} catch (NoSuchElementException e) {
				String nameValue = repairerObj.repair("adminaddnewuser", "id", "applyChange");
				String xpathExpression = "//*[@id='" + nameValue + "']";
				WebElement ele = driver.findElement(By.xpath(xpathExpression));
				JavascriptExecutor executor = (JavascriptExecutor) driver;
				executor.executeScript("arguments[0].click();", ele);
			}
		    try {

				Assert.assertTrue(driver.findElement(By.cssSelector("BODY")).getText()
						.matches("^[\\s\\S]*" + "You typed two different passwords" + "[\\s\\S]*$"));
			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("authentication", "id", "claroBody");
				String xpathExpression = "//*[@id='" + idValue + "']";
				AssertJUnit.assertEquals(driver.findElement(By.xpath(xpathExpression)).getText(), "You typed two different passwords");

			}
			try {
				driver.findElement(By.xpath("//*[@id=\"userBannerRight\"]/ul/li[3]/span/a")).click(); // click on
																												// logout

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("authentication", "id", "userBannerRight");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElement(By.xpath(xpathExpression)).click();
			}
	
		   
		  
		}
		
		
		@Test(priority =12 ,groups= "regression")
		public void admin_add_new_user__2 ()throws Exception
		{
			currrent_test="admin_add_new_user__2";
			try {

				driver.findElement(By.id("login")).clear();

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("authentication", "id", "login");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElement(By.xpath(xpathExpression)).clear();
			}

			try {

				driver.findElement(By.name("login")).sendKeys("admin");

			} catch (NoSuchElementException e) {
				String nameValue = repairerObj.repair("authentication", "name", "login");
				String xpathExpression = "//*[@name='" + nameValue + "']";
				driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
			}

			try {

				driver.findElement(By.id("password")).clear();

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("authentication", "id", "password");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElement(By.xpath(xpathExpression)).clear();
			}

			try {

				driver.findElement(By.name("password")).sendKeys("admin");

			} catch (NoSuchElementException e) {
				String nameValue = repairerObj.repair("authentication", "name", "password");
				String xpathExpression = "//*[@name='" + nameValue + "']";
				driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
			}

			try {

				driver.findElement(By.xpath("//*[@id=\"loginBox\"]/form/fieldset/button")).click();

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("authentication", "text", "Enter");
				String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
				driver.findElement(By.xpath(xpathExpression)).click();
			}

			try {

				driver.findElement(By.xpath("//*[@id=\"userBannerLeft\"]/ul/li[3]/span/a")).click();

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("admin", "text", "Platform administration");
				String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
				driver.findElement(By.xpath(xpathExpression)).click();
			}

			try {

				driver.findElement(By.xpath("//*[@id=\"claroBody\"]/ul/li[1]/ul/li[4]/a")).click();   //click on create user
				flag = 1;																					

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("admin", "text", "Create user");
				String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
				driver.findElement(By.xpath(xpathExpression)).click();
				flag = 2;
			}

			 try {

				    driver.findElement(By.id("firstname")).clear();        //clear the field

				} catch (NoSuchElementException e) {
					String idValue = repairerObj.repair("adminaddnewuser", "id", "firstname");
					String xpathExpression = "//*[@id='" + idValue + "']";
					driver.findElement(By.xpath(xpathExpression)).clear();
				}

				try {

				    driver.findElement(By.id("firstname")).sendKeys("Abid"); //set the value

				} catch (NoSuchElementException e) {
					String Value = repairerObj.repair("adminaddnewuser", "id", "firstname");
					String xpathExpression = "//*[@id='" + Value + "']";
					driver.findElement(By.xpath(xpathExpression)).sendKeys("Abid");
				}
				
		    try {

			    driver.findElement(By.id("lastname")).clear();        //clear the field

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("adminaddnewuser", "id", "lastname");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElement(By.xpath(xpathExpression)).clear();
			}

			try {

			    driver.findElement(By.id("lastname")).sendKeys("Hussain"); //set the value

			} catch (NoSuchElementException e) {
				String Value = repairerObj.repair("adminaddnewuser", "id", "lastname");
				String xpathExpression = "//*[@id='" + Value + "']";
				driver.findElement(By.xpath(xpathExpression)).sendKeys("Hussain");
			}
		    try {

			    driver.findElement(By.id("officialCode")).clear();        //clear the field

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("adminaddnewuser", "id", "officialCode");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElement(By.xpath(xpathExpression)).clear();
			}

			try {

			    driver.findElement(By.id("officialCode")).sendKeys("1234"); //set the value

			} catch (NoSuchElementException e) {
				String Value = repairerObj.repair("adminaddnewuser", "id", "officialCode");
				String xpathExpression = "//*[@id='" + Value + "']";
				driver.findElement(By.xpath(xpathExpression)).sendKeys("1234");
			}
		    try {

			    driver.findElement(By.id("username")).clear();        //clear the field

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("adminaddnewuser", "id", "username");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElement(By.xpath(xpathExpression)).clear();
			}

			try {

			    driver.findElement(By.id("username")).sendKeys("nam"); //set the value

			} catch (NoSuchElementException e) {
				String Value = repairerObj.repair("adminaddnewuser", "id", "username");
				String xpathExpression = "//*[@id='" + Value + "']";
				driver.findElement(By.xpath(xpathExpression)).sendKeys("nam");
			}
		    try {

			    driver.findElement(By.id("username")).clear();        //clear the field

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("adminaddnewuser", "id", "username");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElement(By.xpath(xpathExpression)).clear();
			}

			try {

			    driver.findElement(By.id("username")).sendKeys("abid"); //set the value

			} catch (NoSuchElementException e) {
				String Value = repairerObj.repair("adminaddnewuser", "id", "username");
				String xpathExpression = "//*[@id='" + Value + "']";
				driver.findElement(By.xpath(xpathExpression)).sendKeys("abid");
			}
		    try {

			    driver.findElement(By.id("password")).clear();        //clear the field

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("adminaddnewuser", "id", "password");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElement(By.xpath(xpathExpression)).clear();
			}

			try {

			    driver.findElement(By.id("password")).sendKeys("123456"); //set the value

			} catch (NoSuchElementException e) {
				String Value = repairerObj.repair("adminaddnewuser", "id", "password");
				String xpathExpression = "//*[@id='" + Value + "']";
				driver.findElement(By.xpath(xpathExpression)).sendKeys("123456");
			}
		    try {

			    driver.findElement(By.id("password_conf")).clear();        //clear the field

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("adminaddnewuser", "id", "password_conf");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElement(By.xpath(xpathExpression)).clear();
			}

			try {

			    driver.findElement(By.id("password_conf")).sendKeys("1234567"); //set the value

			} catch (NoSuchElementException e) {
				String Value = repairerObj.repair("adminaddnewuser", "id", "password_conf");
				String xpathExpression = "//*[@id='" + Value + "']";
				driver.findElement(By.xpath(xpathExpression)).sendKeys("1234567");
			}
		  
		    try {

				WebElement ele = driver.findElement(By.id("student"));
				JavascriptExecutor executor = (JavascriptExecutor) driver;
				executor.executeScript("arguments[0].click();", ele);

			} catch (NoSuchElementException e) {
				String nameValue = repairerObj.repair("adminaddnewuser", "id", "student");
				String xpathExpression = "//*[@id='" + nameValue + "']";
				WebElement ele = driver.findElement(By.xpath(xpathExpression));
				JavascriptExecutor executor = (JavascriptExecutor) driver;
				executor.executeScript("arguments[0].click();", ele);
			}

		    try {

				WebElement ele = driver.findElement(By.id("applyChange"));
				JavascriptExecutor executor = (JavascriptExecutor) driver;
				executor.executeScript("arguments[0].click();", ele);

			} catch (NoSuchElementException e) {
				String nameValue = repairerObj.repair("adminaddnewuser", "id", "applyChange");
				String xpathExpression = "//*[@id='" + nameValue + "']";
				WebElement ele = driver.findElement(By.xpath(xpathExpression));
				JavascriptExecutor executor = (JavascriptExecutor) driver;
				executor.executeScript("arguments[0].click();", ele);
			}
		    try {

				Assert.assertTrue(driver.findElement(By.cssSelector("BODY")).getText()
						.matches("^[\\s\\S]*" + "This official code is already used by another user." + "[\\s\\S]*$"));
			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("authentication", "id", "claroBody");
				String xpathExpression = "//*[@id='" + idValue + "']";
				AssertJUnit.assertEquals(driver.findElement(By.xpath(xpathExpression)).getText(), "This official code is already used by another user.");

			}
			try {
				driver.findElement(By.xpath("//*[@id=\"userBannerRight\"]/ul/li[3]/span/a")).click(); // click on
																												// logout

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("authentication", "id", "userBannerRight");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElement(By.xpath(xpathExpression)).click();
			}
	
		    
		}
		
		@Test(priority =13 ,groups= "regression")
		public void admin_user_deleted__1 ()throws Exception
		{
			currrent_test="admin_user_deleted__1";
			try {

				driver.findElement(By.id("login")).clear();

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("authentication", "id", "login");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElement(By.xpath(xpathExpression)).clear();
			}

			try {

				driver.findElement(By.name("login")).sendKeys("admin");

			} catch (NoSuchElementException e) {
				String nameValue = repairerObj.repair("authentication", "name", "login");
				String xpathExpression = "//*[@name='" + nameValue + "']";
				driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
			}

			try {

				driver.findElement(By.id("password")).clear();

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("authentication", "id", "password");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElement(By.xpath(xpathExpression)).clear();
			}

			try {

				driver.findElement(By.name("password")).sendKeys("admin");

			} catch (NoSuchElementException e) {
				String nameValue = repairerObj.repair("authentication", "name", "password");
				String xpathExpression = "//*[@name='" + nameValue + "']";
				driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
			}

			try {

				driver.findElement(By.xpath("//*[@id=\"loginBox\"]/form/fieldset/button")).click();

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("authentication", "text", "Enter");
				String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
				driver.findElement(By.xpath(xpathExpression)).click();
			}

			try {

				driver.findElement(By.xpath("//*[@id=\"userBannerLeft\"]/ul/li[3]/span/a")).click();

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("admin", "text", "Platform administration");
				String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
				driver.findElement(By.xpath(xpathExpression)).click();
			}

			try {

				driver.findElement(By.xpath("//*[@id=\"claroBody\"]/ul/li[1]/ul/li[2]/a")).click();   //click on User list
				flag = 1;																				

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("admin", "text", "User list");
				String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
				driver.findElement(By.xpath(xpathExpression)).click();
				flag = 2;
			}
//			 try {
//
//					driver.findElement(By.id("search")).clear();      //clear the field
//
//				} catch (NoSuchElementException e) {
//					String idValue = repairerObj.repair("admin_users", "id", "search");
//					String xpathExpression = "//*[@id='" + idValue + "']";
//					driver.findElement(By.xpath(xpathExpression)).clear();
//				}
//
//				try {
//
//					driver.findElement(By.id("search")).sendKeys("1234");  //set the value
//
//				} catch (NoSuchElementException e) {
//					String Value = repairerObj.repair("admin_users", "id", "search");
//					String xpathExpression = "//*[@id='" + Value + "']";
//					driver.findElement(By.xpath(xpathExpression)).sendKeys("1234");
//				}
//			try {
//
//				WebElement ele = driver.findElement(By.xpath("//*[@id=\"claroBody\"]/table[1]/tbody/tr[1]/td/form/input[2]"));//click on OK
//				JavascriptExecutor executor = (JavascriptExecutor) driver;
//				executor.executeScript("arguments[0].click();", ele);
//
//			} catch (NoSuchElementException e) {
//				String new_value = repairerObj.repair("admin_users", "value", "Ok");
//				String xpathExpression = "//input[@value='" + new_value + "']";
//				WebElement ele = driver.findElement(By.xpath(xpathExpression));
//				JavascriptExecutor executor = (JavascriptExecutor) driver;
//				executor.executeScript("arguments[0].click();", ele);
//			}
		    try {
			    driver.findElement(By.xpath("//*[@id=\"claroBody\"]/table[2]/tbody/tr[2]/td[7]/a/img")).click();//click on user setting
			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("admin_users", "alt", "User settings");
				String xpathExpression = "//img[@alt='" + new_value + "']";
				driver.findElement(By.xpath(xpathExpression)).click();

			}
		    try {

			    driver.findElement(By.xpath("//*[@id=\"claroBody\"]/div[1]/table/tbody/tr/td[2]/ul/li[4]/a")).click();  //click on delete this user
																									

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("admin_profile", "text", "Delete user");
				String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
				driver.findElement(By.xpath(xpathExpression)).click();

			}
		    try {

			    driver.findElement(By.xpath("//*[@id=\"claroBody\"]/div[2]/div/a[1]")).click();  //click on yes
																									

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("adminuserdeleted", "text", "Yes");
				String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
				driver.findElement(By.xpath(xpathExpression)).click();

			}
		    try {

				Assert.assertTrue(driver.findElement(By.cssSelector("BODY")).getText()
						.matches("^[\\s\\S]*" + "Deletion of the user was done sucessfully" + "[\\s\\S]*$"));
			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("authentication", "id", "claroBody");
				String xpathExpression = "//*[@id='" + idValue + "']";
				AssertJUnit.assertEquals(driver.findElement(By.xpath(xpathExpression)).getText(), "Deletion of the user was done sucessfully");

			}
			try {
				driver.findElement(By.xpath("//*[@id=\"userBannerRight\"]/ul/li[3]/span/a")).click(); // click on
																												// logout

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("authentication", "id", "userBannerRight");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElement(By.xpath(xpathExpression)).click();
			}
	
		  
		}
		
		@Test(priority =14 ,groups= "regression")
		public void lost_Password__2()throws Exception
		{
			currrent_test="lost_Password__2";
			try {

				driver.findElement(By.id("login")).clear();

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("authentication", "id", "login");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElement(By.xpath(xpathExpression)).clear();
			}

			try {

				driver.findElement(By.name("login")).sendKeys("admin");

			} catch (NoSuchElementException e) {
				String nameValue = repairerObj.repair("authentication", "name", "login");
				String xpathExpression = "//*[@name='" + nameValue + "']";
				driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
			}

			try {

				driver.findElement(By.id("password")).clear();

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("authentication", "id", "password");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElement(By.xpath(xpathExpression)).clear();
			}

			try {

				driver.findElement(By.name("password")).sendKeys("admin");

			} catch (NoSuchElementException e) {
				String nameValue = repairerObj.repair("authentication", "name", "password");
				String xpathExpression = "//*[@name='" + nameValue + "']";
				driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
			}

			try {

				driver.findElement(By.xpath("//*[@id=\"loginBox\"]/form/fieldset/button")).click();

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("authentication", "text", "Enter");
				String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
				driver.findElement(By.xpath(xpathExpression)).click();
			}

			try {

				driver.findElement(By.xpath("//*[@id=\"userBannerLeft\"]/ul/li[3]/span/a")).click();

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("admin", "text", "Platform administration");
				String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
				driver.findElement(By.xpath(xpathExpression)).click();
			}

			try {

				driver.findElement(By.xpath("//*[@id=\"claroBody\"]/ul/li[1]/ul/li[2]/a")).click();   //click on User list
				flag = 1;																				

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("admin", "text", "User list");
				String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
				driver.findElement(By.xpath(xpathExpression)).click();
				flag = 2;
			}
			
			try {

				driver.findElement(By.xpath("//*[@id=\"claroBody\"]/div[1]/table/tbody/tr/td[2]/ul/li[2]/a")).click();   //click on Reset all users passward
																									

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("admin_users", "text", "Reset all user passwords");
				String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
				driver.findElement(By.xpath(xpathExpression)).click();

			}
			
			try {
				driver.findElement(By.xpath("//*[@id=\"claroBody\"]/div[2]/div[2]/form/input[3]")).click();   //click on yes
			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("admin_users", "value", "Yes");
				String xpathExpression = "//input[@value='" + new_value + "']";
				driver.findElement(By.xpath(xpathExpression)).click();

			}

		    try {

				Assert.assertTrue(driver.findElement(By.cssSelector("BODY")).getText()
						.matches("^[\\s\\S]*" + "Password changed successfully for all concerned users" + "[\\s\\S]*$"));
			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("authentication", "id", "claroBody");
				String xpathExpression = "//*[@id='" + idValue + "']";
				AssertJUnit.assertEquals(driver.findElement(By.xpath(xpathExpression)).getText(), "Password changed successfully for all concerned users");

			}
			try {
				driver.findElement(By.xpath("//*[@id=\"userBannerRight\"]/ul/li[3]/span/a")).click(); // click on
																												// logout

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("authentication", "id", "userBannerRight");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElement(By.xpath(xpathExpression)).click();
			}
	
		}
		
		@Test(priority =15 ,groups= "regression")
		public void admin_merge_user__1()throws Exception
		{
			currrent_test="admin_merge_user__1";
			try {

				driver.findElement(By.id("login")).clear();

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("authentication", "id", "login");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElement(By.xpath(xpathExpression)).clear();
			}

			try {

				driver.findElement(By.name("login")).sendKeys("admin");

			} catch (NoSuchElementException e) {
				String nameValue = repairerObj.repair("authentication", "name", "login");
				String xpathExpression = "//*[@name='" + nameValue + "']";
				driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
			}

			try {

				driver.findElement(By.id("password")).clear();

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("authentication", "id", "password");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElement(By.xpath(xpathExpression)).clear();
			}

			try {

				driver.findElement(By.name("password")).sendKeys("admin");

			} catch (NoSuchElementException e) {
				String nameValue = repairerObj.repair("authentication", "name", "password");
				String xpathExpression = "//*[@name='" + nameValue + "']";
				driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
			}

			try {

				driver.findElement(By.xpath("//*[@id=\"loginBox\"]/form/fieldset/button")).click();

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("authentication", "text", "Enter");
				String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
				driver.findElement(By.xpath(xpathExpression)).click();
			}

			try {

				driver.findElement(By.xpath("//*[@id=\"userBannerLeft\"]/ul/li[3]/span/a")).click();

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("admin", "text", "Platform administration");
				String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
				driver.findElement(By.xpath(xpathExpression)).click();
			}

			
			
			try {

				driver.findElement(By.xpath("//*[@id=\"claroBody\"]/ul/li[1]/ul/li[4]/a")).click();   //click on create user
				flag = 1;																			

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("admin", "text", "Create user");
				String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
				driver.findElement(By.xpath(xpathExpression)).click();
				flag = 2;
			}

			 try {

				    driver.findElement(By.id("firstname")).clear();        //clear the field

				} catch (NoSuchElementException e) {
					String idValue = repairerObj.repair("adminaddnewuser", "id", "firstname");
					String xpathExpression = "//*[@id='" + idValue + "']";
					driver.findElement(By.xpath(xpathExpression)).clear();
				}

				try {

				    driver.findElement(By.id("firstname")).sendKeys("Abid"); //set the value

				} catch (NoSuchElementException e) {
					String Value = repairerObj.repair("adminaddnewuser", "id", "firstname");
					String xpathExpression = "//*[@id='" + Value + "']";
					driver.findElement(By.xpath(xpathExpression)).sendKeys("Abid");
				}
				
		    try {

			    driver.findElement(By.id("lastname")).clear();        //clear the field

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("adminaddnewuser", "id", "lastname");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElement(By.xpath(xpathExpression)).clear();
			}

			try {

			    driver.findElement(By.id("lastname")).sendKeys("Hussain"); //set the value

			} catch (NoSuchElementException e) {
				String Value = repairerObj.repair("adminaddnewuser", "id", "lastname");
				String xpathExpression = "//*[@id='" + Value + "']";
				driver.findElement(By.xpath(xpathExpression)).sendKeys("Hussain");
			}
		    try {

			    driver.findElement(By.id("officialCode")).clear();        //clear the field

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("adminaddnewuser", "id", "officialCode");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElement(By.xpath(xpathExpression)).clear();
			}

			try {

			    driver.findElement(By.id("officialCode")).sendKeys("1234"); //set the value

			} catch (NoSuchElementException e) {
				String Value = repairerObj.repair("adminaddnewuser", "id", "officialCode");
				String xpathExpression = "//*[@id='" + Value + "']";
				driver.findElement(By.xpath(xpathExpression)).sendKeys("1234");
			}
		    
		    try {

			    driver.findElement(By.id("username")).clear();        //clear the field

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("adminaddnewuser", "id", "username");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElement(By.xpath(xpathExpression)).clear();
			}

			try {

			    driver.findElement(By.id("username")).sendKeys("abid"); //set the value

			} catch (NoSuchElementException e) {
				String Value = repairerObj.repair("adminaddnewuser", "id", "username");
				String xpathExpression = "//*[@id='" + Value + "']";
				driver.findElement(By.xpath(xpathExpression)).sendKeys("abid");
			}
		    try {

			    driver.findElement(By.id("password")).clear();        //clear the field

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("adminaddnewuser", "id", "password");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElement(By.xpath(xpathExpression)).clear();
			}

			try {

			    driver.findElement(By.id("password")).sendKeys("123456"); //set the value

			} catch (NoSuchElementException e) {
				String Value = repairerObj.repair("adminaddnewuser", "id", "password");
				String xpathExpression = "//*[@id='" + Value + "']";
				driver.findElement(By.xpath(xpathExpression)).sendKeys("123456");
			}
		    try {

			    driver.findElement(By.id("password_conf")).clear();        //clear the field

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("adminaddnewuser", "id", "password_conf");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElement(By.xpath(xpathExpression)).clear();
			}

			try {

			    driver.findElement(By.id("password_conf")).sendKeys("123456"); //set the value

			} catch (NoSuchElementException e) {
				String Value = repairerObj.repair("adminaddnewuser", "id", "password_conf");
				String xpathExpression = "//*[@id='" + Value + "']";
				driver.findElement(By.xpath(xpathExpression)).sendKeys("123456");
			}
		  
		    try {

				WebElement ele = driver.findElement(By.id("student"));
				JavascriptExecutor executor = (JavascriptExecutor) driver;
				executor.executeScript("arguments[0].click();", ele);

			} catch (NoSuchElementException e) {
				String nameValue = repairerObj.repair("adminaddnewuser", "id", "student");
				String xpathExpression = "//*[@id='" + nameValue + "']";
				WebElement ele = driver.findElement(By.xpath(xpathExpression));
				JavascriptExecutor executor = (JavascriptExecutor) driver;
				executor.executeScript("arguments[0].click();", ele);
			}

		    try {

				WebElement ele = driver.findElement(By.id("applyChange"));
				JavascriptExecutor executor = (JavascriptExecutor) driver;
				executor.executeScript("arguments[0].click();", ele);

			} catch (NoSuchElementException e) {
				String nameValue = repairerObj.repair("adminaddnewuser", "id", "applyChange");
				String xpathExpression = "//*[@id='" + nameValue + "']";
				WebElement ele = driver.findElement(By.xpath(xpathExpression));
				JavascriptExecutor executor = (JavascriptExecutor) driver;
				executor.executeScript("arguments[0].click();", ele);
			}
		    
		    
		
			
		    try {

				driver.findElement(By.xpath("//*[@id=\"claroBody\"]/ul/li[3]/a")).click();   //click on create another user
																									

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("adminaddnewuser", "text", "Create another new user");
				String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
				driver.findElement(By.xpath(xpathExpression)).click();

			}

			 try {

				    driver.findElement(By.id("firstname")).clear();        //clear the field

				} catch (NoSuchElementException e) {
					String idValue = repairerObj.repair("adminaddnewuser", "id", "firstname");
					String xpathExpression = "//*[@id='" + idValue + "']";
					driver.findElement(By.xpath(xpathExpression)).clear();
				}

				try {

				    driver.findElement(By.id("firstname")).sendKeys("umer"); //set the value

				} catch (NoSuchElementException e) {
					String Value = repairerObj.repair("adminaddnewuser", "id", "firstname");
					String xpathExpression = "//*[@id='" + Value + "']";
					driver.findElement(By.xpath(xpathExpression)).sendKeys("umer");
				}
				
		    try {

			    driver.findElement(By.id("lastname")).clear();        //clear the field

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("adminaddnewuser", "id", "lastname");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElement(By.xpath(xpathExpression)).clear();
			}

			try {

			    driver.findElement(By.id("lastname")).sendKeys("ali"); //set the value

			} catch (NoSuchElementException e) {
				String Value = repairerObj.repair("adminaddnewuser", "id", "lastname");
				String xpathExpression = "//*[@id='" + Value + "']";
				driver.findElement(By.xpath(xpathExpression)).sendKeys("ali");
			}
		    try {

			    driver.findElement(By.id("officialCode")).clear();        //clear the field

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("adminaddnewuser", "id", "officialCode");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElement(By.xpath(xpathExpression)).clear();
			}

			try {

			    driver.findElement(By.id("officialCode")).sendKeys("123"); //set the value

			} catch (NoSuchElementException e) {
				String Value = repairerObj.repair("adminaddnewuser", "id", "officialCode");
				String xpathExpression = "//*[@id='" + Value + "']";
				driver.findElement(By.xpath(xpathExpression)).sendKeys("123");
			}
		   
		    try {

			    driver.findElement(By.id("username")).clear();        //clear the field

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("adminaddnewuser", "id", "username");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElement(By.xpath(xpathExpression)).clear();
			}

			try {

			    driver.findElement(By.id("username")).sendKeys("umer"); //set the value

			} catch (NoSuchElementException e) {
				String Value = repairerObj.repair("adminaddnewuser", "id", "username");
				String xpathExpression = "//*[@id='" + Value + "']";
				driver.findElement(By.xpath(xpathExpression)).sendKeys("umer");
			}
		    try {

			    driver.findElement(By.id("password")).clear();        //clear the field

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("adminaddnewuser", "id", "password");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElement(By.xpath(xpathExpression)).clear();
			}

			try {

			    driver.findElement(By.id("password")).sendKeys("123456"); //set the value

			} catch (NoSuchElementException e) {
				String Value = repairerObj.repair("adminaddnewuser", "id", "password");
				String xpathExpression = "//*[@id='" + Value + "']";
				driver.findElement(By.xpath(xpathExpression)).sendKeys("123456");
			}
		    try {

			    driver.findElement(By.id("password_conf")).clear();        //clear the field

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("adminaddnewuser", "id", "password_conf");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElement(By.xpath(xpathExpression)).clear();
			}

			try {

			    driver.findElement(By.id("password_conf")).sendKeys("123456"); //set the value

			} catch (NoSuchElementException e) {
				String Value = repairerObj.repair("adminaddnewuser", "id", "password_conf");
				String xpathExpression = "//*[@id='" + Value + "']";
				driver.findElement(By.xpath(xpathExpression)).sendKeys("123456");
			}
		  
		    try {

				WebElement ele = driver.findElement(By.id("student"));
				JavascriptExecutor executor = (JavascriptExecutor) driver;
				executor.executeScript("arguments[0].click();", ele);

			} catch (NoSuchElementException e) {
				String nameValue = repairerObj.repair("adminaddnewuser", "id", "student");
				String xpathExpression = "//*[@id='" + nameValue + "']";
				WebElement ele = driver.findElement(By.xpath(xpathExpression));
				JavascriptExecutor executor = (JavascriptExecutor) driver;
				executor.executeScript("arguments[0].click();", ele);
			}

		    try {

				WebElement ele = driver.findElement(By.id("applyChange"));
				JavascriptExecutor executor = (JavascriptExecutor) driver;
				executor.executeScript("arguments[0].click();", ele);

			} catch (NoSuchElementException e) {
				String nameValue = repairerObj.repair("adminaddnewuser", "id", "applyChange");
				String xpathExpression = "//*[@id='" + nameValue + "']";
				WebElement ele = driver.findElement(By.xpath(xpathExpression));
				JavascriptExecutor executor = (JavascriptExecutor) driver;
				executor.executeScript("arguments[0].click();", ele);
			}
			
			
			
			
		    try {

				driver.findElement(By.xpath("//*[@id=\"userBannerLeft\"]/ul/li[3]/span/a")).click();

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("admin", "text", "Platform administration");
				String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
				driver.findElement(By.xpath(xpathExpression)).click();
			}

			
			
			
			try {

				driver.findElement(By.xpath("//*[@id=\"claroBody\"]/ul/li[1]/ul/li[2]/a")).click();   //click on User list
																									

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("admin", "text", "User list");
				String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
				driver.findElement(By.xpath(xpathExpression)).click();

			}
			String str1= "", str2="";
			 try {

				 str1=driver.findElement(By.xpath("//*[@id=\"claroBody\"]/table[2]/tbody/tr[2]/td[1]")).getText();  //getting 1st user ID
																										

				} catch (NoSuchElementException e) {
					String new_value = repairerObj.repair("admin_users", "text", "5");
					String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
					str1=driver.findElement(By.xpath(xpathExpression)).getText(); 

				}
			 try {

				 str2=driver.findElement(By.xpath("//*[@id=\"claroBody\"]/table[2]/tbody/tr[3]/td[1]")).getText();  //getting 2nd User ID
																										

				} catch (NoSuchElementException e) {
					String new_value = repairerObj.repair("admin_users", "text", "5");
					String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
					str2=driver.findElement(By.xpath(xpathExpression)).getText(); 

				}
			System.out.println(str1+str2);
			 try {

					driver.findElement(By.xpath("//*[@id=\"breadcrumbLine\"]/div[1]/ul/li[2]/a")).click();  //click on Administration

				} catch (NoSuchElementException e) {
					String new_value = repairerObj.repair("admin", "text", "Administration");
					String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
					driver.findElement(By.xpath(xpathExpression)).click();
				}
			 try {

					driver.findElement(By.xpath("//*[@id=\"claroBody\"]/ul/li[1]/ul/li[9]/a")).click();  //click on Merge user accounts

				} catch (NoSuchElementException e) {
					String new_value = repairerObj.repair("admin", "text", "Merge user accounts");
					String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
					driver.findElement(By.xpath(xpathExpression)).click();
				}
			try {

				driver.findElement(By.id("uidToRemove")).sendKeys(str1);  //setting the 1st ID value

			} catch (NoSuchElementException e) {
				String Value = repairerObj.repair("adminmergeuser", "id", "uidToRemove");
				String xpathExpression = "//*[@id='" + Value + "']";
				driver.findElement(By.xpath(xpathExpression)).sendKeys(str1);
			}
			try {

				driver.findElement(By.id("uidToKeep")).sendKeys(str2);  //setting the 2nd ID value

			} catch (NoSuchElementException e) {
				String Value = repairerObj.repair("adminmergeuser", "id", "uidToKeep");
				String xpathExpression = "//*[@id='" + Value + "']";
				driver.findElement(By.xpath(xpathExpression)).sendKeys(str2);
			}
			 try {

					driver.findElement(By.xpath("//*[@id=\"claroBody\"]/div[2]/div[2]/form/input[2]")).click();  //click on merge

				} catch (NoSuchElementException e) {
					String new_value = repairerObj.repair("adminmergeuser", "value", "Merge");
					String xpathExpression = "//input[@value='" + new_value + "']";
					driver.findElement(By.xpath(xpathExpression)).click();
				}
			 try {

					driver.findElement(By.xpath("//*[@id=\"claroBody\"]/div[2]/div/form/input[3]")).click();  //click on yes

				} catch (NoSuchElementException e) {
					String new_value = repairerObj.repair("adminmergeuser", "value", "Yes");
					String xpathExpression = "//input[@value='" + new_value + "']";
					driver.findElement(By.xpath(xpathExpression)).click();
				}
		    try {

				Assert.assertTrue(driver.findElement(By.cssSelector("BODY")).getText()
						.matches("^[\\s\\S]*" + "User accounts merged" + "[\\s\\S]*$"));
			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("authentication", "id", "claroBody");
				String xpathExpression = "//*[@id='" + idValue + "']";
				AssertJUnit.assertEquals(driver.findElement(By.xpath(xpathExpression)).getText(), "User accounts merged");

			}
		    
		    try {

				driver.findElement(By.xpath("//*[@id=\"breadcrumbLine\"]/div[1]/ul/li[2]/a")).click();

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("admin", "text", "Administration");
				String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
				driver.findElement(By.xpath(xpathExpression)).click();
			}

			try {

				driver.findElement(By.xpath("//*[@id=\"claroBody\"]/ul/li[1]/ul/li[2]/a")).click();   //click on User list
																									

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("admin", "text", "User list");
				String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
				driver.findElement(By.xpath(xpathExpression)).click();

			}
//			 try {
//
//					driver.findElement(By.id("search")).clear();      //clear the field
//
//				} catch (NoSuchElementException e) {
//					String idValue = repairerObj.repair("admin_users", "id", "search");
//					String xpathExpression = "//*[@id='" + idValue + "']";
//					driver.findElement(By.xpath(xpathExpression)).clear();
//				}
//
//				try {
//
//					driver.findElement(By.id("search")).sendKeys("1234");  //set the value
//
//				} catch (NoSuchElementException e) {
//					String Value = repairerObj.repair("admin_users", "id", "search");
//					String xpathExpression = "//*[@id='" + Value + "']";
//					driver.findElement(By.xpath(xpathExpression)).sendKeys("1234");
//				}
//			try {
//
//				WebElement ele = driver.findElement(By.xpath("//*[@id=\"claroBody\"]/table[1]/tbody/tr[1]/td/form/input[2]"));//click on OK
//				JavascriptExecutor executor = (JavascriptExecutor) driver;
//				executor.executeScript("arguments[0].click();", ele);
//
//			} catch (NoSuchElementException e) {
//				String new_value = repairerObj.repair("admin_users", "value", "Ok");
//				String xpathExpression = "//input[@value='" + new_value + "']";
//				WebElement ele = driver.findElement(By.xpath(xpathExpression));
//				JavascriptExecutor executor = (JavascriptExecutor) driver;
//				executor.executeScript("arguments[0].click();", ele);
//			}
		    try {
			    driver.findElement(By.xpath("//*[@id=\"claroBody\"]/table[2]/tbody/tr[2]/td[7]/a/img")).click();//click on user setting
			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("admin_users", "alt", "User settings");
				String xpathExpression = "//img[@alt='" + new_value + "']";
				driver.findElement(By.xpath(xpathExpression)).click();

			}
		    try {

			    driver.findElement(By.xpath("//*[@id=\"claroBody\"]/div[1]/table/tbody/tr/td[2]/ul/li[4]/a")).click();  //click on delete this user
																									

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("admin_profile", "text", "Delete user");
				String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
				driver.findElement(By.xpath(xpathExpression)).click();

			}
		    try {

			    driver.findElement(By.xpath("//*[@id=\"claroBody\"]/div[2]/div/a[1]")).click();  //click on yes
																									

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("adminuserdeleted", "text", "Yes");
				String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
				driver.findElement(By.xpath(xpathExpression)).click();

			}
		    try {

				Assert.assertTrue(driver.findElement(By.cssSelector("BODY")).getText()
						.matches("^[\\s\\S]*" + "Deletion of the user was done sucessfully" + "[\\s\\S]*$"));
			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("authentication", "id", "claroBody");
				String xpathExpression = "//*[@id='" + idValue + "']";
				AssertJUnit.assertEquals(driver.findElement(By.xpath(xpathExpression)).getText(), "Deletion of the user was done sucessfully");

			}
		    try {
				driver.findElement(By.xpath("//*[@id=\"userBannerRight\"]/ul/li[3]/span/a")).click(); // click on
																												// logout

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("authentication", "id", "userBannerRight");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElement(By.xpath(xpathExpression)).click();
			}
		  
		}


}
