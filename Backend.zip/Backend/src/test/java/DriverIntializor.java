
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.ITestContext;
import org.testng.ITestNGMethod;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;

import com.example.demo.Repairer;

import static org.testng.Assert.fail;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class DriverIntializor {
	protected static WebDriver driver;
	protected WebDriverWait wait;
	protected static JavascriptExecutor js;
	protected static Repairer repairerObj;
	protected boolean acceptNextAlert = true;
	protected StringBuffer verificationErrors = new StringBuffer();
	protected JavascriptExecutor jse;
	protected String currrent_test = "";
	protected int flag = 0;

	@BeforeSuite
	public void getAllTestScripts(ITestContext context) throws IOException {
		ITestNGMethod[] a = context.getAllTestMethods();

		FileWriter br1 = null;
		try {
			br1 = new FileWriter("TestscriptNames.txt");
		} catch (IOException e) {
			System.out.println("An error occurred.");
			e.printStackTrace();
		}

		for (ITestNGMethod b : a) {
			br1.write(b.getConstructorOrMethod().getName() + "\n");
		}
		br1.close();
	}

//	@BeforeSuite
	public static void invokeBrowser() {

		System.setProperty("webdriver.chrome.driver", "F:\\eclipes_workspace3\\fyp2\\chromedriver.exe");
		driver = new ChromeDriver(); // for Chrome driver
		driver.manage().deleteAllCookies(); // deleteitng all cookies
		driver.manage().window().maximize(); // screen maxmixing
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS); // setting timout
		driver.manage().timeouts().pageLoadTimeout(5, TimeUnit.SECONDS);
		// driver.get("http://localhost/parent/claroline/index.php?logout=true"); //base
		driver.get("http://localhost/parent3/vtwo/index.php?logout=true"); // new
		repairerObj = new Repairer();
		js = (JavascriptExecutor) driver;

	}

	/*
	 * * *
	 * 
	 * classify test cases either is unchange, modified or obselete
	 * 
	 */
//	@AfterMethod
	public void classifier() throws IOException {
		FileWriter br1 = null;
		if (flag == 1)
			{
			
			try {
				br1 = new FileWriter("unchange.txt", true); // file opening

			} catch (IOException e) {
				System.out.println("An error occurred.");
				e.printStackTrace();
			}
			br1.write(currrent_test+"\n");
			}
		else if (flag == 2)
			{
			
			try {
				br1 = new FileWriter("modified.txt", true); // file opening

			} catch (IOException e) {
				System.out.println("An error occurred.");
				e.printStackTrace();
			}
			br1.write(currrent_test+"\n");
			}
		else
			{
			try {
				br1 = new FileWriter("obsolete.txt", true); // file opening

			} catch (IOException e) {
				System.out.println("An error occurred.");
				e.printStackTrace();
			}
			br1.write(currrent_test+"\n");
			
			}
		flag = 0;
		br1.close();
	}
	/* * *
	 * 
	 * write unchange, modified or obselete test cases to file
	 * 
	 */
//	@AfterSuite
	public void writer() throws IOException {
		FileWriter br1 = null;
		try {
			br1 = new FileWriter("cards.txt", true); // file opening

		} catch (IOException e) {
			System.out.println("An error occurred.");
			e.printStackTrace();
		}
		
		
		File file = new File("obsolete.txt");
		BufferedReader br = new BufferedReader(new FileReader(file));
		String st;
		br1.write("Obsolete\n");
		while ((st = br.readLine()) != null) {
			br1.write(st+"\n");
		}
		
		File file1 = new File("modified.txt");
		BufferedReader	 br3 = new BufferedReader(new FileReader(file1));
		br1.write("Modified\n");
		while ((st = br3.readLine()) != null) {
			br1.write(st+"\n");
			System.out.println(st);
		}
		
		
		File file2 = new File("unchange.txt");
		BufferedReader br2 = new BufferedReader(new FileReader(file2));
		br1.write("Unchanged\n");
		while ((st = br2.readLine()) != null) {
			br1.write(st+"\n");
		}
		br1.close();
		

	}
//	 @AfterClass(alwaysRun = true)
//	  public void tearDown() throws Exception {
//	    driver.quit();
//	    String verificationErrorString = verificationErrors.toString();
//	    if (!"".equals(verificationErrorString)) {
//	      fail(verificationErrorString);
//	    }
//	  }

//	 protected boolean isElementPresent(By by) {
//	    try {
//	      driver.findElement(by);
//	      return true;
//	    } catch (NoSuchElementException e) {
//	      return false;
//	    }
//	  }
//
//	  protected boolean isAlertPresent() {
//	    try {
//	      driver.switchTo().alert();
//	      return true;
//	    } catch (NoAlertPresentException e) {
//	      return false;
//	    }
//	  }
//
//	  protected String closeAlertAndGetItsText() {
//	    try {
//	      Alert alert = driver.switchTo().alert();
//	      String alertText = alert.getText();
//	      if (acceptNextAlert) {
//	        alert.accept();
//	      } else {
//	        alert.dismiss();
//	      }
//	      return alertText;
//	    } finally {
//	      acceptNextAlert = true;
//	    }
//	  }
}
