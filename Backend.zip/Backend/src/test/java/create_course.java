

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.testng.Assert;
import org.testng.AssertJUnit;
import org.testng.annotations.Test;



public class create_course extends DriverIntializor{

	@Test(priority =1 ,groups= "regression")
	public void authentication__1()throws Exception {
		try {
			currrent_test="authentication__1";

			driver.findElement(By.id("login")).clear();

		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("authentication", "id", "login");
			String xpathExpression = "//*[@id='" + idValue + "']";
			driver.findElement(By.xpath(xpathExpression)).clear();
		}

		try {

			driver.findElement(By.name("login")).sendKeys("admin");

		} catch (NoSuchElementException e) {
			String nameValue = repairerObj.repair("authentication", "name", "login");
			String xpathExpression = "//*[@name='" + nameValue + "']";
			driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
		}

		try {

			driver.findElement(By.id("password")).clear();

		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("authentication", "id", "password");
			String xpathExpression = "//*[@id='" + idValue + "']";
			driver.findElement(By.xpath(xpathExpression)).clear();
		}

		try {

			driver.findElement(By.name("password")).sendKeys("admin");

		} catch (NoSuchElementException e) {
			String nameValue = repairerObj.repair("authentication", "name", "password");
			String xpathExpression = "//*[@name='" + nameValue + "']";
			driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
		}

		try {

			driver.findElement(By.xpath("//*[@id=\"loginBox\"]/form/fieldset/button")).click();

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("authentication", "text", "Enter");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();
		}

			
			
			try {

				Assert.assertTrue(driver.findElement(By.cssSelector("BODY")).getText()
						.matches("^[\\s\\S]*" + "Claroline" + "[\\s\\S]*$"));
			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("agenda", "id", "claroBody");
				String xpathExpression = "//*[@id='" + idValue + "']";
				AssertJUnit.assertEquals(driver.findElement(By.xpath(xpathExpression)).getText(), "Claroline");

			}

			// logout

			try {
				driver.findElements(By.xpath("//*[@id=\"userBannerRight\"]/ul/li[3]/span/a")).get(0).click(); // click on
																												// logout

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("agenda", "id", "userBannerRight");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElements(By.xpath(xpathExpression)).get(0).click();
			}
			flag = 1;
	}

	@Test(priority =1 ,groups= "regression")
	public void create__1()throws Exception
	{
		currrent_test="create__1";
		try {

			driver.findElement(By.id("login")).clear();

		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("authentication", "id", "login");
			String xpathExpression = "//*[@id='" + idValue + "']";
			driver.findElement(By.xpath(xpathExpression)).clear();
		}

		try {

			driver.findElement(By.name("login")).sendKeys("admin");

		} catch (NoSuchElementException e) {
			String nameValue = repairerObj.repair("authentication", "name", "login");
			String xpathExpression = "//*[@name='" + nameValue + "']";
			driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
		}

		try {

			driver.findElement(By.id("password")).clear();

		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("authentication", "id", "password");
			String xpathExpression = "//*[@id='" + idValue + "']";
			driver.findElement(By.xpath(xpathExpression)).clear();
		}

		try {

			driver.findElement(By.name("password")).sendKeys("admin");

		} catch (NoSuchElementException e) {
			String nameValue = repairerObj.repair("authentication", "name", "password");
			String xpathExpression = "//*[@name='" + nameValue + "']";
			driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
		}

		try {

			driver.findElement(By.xpath("//*[@id=\"loginBox\"]/form/fieldset/button")).click();

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("authentication", "text", "Enter");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();
		}

		try {

			driver.findElement(By.xpath("//*[@id=\"userBannerLeft\"]/ul/li[3]/span/a")).click();

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("admin", "text", "Platform administration");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();
		}

		try {

			driver.findElement(By.xpath("//*[@id=\"claroBody\"]/ul/li[2]/ul/li[3]/a")).click(); // click on create course
			flag = 1;																				// button in Courses

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("admin", "text", "Create course");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();
			flag = 2;
		}
		try {

			driver.findElement(By.xpath("//*[@id=\"courseSettings\"]/p/a[1]")).click();

		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("create", "id", "courseSettings");
			String xpathExpression = "//*[@id='" + idValue + "']";
			driver.findElement(By.xpath(xpathExpression)).click();
		}
		// ***********************************Create Course()*****************************
		// *********************************** Basic Setting******************************
		try {

			driver.findElement(By.id("course_title")).clear(); 

		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("create", "id", "course_title");
			String xpathExpression = "//*[@id='" + idValue + "']";
			driver.findElement(By.xpath(xpathExpression)).clear();
		}
		try {

			driver.findElement(By.id("course_title")).sendKeys("Programming Fundamentals");

		} catch (NoSuchElementException e) {
			String nameValue = repairerObj.repair("create", "id", "course_title");
			String xpathExpression = "//*[@id='" + nameValue + "']";
			driver.findElement(By.xpath(xpathExpression)).sendKeys("Programming Fundamentals");
		}
		try {

			driver.findElement(By.id("course_officialCode")).clear(); 

		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("create", "id", "course_officialCode");
			String xpathExpression = "//*[@id='" + idValue + "']";
			driver.findElement(By.xpath(xpathExpression)).clear();
		}
		try {

			driver.findElement(By.id("course_officialCode")).sendKeys("CS-2002");

		} catch (NoSuchElementException e) {
			String nameValue = repairerObj.repair("create", "id", "course_officialCode");
			String xpathExpression = "//*[@id='" + nameValue + "']";
			driver.findElement(By.xpath(xpathExpression)).sendKeys("CS-2002");
		}
		
		try {

			driver.findElement(By.xpath("//option[@value='2']")).click();

		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("create", "value", "2");
			String xpathExpression = "//option[@value='" + idValue + "']";
			driver.findElement(By.xpath(xpathExpression)).click();
		}

		try {

			driver.findElement(By.id("course_titular")).clear();

		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("create", "id", "course_titular");
			String xpathExpression = "//*[@id='" + idValue + "']";
			driver.findElement(By.xpath(xpathExpression)).clear();
		}
		
		try {

			driver.findElement(By.id("course_titular")).sendKeys("Muhammad Aqel Afzal");

		} catch (NoSuchElementException e) {
			String nameValue = repairerObj.repair("create", "id", "course_titular");
			String xpathExpression = "//*[@id='" + nameValue + "']";
			driver.findElement(By.xpath(xpathExpression)).sendKeys("Muhammad Aqel Afzal");
		}
		
		
		try {

			driver.findElement(By.id("course_email")).clear();

		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("create", "id", "course_email");
			String xpathExpression = "//*[@id='" + idValue + "']";
			driver.findElement(By.xpath(xpathExpression)).clear();
		}
		
		try {

			driver.findElement(By.id("course_email")).sendKeys("muhammadaqelafzal@gmail.com");

		} catch (NoSuchElementException e) {
			String nameValue = repairerObj.repair("create", "id", "course_email");
			String xpathExpression = "//*[@id='" + nameValue + "']";
			driver.findElement(By.xpath(xpathExpression)).sendKeys("muhammadaqelafzal@gmail.com");
		}
		try {

			driver.findElement(By.xpath("//*[@id=\"mandatories\"]/div/dl/dd[7]/label[2]")).click();

		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("create", "id", "mandatories");
			String xpathExpression = "//*[@id='" + idValue + "']";
			driver.findElement(By.xpath(xpathExpression)).click();
		}
		try {

			driver.findElement(By.xpath("//*[@id=\"mandatories\"]/div/dl/dd[8]/label[1]")).click();

		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("create", "id", "mandatories");
			String xpathExpression = "//*[@id='" + idValue + "']";
			driver.findElement(By.xpath(xpathExpression)).click();
		}
		

		try {

			driver.findElement(By.xpath("//*[@id=\"courseSettings\"]/dl/dt/input")).click(); // or we can write it as tr:nth-child(6) > td > input

		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("create", "id", "courseSettings");
			String xpathExpression = "//*[@id='" + idValue + "']";
			driver.findElement(By.xpath(xpathExpression)).click();
		}

	//	driver.findElement(By.xpath("//*[@id=\"claroBody\"]/p/a")).click(); // or we can write it as tr:nth-child(6) > td > input
		
		try {

			Assert.assertTrue(driver.findElement(By.cssSelector("BODY")).getText()
					.matches("^[\\s\\S]*" + "You have just created the course website : " + "[\\s\\S]*$"));
		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("tools", "id", "claroBody");
			String xpathExpression = "//*[@id='" + idValue + "']";
			AssertJUnit.assertEquals(driver.findElement(By.xpath(xpathExpression)).getText(), "You have just created the course website : ");

		}
		// logout
		try {
			driver.findElements(By.xpath("//*[@id=\"userBannerRight\"]/ul/li[3]/span/a")).get(0).click(); // click on
																											// logout

		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("tools", "id", "userBannerRight");
			String xpathExpression = "//*[@id='" + idValue + "']";
			driver.findElements(By.xpath(xpathExpression)).get(0).click();
		}
		
	}
	
//	@Test(priority =2 ,groups= "regression")
//	public void create_with_additional_settings__2()throws Exception
//	{
//	currrent_test="create_with_additional_settings__2";
//		try {
//
//			driver.findElement(By.id("login")).clear();
//
//		} catch (NoSuchElementException e) {
//			String idValue = repairerObj.repair("authentication", "id", "login");
//			String xpathExpression = "//*[@id='" + idValue + "']";
//			driver.findElement(By.xpath(xpathExpression)).clear();
//		}
//
//		try {
//
//			driver.findElement(By.name("login")).sendKeys("admin");
//
//		} catch (NoSuchElementException e) {
//			String nameValue = repairerObj.repair("authentication", "name", "login");
//			String xpathExpression = "//*[@name='" + nameValue + "']";
//			driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
//		}
//
//		try {
//
//			driver.findElement(By.id("password")).clear();
//
//		} catch (NoSuchElementException e) {
//			String idValue = repairerObj.repair("authentication", "id", "password");
//			String xpathExpression = "//*[@id='" + idValue + "']";
//			driver.findElement(By.xpath(xpathExpression)).clear();
//		}
//
//		try {
//
//			driver.findElement(By.name("password")).sendKeys("admin");
//
//		} catch (NoSuchElementException e) {
//			String nameValue = repairerObj.repair("authentication", "name", "password");
//			String xpathExpression = "//*[@name='" + nameValue + "']";
//			driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
//		}
//
//		try {
//
//			driver.findElement(By.xpath("//*[@id=\"loginBox\"]/form/fieldset/button")).click();
//
//		} catch (NoSuchElementException e) {
//			String new_value = repairerObj.repair("authentication", "text", "Enter");
//			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
//			driver.findElement(By.xpath(xpathExpression)).click();
//		}
//
//		try {
//
//			driver.findElement(By.xpath("//*[@id=\"userBannerLeft\"]/ul/li[3]/span/a")).click();
//
//		} catch (NoSuchElementException e) {
//			String new_value = repairerObj.repair("admin", "text", "Platform administration");
//			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
//			driver.findElement(By.xpath(xpathExpression)).click();
//		}
//
//		try {
//
//			driver.findElement(By.xpath("//*[@id=\"claroBody\"]/ul/li[2]/ul/li[3]/a")).click(); // click on create course
//				flag = 1;																				// button in Courses
//
//		} catch (NoSuchElementException e) {
//			String new_value = repairerObj.repair("admin", "text", "Create course");
//			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
//			driver.findElement(By.xpath(xpathExpression)).click();
//			flag = 2;
//		}
//		try {
//
//			driver.findElement(By.xpath("//*[@id=\"courseSettings\"]/p/a[1]")).click();
//
//		} catch (NoSuchElementException e) {
//			String idValue = repairerObj.repair("create", "id", "courseSettings");
//			String xpathExpression = "//*[@id='" + idValue + "']";
//			driver.findElement(By.xpath(xpathExpression)).click();
//		}
//		// ***********************************Create Course()*****************************
//		// *********************************** Basic Setting******************************
//		try {
//
//			driver.findElement(By.id("course_title")).clear(); 
//
//		} catch (NoSuchElementException e) {
//			String idValue = repairerObj.repair("create", "id", "course_title");
//			String xpathExpression = "//*[@id='" + idValue + "']";
//			driver.findElement(By.xpath(xpathExpression)).clear();
//		}
//		try {
//
//			driver.findElement(By.id("course_title")).sendKeys("Programming Fundamentals");
//
//		} catch (NoSuchElementException e) {
//			String nameValue = repairerObj.repair("create", "id", "course_title");
//			String xpathExpression = "//*[@id='" + nameValue + "']";
//			driver.findElement(By.xpath(xpathExpression)).sendKeys("Programming Fundamentals");
//		}
//		try {
//
//			driver.findElement(By.id("course_officialCode")).clear(); 
//
//		} catch (NoSuchElementException e) {
//			String idValue = repairerObj.repair("create", "id", "course_officialCode");
//			String xpathExpression = "//*[@id='" + idValue + "']";
//			driver.findElement(By.xpath(xpathExpression)).clear();
//		}
//		try {
//
//			driver.findElement(By.id("course_officialCode")).sendKeys("CS-2002");
//
//		} catch (NoSuchElementException e) {
//			String nameValue = repairerObj.repair("create", "id", "course_officialCode");
//			String xpathExpression = "//*[@id='" + nameValue + "']";
//			driver.findElement(By.xpath(xpathExpression)).sendKeys("CS-2002");
//		}
//		
//		try {
//
//			driver.findElement(By.xpath("//option[@value='2']")).click();
//
//		} catch (NoSuchElementException e) {
//			String idValue = repairerObj.repair("create", "value", "2");
//			String xpathExpression = "//option[@value='" + idValue + "']";
//			driver.findElement(By.xpath(xpathExpression)).click();
//		}
//
//		try {
//
//			driver.findElement(By.id("course_titular")).clear();
//
//		} catch (NoSuchElementException e) {
//			String idValue = repairerObj.repair("create", "id", "course_titular");
//			String xpathExpression = "//*[@id='" + idValue + "']";
//			driver.findElement(By.xpath(xpathExpression)).clear();
//		}
//		
//		try {
//
//			driver.findElement(By.id("course_titular")).sendKeys("Muhammad Aqel Afzal");
//
//		} catch (NoSuchElementException e) {
//			String nameValue = repairerObj.repair("create", "id", "course_titular");
//			String xpathExpression = "//*[@id='" + nameValue + "']";
//			driver.findElement(By.xpath(xpathExpression)).sendKeys("Muhammad Aqel Afzal");
//		}
//		
//		
//		try {
//
//			driver.findElement(By.id("course_email")).clear();
//
//		} catch (NoSuchElementException e) {
//			String idValue = repairerObj.repair("create", "id", "course_email");
//			String xpathExpression = "//*[@id='" + idValue + "']";
//			driver.findElement(By.xpath(xpathExpression)).clear();
//		}
//		
//		try {
//
//			driver.findElement(By.id("course_email")).sendKeys("muhammadaqelafzal@gmail.com");
//
//		} catch (NoSuchElementException e) {
//			String nameValue = repairerObj.repair("create", "id", "course_email");
//			String xpathExpression = "//*[@id='" + nameValue + "']";
//			driver.findElement(By.xpath(xpathExpression)).sendKeys("muhammadaqelafzal@gmail.com");
//		}
//		try {
//
//			driver.findElement(By.xpath("//*[@id=\"mandatories\"]/div/dl/dd[7]/label[2]")).click();
//
//		} catch (NoSuchElementException e) {
//			String idValue = repairerObj.repair("create", "id", "mandatories");
//			String xpathExpression = "//*[@id='" + idValue + "']";
//			driver.findElement(By.xpath(xpathExpression)).click();
//		}
//		try {
//
//			driver.findElement(By.xpath("//*[@id=\"mandatories\"]/div/dl/dd[8]/label[1]")).click();
//
//		} catch (NoSuchElementException e) {
//			String idValue = repairerObj.repair("create", "id", "mandatories");
//			String xpathExpression = "//*[@id='" + idValue + "']";
//			driver.findElement(By.xpath(xpathExpression)).click();
//		}
//		//driver.findElement(By.xpath("//*[@id=\"mandatories\"]/legend/a")).click();
//
//
//		// ***********************************Create Course()*****************************
//		// ***********************************Optional Course ****************************
//	//	driver.findElement(By.xpath("//*[@id=\"options\"]/legend/a")).click();
//		try {
//
//			driver.findElement(By.id("course_departmentName")).clear();
//
//		} catch (NoSuchElementException e) {
//			String idValue = repairerObj.repair("create", "id", "course_departmentName");
//			String xpathExpression = "//*[@id='" + idValue + "']";
//			driver.findElement(By.xpath(xpathExpression)).clear();
//		}
//		
//		try {
//
//			driver.findElement(By.id("course_departmentName")).sendKeys("Computer Science");
//
//		} catch (NoSuchElementException e) {
//			String nameValue = repairerObj.repair("create", "id", "course_departmentName");
//			String xpathExpression = "//*[@id='" + nameValue + "']";
//			driver.findElement(By.xpath(xpathExpression)).sendKeys("Computer Science");
//		}
//		try {
//
//			driver.findElement(By.id("course_extLinkUrl")).clear();
//
//		} catch (NoSuchElementException e) {
//			String idValue = repairerObj.repair("create", "id", "course_extLinkUrl");
//			String xpathExpression = "//*[@id='" + idValue + "']";
//			driver.findElement(By.xpath(xpathExpression)).clear();
//		}
//		
//		try {
//
//			driver.findElement(By.id("course_extLinkUrl")).sendKeys("https://www.nu.edu.pk");
//
//		} catch (NoSuchElementException e) {
//			String nameValue = repairerObj.repair("create", "id", "course_extLinkUrl");
//			String xpathExpression = "//*[@id='" + nameValue + "']";
//			driver.findElement(By.xpath(xpathExpression)).sendKeys("https://www.nu.edu.pk");
//		}
//
//		// ***********************************Create Course()*****************************
//		// ***********************************Advanced Option*****************************
//
//	//	driver.findElement(By.xpath("//*[@id=\"advancedInformation\"]/legend/a")).click();
//		try {
//
//			driver.findElement(By.xpath("//*[@id=\"visibility_hidden\"]")).click();
//
//		} catch (NoSuchElementException e) {
//			String idValue = repairerObj.repair("create", "id", "visibility_hidden");
//			String xpathExpression = "//*[@id='" + idValue + "']";
//			driver.findElement(By.xpath(xpathExpression)).click();
//		}
//		try {
//
//			driver.findElement(By.name("course_userLimit")).clear();
//
//		} catch (NoSuchElementException e) {
//			String idValue = repairerObj.repair("create", "id", "course_userLimit");
//			String xpathExpression = "//*[@id='" + idValue + "']";
//			driver.findElement(By.xpath(xpathExpression)).clear();
//		}
//		
//		try {
//
//			driver.findElement(By.name("course_userLimit")).sendKeys("200");
//
//		} catch (NoSuchElementException e) {
//			String nameValue = repairerObj.repair("create", "id", "course_userLimit");
//			String xpathExpression = "//*[@id='" + nameValue + "']";
//			driver.findElement(By.xpath(xpathExpression)).sendKeys("200");
//		}
//
//		try {
//
//			driver.findElement(By.xpath("//*[@id=\"course_status_enable\"]")).click();
//
//		} catch (NoSuchElementException e) {
//			String idValue = repairerObj.repair("create", "id", "course_status_enable");
//			String xpathExpression = "//*[@id='" + idValue + "']";
//			driver.findElement(By.xpath(xpathExpression)).click();
//		}
//		
//		try {
//
//			driver.findElement(By.xpath("//*[@id=\"courseSettings\"]/dl/dt/input")).click(); // or we can write it as tr:nth-child(6) > td > input
//
//		} catch (NoSuchElementException e) {
//			String idValue = repairerObj.repair("create", "id", "courseSettings");
//			String xpathExpression = "//*[@id='" + idValue + "']";
//			driver.findElement(By.xpath(xpathExpression)).click();
//		}
//
//	//	driver.findElement(By.xpath("//*[@id=\"claroBody\"]/p/a")).click(); // or we can write it as tr:nth-child(6) > td > input
//		
//		try {
//
//			Assert.assertTrue(driver.findElement(By.cssSelector("BODY")).getText()
//					.matches("^[\\s\\S]*" + "You have just created the course website : " + "[\\s\\S]*$"));
//		} catch (NoSuchElementException e) {
//			String idValue = repairerObj.repair("tools", "id", "claroBody");
//			String xpathExpression = "//*[@id='" + idValue + "']";
//			AssertJUnit.assertEquals(driver.findElement(By.xpath(xpathExpression)).getText(), "You have just created the course website : ");
//
//		}
//		// logout
//		try {
//			driver.findElements(By.xpath("//*[@id=\"userBannerRight\"]/ul/li[3]/span/a")).get(0).click(); // click on
//																											// logout
//
//		} catch (NoSuchElementException e) {
//			String idValue = repairerObj.repair("tools", "id", "userBannerRight");
//			String xpathExpression = "//*[@id='" + idValue + "']";
//			driver.findElements(By.xpath(xpathExpression)).get(0).click();
//		}
//	}



}
