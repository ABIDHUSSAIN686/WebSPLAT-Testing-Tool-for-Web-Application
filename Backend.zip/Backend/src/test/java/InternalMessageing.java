

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.testng.AssertJUnit;
import org.testng.annotations.Test;
public class InternalMessageing extends DriverIntializor{

	  
	  @Test(priority =1 ,groups= "regression")
		public void messaging__1()throws Exception
		{
		  currrent_test="messaging__1";
		  try {

				driver.findElement(By.id("login")).clear();

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("authentication", "id", "login");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElement(By.xpath(xpathExpression)).clear();
			}

			try {

				driver.findElement(By.name("login")).sendKeys("admin");

			} catch (NoSuchElementException e) {
				String nameValue = repairerObj.repair("authentication", "name", "login");
				String xpathExpression = "//*[@name='" + nameValue + "']";
				driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
			}

			try {

				driver.findElement(By.id("password")).clear();

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("authentication", "id", "password");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElement(By.xpath(xpathExpression)).clear();
			}

			try {

				driver.findElement(By.name("password")).sendKeys("admin");

			} catch (NoSuchElementException e) {
				String nameValue = repairerObj.repair("authentication", "name", "password");
				String xpathExpression = "//*[@name='" + nameValue + "']";
				driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
			}

			try {

				driver.findElement(By.xpath("//*[@id=\"loginBox\"]/form/fieldset/button")).click();

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("authentication", "text", "Enter");
				String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
				driver.findElement(By.xpath(xpathExpression)).click();
			}


			try {

				driver.findElement(By.xpath("//*[@id=\"userBannerLeft\"]/ul/li[3]/span/a")).click();

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("admin", "text", "Platform administration");
				String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
				driver.findElement(By.xpath(xpathExpression)).click();
			}

			
			try {

				WebElement ele = driver.findElement(By.xpath("//*[@id=\"claroBody\"]/ul/li[6]/ul/li/a"));
				JavascriptExecutor executor = (JavascriptExecutor) driver;
				executor.executeScript("arguments[0].click();", ele);
				flag = 1;
			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("admin", "text", "Internal messaging");
				String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
				WebElement ele = driver.findElement(By.xpath(xpathExpression));
				JavascriptExecutor executor = (JavascriptExecutor) driver;
				executor.executeScript("arguments[0].click();", ele);
				flag = 2;
			}
			try {

				driver.findElement(By.xpath("//*[@id=\"claroBody\"]/ul[1]/li[1]/a")).click();   //click on All message from a user

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("admin", "text", "All messages from a user");
				String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
				driver.findElement(By.xpath(xpathExpression)).click();
				
			}
			try {

				driver.findElement(By.name("name")).clear();      //clear the field

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("messaging", "name", "name");
				String xpathExpression = "//*[@name='" + idValue + "']";
				driver.findElement(By.xpath(xpathExpression)).clear();
			}

			try {

				driver.findElement(By.name("name")).sendKeys("abid");  //set the value

			} catch (NoSuchElementException e) {
				String nameValue = repairerObj.repair("messaging", "name", "name");
				String xpathExpression = "//*[@name='" + nameValue + "']";
				driver.findElement(By.xpath(xpathExpression)).sendKeys("abid");
			}
			try {

				driver.findElement(By.xpath("//*[@id=\"claroBody\"]/div[2]/div/form/input[2]")).click();   //click on Search

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("messaging", "value", "Search");
				String xpathExpression = "//input[@value='" + new_value + "']";
				driver.findElement(By.xpath(xpathExpression)).click();

				
			}
			
			    try {

					Assert.assertTrue(driver.findElement(By.cssSelector("BODY")).getText()
							.matches("^[\\s\\S]*" + "Subject" + "[\\s\\S]*$"));
				} catch (NoSuchElementException e) {
					String idValue = repairerObj.repair("messaging", "id", "claroBody");
					String xpathExpression = "//*[@id='" + idValue + "']";
					AssertJUnit.assertEquals(driver.findElement(By.xpath(xpathExpression)).getText(), "Subject");

				}
				// logout
				try {
					driver.findElement(By.xpath("//*[@id=\"userBannerRight\"]/ul/li[3]/span/a")).click(); // click on
																													// logout

				} catch (NoSuchElementException e) {
					String idValue = repairerObj.repair("tools", "id", "userBannerRight");
					String xpathExpression = "//*[@id='" + idValue + "']";
					driver.findElements(By.xpath(xpathExpression)).get(0).click();
				}
		}
	  
	  @Test(priority =2 ,groups= "regression")
		public void read_message__1()throws Exception
		{
		  currrent_test="read_message__1";
			
			    try {

					driver.findElement(By.id("login")).clear();

				} catch (NoSuchElementException e) {
					String idValue = repairerObj.repair("authentication", "id", "login");
					String xpathExpression = "//*[@id='" + idValue + "']";
					driver.findElement(By.xpath(xpathExpression)).clear();
				}

				try {

					driver.findElement(By.name("login")).sendKeys("admin");

				} catch (NoSuchElementException e) {
					String nameValue = repairerObj.repair("authentication", "name", "login");
					String xpathExpression = "//*[@name='" + nameValue + "']";
					driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
				}

				try {

					driver.findElement(By.id("password")).clear();

				} catch (NoSuchElementException e) {
					String idValue = repairerObj.repair("authentication", "id", "password");
					String xpathExpression = "//*[@id='" + idValue + "']";
					driver.findElement(By.xpath(xpathExpression)).clear();
				}

				try {

					driver.findElement(By.name("password")).sendKeys("admin");

				} catch (NoSuchElementException e) {
					String nameValue = repairerObj.repair("authentication", "name", "password");
					String xpathExpression = "//*[@name='" + nameValue + "']";
					driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
				}

				try {

					driver.findElement(By.xpath("//*[@id=\"loginBox\"]/form/fieldset/button")).click();

				} catch (NoSuchElementException e) {
					String new_value = repairerObj.repair("authentication", "text", "Enter");
					String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
					driver.findElement(By.xpath(xpathExpression)).click();
				}


				try {

					driver.findElement(By.xpath("//*[@id=\"userBannerLeft\"]/ul/li[3]/span/a")).click();

				} catch (NoSuchElementException e) {
					String new_value = repairerObj.repair("admin", "text", "Platform administration");
					String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
					driver.findElement(By.xpath(xpathExpression)).click();
				}

				
				try {

					WebElement ele = driver.findElement(By.xpath("//*[@id=\"claroBody\"]/ul/li[6]/ul/li/a"));
					JavascriptExecutor executor = (JavascriptExecutor) driver;
					executor.executeScript("arguments[0].click();", ele);
					flag = 1;
				} catch (NoSuchElementException e) {
					String new_value = repairerObj.repair("admin", "text", "Internal messaging");
					String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
					WebElement ele = driver.findElement(By.xpath(xpathExpression));
					JavascriptExecutor executor = (JavascriptExecutor) driver;
					executor.executeScript("arguments[0].click();", ele);
					flag = 2;
				}
				try {

					driver.findElement(By.xpath("//*[@id=\"claroBody\"]/ul[1]/li[2]/a")).click();   //click on All messages older then
				} catch (NoSuchElementException e) {
					String new_value = repairerObj.repair("messaging", "text", "All messages older than");
					String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
					driver.findElement(By.xpath(xpathExpression)).click();
					
				}
				
				try {

					driver.findElement(By.xpath("//*[@id=\"claroBody\"]/div[2]/div/form/input[2]")).click();   //click on Search

				} catch (NoSuchElementException e) {
					String new_value = repairerObj.repair("messaging", "value", "Search");
					String xpathExpression = "//input[@value='" + new_value + "']";
					driver.findElement(By.xpath(xpathExpression)).click();

					
				}
				
				    try {

						Assert.assertTrue(driver.findElement(By.cssSelector("BODY")).getText()
								.matches("^[\\s\\S]*" + "Subject" + "[\\s\\S]*$"));
					} catch (NoSuchElementException e) {
						String idValue = repairerObj.repair("messaging", "id", "claroBody");
						String xpathExpression = "//*[@id='" + idValue + "']";
						AssertJUnit.assertEquals(driver.findElement(By.xpath(xpathExpression)).getText(), "Subject");

					}
					// logout
					try {
						driver.findElement(By.xpath("//*[@id=\"userBannerRight\"]/ul/li[3]/span/a")).click(); // click on
																														// logout

					} catch (NoSuchElementException e) {
						String idValue = repairerObj.repair("tools", "id", "userBannerRight");
						String xpathExpression = "//*[@id='" + idValue + "']";
						driver.findElements(By.xpath(xpathExpression)).get(0).click();
					}
		}
	  
	  @Test(priority =3 ,groups= "regression")
		public void message_box__1()throws Exception
		{
		  currrent_test="message_box__1";
				    try {

					driver.findElement(By.id("login")).clear();

				} catch (NoSuchElementException e) {
					String idValue = repairerObj.repair("authentication", "id", "login");
					String xpathExpression = "//*[@id='" + idValue + "']";
					driver.findElement(By.xpath(xpathExpression)).clear();
				}

				try {

					driver.findElement(By.name("login")).sendKeys("admin");

				} catch (NoSuchElementException e) {
					String nameValue = repairerObj.repair("authentication", "name", "login");
					String xpathExpression = "//*[@name='" + nameValue + "']";
					driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
				}

				try {

					driver.findElement(By.id("password")).clear();

				} catch (NoSuchElementException e) {
					String idValue = repairerObj.repair("authentication", "id", "password");
					String xpathExpression = "//*[@id='" + idValue + "']";
					driver.findElement(By.xpath(xpathExpression)).clear();
				}

				try {

					driver.findElement(By.name("password")).sendKeys("admin");

				} catch (NoSuchElementException e) {
					String nameValue = repairerObj.repair("authentication", "name", "password");
					String xpathExpression = "//*[@name='" + nameValue + "']";
					driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
				}

				try {

					driver.findElement(By.xpath("//*[@id=\"loginBox\"]/form/fieldset/button")).click();

				} catch (NoSuchElementException e) {
					String new_value = repairerObj.repair("authentication", "text", "Enter");
					String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
					driver.findElement(By.xpath(xpathExpression)).click();
				}


				try {

					driver.findElement(By.xpath("//*[@id=\"userBannerLeft\"]/ul/li[3]/span/a")).click();

				} catch (NoSuchElementException e) {
					String new_value = repairerObj.repair("admin", "text", "Platform administration");
					String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
					driver.findElement(By.xpath(xpathExpression)).click();
				}

				
				try {

					WebElement ele = driver.findElement(By.xpath("//*[@id=\"claroBody\"]/ul/li[6]/ul/li/a"));
					JavascriptExecutor executor = (JavascriptExecutor) driver;
					executor.executeScript("arguments[0].click();", ele);
					flag = 1;
				} catch (NoSuchElementException e) {
					String new_value = repairerObj.repair("admin", "text", "Internal messaging");
					String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
					WebElement ele = driver.findElement(By.xpath(xpathExpression));
					JavascriptExecutor executor = (JavascriptExecutor) driver;
					executor.executeScript("arguments[0].click();", ele);
					flag = 2;
				}
				try {

					driver.findElement(By.xpath("//*[@id=\"claroBody\"]/ul[1]/li[4]/a")).click();   //click on All platform messages
				} catch (NoSuchElementException e) {
					String new_value = repairerObj.repair("messaging", "text", "All platform messages");
					String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
					driver.findElement(By.xpath(xpathExpression)).click();
					
				}
				
				
				
				    try {

						Assert.assertTrue(driver.findElement(By.cssSelector("BODY")).getText()
								.matches("^[\\s\\S]*" + "All platform messages" + "[\\s\\S]*$"));
					} catch (NoSuchElementException e) {
						String idValue = repairerObj.repair("messaging", "id", "claroBody");
						String xpathExpression = "//*[@id='" + idValue + "']";
						AssertJUnit.assertEquals(driver.findElement(By.xpath(xpathExpression)).getText(), "All platform messages");

					}
					// logout
					try {
						driver.findElement(By.xpath("//*[@id=\"userBannerRight\"]/ul/li[3]/span/a")).click(); // click on
																														// logout

					} catch (NoSuchElementException e) {
						String idValue = repairerObj.repair("tools", "id", "userBannerRight");
						String xpathExpression = "//*[@id='" + idValue + "']";
						driver.findElements(By.xpath(xpathExpression)).get(0).click();
					}
		}
	
	  @Test(priority =4 ,groups= "regression")
		public void message_box__2()throws Exception
		{
			
		  currrent_test="message_box__2";
			    try {

					driver.findElement(By.id("login")).clear();

				} catch (NoSuchElementException e) {
					String idValue = repairerObj.repair("authentication", "id", "login");
					String xpathExpression = "//*[@id='" + idValue + "']";
					driver.findElement(By.xpath(xpathExpression)).clear();
				}

				try {

					driver.findElement(By.name("login")).sendKeys("admin");

				} catch (NoSuchElementException e) {
					String nameValue = repairerObj.repair("authentication", "name", "login");
					String xpathExpression = "//*[@name='" + nameValue + "']";
					driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
				}

				try {

					driver.findElement(By.id("password")).clear();

				} catch (NoSuchElementException e) {
					String idValue = repairerObj.repair("authentication", "id", "password");
					String xpathExpression = "//*[@id='" + idValue + "']";
					driver.findElement(By.xpath(xpathExpression)).clear();
				}

				try {

					driver.findElement(By.name("password")).sendKeys("admin");

				} catch (NoSuchElementException e) {
					String nameValue = repairerObj.repair("authentication", "name", "password");
					String xpathExpression = "//*[@name='" + nameValue + "']";
					driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
				}

				try {

					driver.findElement(By.xpath("//*[@id=\"loginBox\"]/form/fieldset/button")).click();

				} catch (NoSuchElementException e) {
					String new_value = repairerObj.repair("authentication", "text", "Enter");
					String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
					driver.findElement(By.xpath(xpathExpression)).click();
				}


				try {

					driver.findElement(By.xpath("//*[@id=\"userBannerLeft\"]/ul/li[3]/span/a")).click();

				} catch (NoSuchElementException e) {
					String new_value = repairerObj.repair("admin", "text", "Platform administration");
					String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
					driver.findElement(By.xpath(xpathExpression)).click();
				}

				
				try {

					WebElement ele = driver.findElement(By.xpath("//*[@id=\"claroBody\"]/ul/li[6]/ul/li/a"));
					JavascriptExecutor executor = (JavascriptExecutor) driver;
					executor.executeScript("arguments[0].click();", ele);
					flag = 1;
				} catch (NoSuchElementException e) {
					String new_value = repairerObj.repair("admin", "text", "Internal messaging");
					String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
					WebElement ele = driver.findElement(By.xpath(xpathExpression));
					JavascriptExecutor executor = (JavascriptExecutor) driver;
					executor.executeScript("arguments[0].click();", ele);
					flag = 2;
				}
				try {

					driver.findElements(By.xpath("//*[@id=\"claroBody\"]/ul[1]/li[3]/a")).get(0).click();   //click on All messages in date interval
				} catch (NoSuchElementException e) {
					String new_value = repairerObj.repair("messaging", "text", "All messages older than");
					String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
					driver.findElement(By.xpath(xpathExpression)).click();
					
				}
				
				try {

					driver.findElement(By.xpath("//*[@id=\"claroBody\"]/div[2]/div/form/input[3]")).click();   //click on Search

				} catch (NoSuchElementException e) {
					String new_value = repairerObj.repair("messaging", "value", "Search");
					String xpathExpression = "//input[@value='" + new_value + "']";
					driver.findElement(By.xpath(xpathExpression)).click();

					
				}
				
				    try {

						Assert.assertTrue(driver.findElement(By.cssSelector("BODY")).getText()
								.matches("^[\\s\\S]*" + "Subject" + "[\\s\\S]*$"));
					} catch (NoSuchElementException e) {
						String idValue = repairerObj.repair("messaging", "id", "claroBody");
						String xpathExpression = "//*[@id='" + idValue + "']";
						AssertJUnit.assertEquals(driver.findElement(By.xpath(xpathExpression)).getText(), "Subject");

					}
					// logout
					try {
						driver.findElement(By.xpath("//*[@id=\"userBannerRight\"]/ul/li[3]/span/a")).click(); // click on
																														// logout

					} catch (NoSuchElementException e) {
						String idValue = repairerObj.repair("tools", "id", "userBannerRight");
						String xpathExpression = "//*[@id='" + idValue + "']";
						driver.findElements(By.xpath(xpathExpression)).get(0).click();
					}
		}
	  
	  
	  
	  @Test(priority =5 ,groups= "regression")
		public void messages_course__2()throws Exception
		{
			
		  currrent_test="messages_course__2";
			    try {

					driver.findElement(By.id("login")).clear();

				} catch (NoSuchElementException e) {
					String idValue = repairerObj.repair("authentication", "id", "login");
					String xpathExpression = "//*[@id='" + idValue + "']";
					driver.findElement(By.xpath(xpathExpression)).clear();
				}

				try {

					driver.findElement(By.name("login")).sendKeys("admin");

				} catch (NoSuchElementException e) {
					String nameValue = repairerObj.repair("authentication", "name", "login");
					String xpathExpression = "//*[@name='" + nameValue + "']";
					driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
				}

				try {

					driver.findElement(By.id("password")).clear();

				} catch (NoSuchElementException e) {
					String idValue = repairerObj.repair("authentication", "id", "password");
					String xpathExpression = "//*[@id='" + idValue + "']";
					driver.findElement(By.xpath(xpathExpression)).clear();
				}

				try {

					driver.findElement(By.name("password")).sendKeys("admin");

				} catch (NoSuchElementException e) {
					String nameValue = repairerObj.repair("authentication", "name", "password");
					String xpathExpression = "//*[@name='" + nameValue + "']";
					driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
				}

				try {

					driver.findElement(By.xpath("//*[@id=\"loginBox\"]/form/fieldset/button")).click();

				} catch (NoSuchElementException e) {
					String new_value = repairerObj.repair("authentication", "text", "Enter");
					String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
					driver.findElement(By.xpath(xpathExpression)).click();
				}


				try {

					driver.findElement(By.xpath("//*[@id=\"userBannerLeft\"]/ul/li[3]/span/a")).click();

				} catch (NoSuchElementException e) {
					String new_value = repairerObj.repair("admin", "text", "Platform administration");
					String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
					driver.findElement(By.xpath(xpathExpression)).click();
				}

				
				try {

					WebElement ele = driver.findElement(By.xpath("//*[@id=\"claroBody\"]/ul/li[6]/ul/li/a"));
					JavascriptExecutor executor = (JavascriptExecutor) driver;
					executor.executeScript("arguments[0].click();", ele);
					flag = 1;
				} catch (NoSuchElementException e) {
					String new_value = repairerObj.repair("admin", "text", "Internal messaging");
					String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
					WebElement ele = driver.findElement(By.xpath(xpathExpression));
					JavascriptExecutor executor = (JavascriptExecutor) driver;
					executor.executeScript("arguments[0].click();", ele);
					flag = 2;
				}
				try {

					driver.findElements(By.xpath("//*[@id=\"claroBody\"]/ul[2]/li[2]/a")).get(0).click();   //click on All messages from a user

				} catch (NoSuchElementException e) {
					String new_value = repairerObj.repair("admin", "text", "All messages from a user");
					String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
					driver.findElement(By.xpath(xpathExpression)).click();
					
				}
				try {

					driver.findElement(By.name("search")).clear();      //clear the field

				} catch (NoSuchElementException e) {
					String idValue = repairerObj.repair("messaging", "name", "search");
					String xpathExpression = "//*[@name='" + idValue + "']";
					driver.findElement(By.xpath(xpathExpression)).clear();
				}

				try {

					driver.findElement(By.name("search")).sendKeys("abid");  //set the value

				} catch (NoSuchElementException e) {
					String nameValue = repairerObj.repair("messaging", "name", "search");
					String xpathExpression = "//*[@name='" + nameValue + "']";
					driver.findElement(By.xpath(xpathExpression)).sendKeys("abid");
				}
				try {

					driver.findElement(By.xpath("//*[@id=\"claroBody\"]/div[2]/div/form/input[2]")).click();   //click on Search

				} catch (NoSuchElementException e) {
					String new_value = repairerObj.repair("messaging", "value", "Search");
					String xpathExpression = "//input[@value='" + new_value + "']";
					driver.findElement(By.xpath(xpathExpression)).click();

					
				}
				
				    try {

						Assert.assertTrue(driver.findElement(By.cssSelector("BODY")).getText()
								.matches("^[\\s\\S]*" + "Id" + "[\\s\\S]*$"));
					} catch (NoSuchElementException e) {
						String idValue = repairerObj.repair("messaging", "id", "claroBody");
						String xpathExpression = "//*[@id='" + idValue + "']";
						AssertJUnit.assertEquals(driver.findElement(By.xpath(xpathExpression)).getText(), "Id");

					}
					// logout
					try {
						driver.findElement(By.xpath("//*[@id=\"userBannerRight\"]/ul/li[3]/span/a")).click(); // click on
																														// logout

					} catch (NoSuchElementException e) {
						String idValue = repairerObj.repair("tools", "id", "userBannerRight");
						String xpathExpression = "//*[@id='" + idValue + "']";
						driver.findElements(By.xpath(xpathExpression)).get(0).click();
					}
		}
	  
	  @Test(priority =6 ,groups= "regression")
		public void admin_user_deleted__1()throws Exception
		{
		  currrent_test="admin_user_deleted__1";

		
			 try {

					driver.findElement(By.id("login")).clear();

				} catch (NoSuchElementException e) {
					String idValue = repairerObj.repair("authentication", "id", "login");
					String xpathExpression = "//*[@id='" + idValue + "']";
					driver.findElement(By.xpath(xpathExpression)).clear();
				}

				try {

					driver.findElement(By.name("login")).sendKeys("admin");

				} catch (NoSuchElementException e) {
					String nameValue = repairerObj.repair("authentication", "name", "login");
					String xpathExpression = "//*[@name='" + nameValue + "']";
					driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
				}

				try {

					driver.findElement(By.id("password")).clear();

				} catch (NoSuchElementException e) {
					String idValue = repairerObj.repair("authentication", "id", "password");
					String xpathExpression = "//*[@id='" + idValue + "']";
					driver.findElement(By.xpath(xpathExpression)).clear();
				}

				try {

					driver.findElement(By.name("password")).sendKeys("admin");

				} catch (NoSuchElementException e) {
					String nameValue = repairerObj.repair("authentication", "name", "password");
					String xpathExpression = "//*[@name='" + nameValue + "']";
					driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
				}

				try {

					driver.findElement(By.xpath("//*[@id=\"loginBox\"]/form/fieldset/button")).click();

				} catch (NoSuchElementException e) {
					String new_value = repairerObj.repair("authentication", "text", "Enter");
					String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
					driver.findElement(By.xpath(xpathExpression)).click();
				}


				try {

					driver.findElement(By.xpath("//*[@id=\"userBannerLeft\"]/ul/li[3]/span/a")).click();

				} catch (NoSuchElementException e) {
					String new_value = repairerObj.repair("admin", "text", "Platform administration");
					String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
					driver.findElement(By.xpath(xpathExpression)).click();
				}

				
				try {

					WebElement ele = driver.findElement(By.xpath("//*[@id=\"claroBody\"]/ul/li[6]/ul/li/a"));
					JavascriptExecutor executor = (JavascriptExecutor) driver;
					executor.executeScript("arguments[0].click();", ele);
					flag = 1;
				} catch (NoSuchElementException e) {
					String new_value = repairerObj.repair("admin", "text", "Internal messaging");
					String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
					WebElement ele = driver.findElement(By.xpath(xpathExpression));
					JavascriptExecutor executor = (JavascriptExecutor) driver;
					executor.executeScript("arguments[0].click();", ele);
					flag = 2;
				}
				try {

					driver.findElements(By.xpath("//*[@id=\"claroBody\"]/ul[2]/li[3]/a")).get(0).click();   //click on All messages older than

				} catch (NoSuchElementException e) {
					String new_value = repairerObj.repair("admin", "text", "All messages older than");
					String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
					driver.findElement(By.xpath(xpathExpression)).click();
					
				}
			try {

				driver.findElements(By.xpath("//*[@id=\"claroBody\"]/div[2]/div/form/input[2]")).get(0).click();   //click on Delete

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("admin_delete", "value", "Delete");
				String xpathExpression = "//input[@value='" + new_value + "']";
				driver.findElement(By.xpath(xpathExpression)).click();
				
			}
			try {

				driver.findElements(By.xpath("//*[@id=\"claroBody\"]/div[2]/div[3]/a[1]")).get(0).click();   //click on yes

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("admin_delete", "text", "Yes");
				String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
				driver.findElement(By.xpath(xpathExpression)).click();
				
			}
			try {

				Assert.assertTrue(driver.findElement(By.cssSelector("BODY")).getText()
						.matches("^[\\s\\S]*" + "Back" + "[\\s\\S]*$"));
			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("messaging", "id", "claroBody");
				String xpathExpression = "//*[@id='" + idValue + "']";
				AssertJUnit.assertEquals(driver.findElement(By.xpath(xpathExpression)).getText(), "Back");

			}
			// logout
			try {
				driver.findElement(By.xpath("//*[@id=\"userBannerRight\"]/ul/li[3]/span/a")).click(); // click on
																												// logout

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("tools", "id", "userBannerRight");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElements(By.xpath(xpathExpression)).get(0).click();
			}
		}
	  @Test(priority =7 ,groups= "regression")
		public void read_message__2()throws Exception
		{
		  currrent_test="read_message__2";
			
			
			    try {

					driver.findElement(By.id("login")).clear();

				} catch (NoSuchElementException e) {
					String idValue = repairerObj.repair("authentication", "id", "login");
					String xpathExpression = "//*[@id='" + idValue + "']";
					driver.findElement(By.xpath(xpathExpression)).clear();
				}

				try {

					driver.findElement(By.name("login")).sendKeys("admin");

				} catch (NoSuchElementException e) {
					String nameValue = repairerObj.repair("authentication", "name", "login");
					String xpathExpression = "//*[@name='" + nameValue + "']";
					driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
				}

				try {

					driver.findElement(By.id("password")).clear();

				} catch (NoSuchElementException e) {
					String idValue = repairerObj.repair("authentication", "id", "password");
					String xpathExpression = "//*[@id='" + idValue + "']";
					driver.findElement(By.xpath(xpathExpression)).clear();
				}

				try {

					driver.findElement(By.name("password")).sendKeys("admin");

				} catch (NoSuchElementException e) {
					String nameValue = repairerObj.repair("authentication", "name", "password");
					String xpathExpression = "//*[@name='" + nameValue + "']";
					driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
				}

				try {

					driver.findElement(By.xpath("//*[@id=\"loginBox\"]/form/fieldset/button")).click();

				} catch (NoSuchElementException e) {
					String new_value = repairerObj.repair("authentication", "text", "Enter");
					String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
					driver.findElement(By.xpath(xpathExpression)).click();
				}


				try {

					driver.findElement(By.xpath("//*[@id=\"userBannerLeft\"]/ul/li[3]/span/a")).click();

				} catch (NoSuchElementException e) {
					String new_value = repairerObj.repair("admin", "text", "Platform administration");
					String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
					driver.findElement(By.xpath(xpathExpression)).click();
				}

				
				try {

					WebElement ele = driver.findElement(By.xpath("//*[@id=\"claroBody\"]/ul/li[6]/ul/li/a"));
					JavascriptExecutor executor = (JavascriptExecutor) driver;
					executor.executeScript("arguments[0].click();", ele);
					flag = 1;
				} catch (NoSuchElementException e) {
					String new_value = repairerObj.repair("admin", "text", "Internal messaging");
					String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
					WebElement ele = driver.findElement(By.xpath(xpathExpression));
					JavascriptExecutor executor = (JavascriptExecutor) driver;
					executor.executeScript("arguments[0].click();", ele);
					flag = 2;
				}
				try {

					driver.findElements(By.xpath("//*[@id=\"claroBody\"]/ul[2]/li[1]/a")).get(0).click();   //click on All messages
				} catch (NoSuchElementException e) {
					String new_value = repairerObj.repair("messaging", "text", "All messages");
					String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
					driver.findElement(By.xpath(xpathExpression)).click();
					
				}
				try {

					driver.findElements(By.xpath("//*[@id=\"claroBody\"]/div[2]/div[3]/a[1]")).get(0).click();   //click on yes
				} catch (NoSuchElementException e) {
					String new_value = repairerObj.repair("admin_delete", "text", "Yes");
					String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
					driver.findElement(By.xpath(xpathExpression)).click();
					
				}
				
				
				    try {

						Assert.assertTrue(driver.findElement(By.cssSelector("BODY")).getText()
								.matches("^[\\s\\S]*" + "Back" + "[\\s\\S]*$"));
					} catch (NoSuchElementException e) {
						String idValue = repairerObj.repair("messaging", "id", "claroBody");
						String xpathExpression = "//*[@id='" + idValue + "']";
						AssertJUnit.assertEquals(driver.findElement(By.xpath(xpathExpression)).getText(), "Back");

					}
					// logout
					try {
						driver.findElement(By.xpath("//*[@id=\"userBannerRight\"]/ul/li[3]/span/a")).click(); // click on
																														// logout

					} catch (NoSuchElementException e) {
						String idValue = repairerObj.repair("tools", "id", "userBannerRight");
						String xpathExpression = "//*[@id='" + idValue + "']";
						driver.findElements(By.xpath(xpathExpression)).get(0).click();
					}
		}
	  
	  @Test(priority =8 ,groups= "regression")
		public void messaging_2() throws Exception
		{
			
		
		  currrent_test="messaging_2";

			    try {

					driver.findElement(By.id("login")).clear();

				} catch (NoSuchElementException e) {
					String idValue = repairerObj.repair("authentication", "id", "login");
					String xpathExpression = "//*[@id='" + idValue + "']";
					driver.findElement(By.xpath(xpathExpression)).clear();
				}

				try {

					driver.findElement(By.name("login")).sendKeys("admin");

				} catch (NoSuchElementException e) {
					String nameValue = repairerObj.repair("authentication", "name", "login");
					String xpathExpression = "//*[@name='" + nameValue + "']";
					driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
				}

				try {

					driver.findElement(By.id("password")).clear();

				} catch (NoSuchElementException e) {
					String idValue = repairerObj.repair("authentication", "id", "password");
					String xpathExpression = "//*[@id='" + idValue + "']";
					driver.findElement(By.xpath(xpathExpression)).clear();
				}

				try {

					driver.findElement(By.name("password")).sendKeys("admin");

				} catch (NoSuchElementException e) {
					String nameValue = repairerObj.repair("authentication", "name", "password");
					String xpathExpression = "//*[@name='" + nameValue + "']";
					driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
				}

				try {

					driver.findElement(By.xpath("//*[@id=\"loginBox\"]/form/fieldset/button")).click();

				} catch (NoSuchElementException e) {
					String new_value = repairerObj.repair("authentication", "text", "Enter");
					String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
					driver.findElement(By.xpath(xpathExpression)).click();
				}


				try {

					driver.findElement(By.xpath("//*[@id=\"userBannerLeft\"]/ul/li[3]/span/a")).click();

				} catch (NoSuchElementException e) {
					String new_value = repairerObj.repair("admin", "text", "Platform administration");
					String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
					driver.findElement(By.xpath(xpathExpression)).click();
				}

				
				try {

					WebElement ele = driver.findElement(By.xpath("//*[@id=\"claroBody\"]/ul/li[6]/ul/li/a"));
					JavascriptExecutor executor = (JavascriptExecutor) driver;
					executor.executeScript("arguments[0].click();", ele);
					flag = 1;
				} catch (NoSuchElementException e) {
					String new_value = repairerObj.repair("admin", "text", "Internal messaging");
					String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
					WebElement ele = driver.findElement(By.xpath(xpathExpression));
					JavascriptExecutor executor = (JavascriptExecutor) driver;
					executor.executeScript("arguments[0].click();", ele);
					flag = 2;
				}
				try {

					driver.findElements(By.xpath("//*[@id=\"claroBody\"]/ul[2]/li[4]/a")).get(0).click();   //click on All platform messages
				} catch (NoSuchElementException e) {
					String new_value = repairerObj.repair("messaging", "text", "All platform messages");
					String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
					driver.findElement(By.xpath(xpathExpression)).click();
					
				}
				try {

					driver.findElements(By.xpath("//*[@id=\"claroBody\"]/div[2]/div[3]/a[1]")).get(0).click();   //click on yes
				} catch (NoSuchElementException e) {
					String new_value = repairerObj.repair("admin_delete", "text", "Yes");
					String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
					driver.findElement(By.xpath(xpathExpression)).click();
					
				}
				
				
				    try {

						Assert.assertTrue(driver.findElement(By.cssSelector("BODY")).getText()
								.matches("^[\\s\\S]*" + "Back" + "[\\s\\S]*$"));
					} catch (NoSuchElementException e) {
						String idValue = repairerObj.repair("messaging", "id", "claroBody");
						String xpathExpression = "//*[@id='" + idValue + "']";
						AssertJUnit.assertEquals(driver.findElement(By.xpath(xpathExpression)).getText(), "Back");

					}
					// logout
					try {
						driver.findElement(By.xpath("//*[@id=\"userBannerRight\"]/ul/li[3]/span/a")).click(); // click on
																														// logout

					} catch (NoSuchElementException e) {
						String idValue = repairerObj.repair("tools", "id", "userBannerRight");
						String xpathExpression = "//*[@id='" + idValue + "']";
						driver.findElements(By.xpath(xpathExpression)).get(0).click();
					}
		}
	  
	  

}
