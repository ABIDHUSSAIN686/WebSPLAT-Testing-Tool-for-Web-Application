

import org.junit.Assert;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.testng.AssertJUnit;
import org.testng.annotations.Test;


public class ManageClasses extends DriverIntializor {
	@Test(priority =1 ,groups= "regression")
	public void admin_class__1()throws Exception
	{
		 currrent_test="admin_class__1";
		
		 try {

				driver.findElement(By.id("login")).clear();

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("authentication", "id", "login");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElement(By.xpath(xpathExpression)).clear();
			}

			try {

				driver.findElement(By.name("login")).sendKeys("admin");

			} catch (NoSuchElementException e) {
				String nameValue = repairerObj.repair("authentication", "name", "login");
				String xpathExpression = "//*[@name='" + nameValue + "']";
				driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
			}

			try {

				driver.findElement(By.id("password")).clear();

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("authentication", "id", "password");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElement(By.xpath(xpathExpression)).clear();
			}

			try {

				driver.findElement(By.name("password")).sendKeys("admin");

			} catch (NoSuchElementException e) {
				String nameValue = repairerObj.repair("authentication", "name", "password");
				String xpathExpression = "//*[@name='" + nameValue + "']";
				driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
			}

			try {

				driver.findElement(By.xpath("//*[@id=\"loginBox\"]/form/fieldset/button")).click();

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("authentication", "text", "Enter");
				String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
				driver.findElement(By.xpath(xpathExpression)).click();
			}

			try {

				driver.findElement(By.xpath("//*[@id=\"userBannerLeft\"]/ul/li[3]/span/a")).click();

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("admin", "text", "Platform administration");
				String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
				driver.findElement(By.xpath(xpathExpression)).click();
			}

			try {

				driver.findElement(By.xpath("//*[@id=\"claroBody\"]/ul/li[1]/ul/li[6]/a")).click();   //click on Manage classes
				flag = 1;																				

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("admin", "text", "Manage classes");
				String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
				driver.findElement(By.xpath(xpathExpression)).click();
				flag = 2;
			}

		try {

			driver.findElement(By.xpath("//*[@id=\"claroBody\"]/div[1]/table/tbody/tr/td[2]/ul/li/a")).click();   //click  on create a new class
																								

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("admin_class", "text", "Create a new class");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();

		}
		try {

			driver.findElement(By.name("class_name")).sendKeys("class1");  //set the value

		} catch (NoSuchElementException e) {
			String nameValue = repairerObj.repair("admin_class", "name", "class_name");
			String xpathExpression = "//*[@name='" + nameValue + "']";
			driver.findElement(By.xpath(xpathExpression)).sendKeys("class1");
		}
		try {

			driver.findElement(By.xpath("//*[@id=\"claroBody\"]/div[2]/div/form/table/tbody/tr[2]/td[2]/input")).click();   //click on OK
																								

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("admin_class", "value", " Ok ");
			String xpathExpression = "//input[@value='" + new_value + "']";
			driver.findElement(By.xpath(xpathExpression)).click();

		}
		
		try {

			Assert.assertTrue(driver.findElement(By.cssSelector("BODY")).getText()
					.matches("^[\\s\\S]*" + "The new class has been created" + "[\\s\\S]*$"));
		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("admin_class", "id", "claroBody");
			String xpathExpression = "//*[@id='" + idValue + "']";
			AssertJUnit.assertEquals(driver.findElement(By.xpath(xpathExpression)).getText(), "The new class has been created");

		}
		try {
			driver.findElements(By.xpath("//*[@id=\"userBannerRight\"]/ul/li[3]/span/a")).get(0).click(); // click on
																											// logout

		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("document", "id", "userBannerRight");
			String xpathExpression = "//*[@id='" + idValue + "']";
			driver.findElements(By.xpath(xpathExpression)).get(0).click();
		}
		}
	@Test(priority =2 ,groups= "regression")
	public void admin__1()throws Exception
	{
		 currrent_test="admin__1";
		
		 try {

				driver.findElement(By.id("login")).clear();

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("authentication", "id", "login");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElement(By.xpath(xpathExpression)).clear();
			}

			try {

				driver.findElement(By.name("login")).sendKeys("admin");

			} catch (NoSuchElementException e) {
				String nameValue = repairerObj.repair("authentication", "name", "login");
				String xpathExpression = "//*[@name='" + nameValue + "']";
				driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
			}

			try {

				driver.findElement(By.id("password")).clear();

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("authentication", "id", "password");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElement(By.xpath(xpathExpression)).clear();
			}

			try {

				driver.findElement(By.name("password")).sendKeys("admin");

			} catch (NoSuchElementException e) {
				String nameValue = repairerObj.repair("authentication", "name", "password");
				String xpathExpression = "//*[@name='" + nameValue + "']";
				driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
			}

			try {

				driver.findElement(By.xpath("//*[@id=\"loginBox\"]/form/fieldset/button")).click();

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("authentication", "text", "Enter");
				String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
				driver.findElement(By.xpath(xpathExpression)).click();
			}

			try {

				driver.findElement(By.xpath("//*[@id=\"userBannerLeft\"]/ul/li[3]/span/a")).click();

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("admin", "text", "Platform administration");
				String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
				driver.findElement(By.xpath(xpathExpression)).click();
			}

			try {

				driver.findElement(By.xpath("//*[@id=\"claroBody\"]/ul/li[1]/ul/li[6]/a")).click();   //click on Manage classes
				flag = 1;																				

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("admin", "text", "Manage classes");
				String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
				driver.findElement(By.xpath(xpathExpression)).click();
				flag = 2;
			}

		try {

			driver.findElement(By.xpath("//*[@id=\"claroBody\"]/table/tbody/tr/td[4]/a/img")).click();   //click  on edit
																								

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("admin_class", "alt", "Edit");
			String xpathExpression = "//img[@alt='" + new_value + "']";
			driver.findElement(By.xpath(xpathExpression)).click();

		}
		 try {

				driver.findElement(By.name("class_name")).clear();

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("admin_class", "name", "class_name");
				String xpathExpression = "//*[@name='" + new_value + "']";
				driver.findElement(By.xpath(xpathExpression)).clear();
			}

		try {

			driver.findElement(By.name("class_name")).sendKeys("class2");  //set the value

		} catch (NoSuchElementException e) {
			String nameValue = repairerObj.repair("admin_class", "name", "class_name");
			String xpathExpression = "//*[@name='" + nameValue + "']";
			driver.findElement(By.xpath(xpathExpression)).sendKeys("class2");
		}
		try {

			driver.findElement(By.xpath("//*[@id=\"claroBody\"]/div[2]/div/form/table/tbody/tr[2]/td[2]/input")).click();   //click on OK
																								

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("admin_class", "value", " Ok ");
			String xpathExpression = "//input[@value='" + new_value + "']";
			driver.findElement(By.xpath(xpathExpression)).click();

		}
		
		try {

			Assert.assertTrue(driver.findElement(By.cssSelector("BODY")).getText()
					.matches("^[\\s\\S]*" + "Name of the class has been changed" + "[\\s\\S]*$"));
		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("admin_class", "id", "claroBody");
			String xpathExpression = "//*[@id='" + idValue + "']";
			AssertJUnit.assertEquals(driver.findElement(By.xpath(xpathExpression)).getText(), "Name of the class has been changed");

		}
		try {
			driver.findElements(By.xpath("//*[@id=\"userBannerRight\"]/ul/li[3]/span/a")).get(0).click(); // click on
																											// logout

		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("document", "id", "userBannerRight");
			String xpathExpression = "//*[@id='" + idValue + "']";
			driver.findElements(By.xpath(xpathExpression)).get(0).click();
		}
		}
	@Test(priority =3 ,groups= "regression")
	public void admin_class__2()throws Exception
	{
		currrent_test="admin_class__2";
		 try {

				driver.findElement(By.id("login")).clear();

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("authentication", "id", "login");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElement(By.xpath(xpathExpression)).clear();
			}

			try {

				driver.findElement(By.name("login")).sendKeys("admin");

			} catch (NoSuchElementException e) {
				String nameValue = repairerObj.repair("authentication", "name", "login");
				String xpathExpression = "//*[@name='" + nameValue + "']";
				driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
			}

			try {

				driver.findElement(By.id("password")).clear();

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("authentication", "id", "password");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElement(By.xpath(xpathExpression)).clear();
			}

			try {

				driver.findElement(By.name("password")).sendKeys("admin");

			} catch (NoSuchElementException e) {
				String nameValue = repairerObj.repair("authentication", "name", "password");
				String xpathExpression = "//*[@name='" + nameValue + "']";
				driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
			}

			try {

				driver.findElement(By.xpath("//*[@id=\"loginBox\"]/form/fieldset/button")).click();

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("authentication", "text", "Enter");
				String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
				driver.findElement(By.xpath(xpathExpression)).click();
			}

			try {

				driver.findElement(By.xpath("//*[@id=\"userBannerLeft\"]/ul/li[3]/span/a")).click();

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("admin", "text", "Platform administration");
				String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
				driver.findElement(By.xpath(xpathExpression)).click();
			}

			try {

				driver.findElement(By.xpath("//*[@id=\"claroBody\"]/ul/li[1]/ul/li[6]/a")).click();   //click on Manage classes
				flag = 1;																			

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("admin", "text", "Manage classes");
				String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
				driver.findElement(By.xpath(xpathExpression)).click();
				flag = 2;
			}

		try {

			driver.findElement(By.xpath("//*[@id=\"claroBody\"]/div[1]/table/tbody/tr/td[2]/ul/li[2]/a")).click();   //click  on empty all classes
																								

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("admin_class", "text", "Empty all classes");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();

		}
		Alert alert = driver.switchTo().alert();
        alert.accept();
		try {

			Assert.assertTrue(driver.findElement(By.cssSelector("BODY")).getText()
					.matches("^[\\s\\S]*" + "All classes emptied" + "[\\s\\S]*$"));
		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("admin_class", "id", "claroBody");
			String xpathExpression = "//*[@id='" + idValue + "']";
			AssertJUnit.assertEquals(driver.findElement(By.xpath(xpathExpression)).getText(), "All classes emptied");

		}
		try {
			driver.findElements(By.xpath("//*[@id=\"userBannerRight\"]/ul/li[3]/span/a")).get(0).click(); // click on
																											// logout

		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("document", "id", "userBannerRight");
			String xpathExpression = "//*[@id='" + idValue + "']";
			driver.findElements(By.xpath(xpathExpression)).get(0).click();
		}

	}
	
	@Test(priority =4 ,groups= "regression")
	public void admin_class__3()throws Exception
	{
		currrent_test="admin_class__3";
		 try {

				driver.findElement(By.id("login")).clear();

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("authentication", "id", "login");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElement(By.xpath(xpathExpression)).clear();
			}

			try {

				driver.findElement(By.name("login")).sendKeys("admin");

			} catch (NoSuchElementException e) {
				String nameValue = repairerObj.repair("authentication", "name", "login");
				String xpathExpression = "//*[@name='" + nameValue + "']";
				driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
			}

			try {

				driver.findElement(By.id("password")).clear();

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("authentication", "id", "password");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElement(By.xpath(xpathExpression)).clear();
			}

			try {

				driver.findElement(By.name("password")).sendKeys("admin");

			} catch (NoSuchElementException e) {
				String nameValue = repairerObj.repair("authentication", "name", "password");
				String xpathExpression = "//*[@name='" + nameValue + "']";
				driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
			}

			try {

				driver.findElement(By.xpath("//*[@id=\"loginBox\"]/form/fieldset/button")).click();

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("authentication", "text", "Enter");
				String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
				driver.findElement(By.xpath(xpathExpression)).click();
			}

			try {

				driver.findElement(By.xpath("//*[@id=\"userBannerLeft\"]/ul/li[3]/span/a")).click();

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("admin", "text", "Platform administration");
				String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
				driver.findElement(By.xpath(xpathExpression)).click();
			}

			try {

				driver.findElement(By.xpath("//*[@id=\"claroBody\"]/ul/li[1]/ul/li[6]/a")).click();   //click on Manage classes
				flag = 1;																	

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("admin", "text", "Manage classes");
				String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
				driver.findElement(By.xpath(xpathExpression)).click();
				flag = 2;
			}
			try {

				driver.findElement(By.xpath("//*[@id=\"claroBody\"]/table/tbody/tr/td[6]/a/img")).click();   //click  on delete
																									

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("admin_class", "alt", "Edit");
				String xpathExpression = "//img[@alt='" + new_value + "']";
				driver.findElement(By.xpath(xpathExpression)).click();

			}
		Alert alert = driver.switchTo().alert();
        alert.accept();
        
        try {

			Assert.assertTrue(driver.findElement(By.cssSelector("BODY")).getText()
					.matches("^[\\s\\S]*" + "Class deleted" + "[\\s\\S]*$"));
		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("admin_class", "id", "claroBody");
			String xpathExpression = "//*[@id='" + idValue + "']";
			AssertJUnit.assertEquals(driver.findElement(By.xpath(xpathExpression)).getText(), "Class deleted");

		}
		try {
			driver.findElements(By.xpath("//*[@id=\"userBannerRight\"]/ul/li[3]/span/a")).get(0).click(); // click on
																											// logout

		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("document", "id", "userBannerRight");
			String xpathExpression = "//*[@id='" + idValue + "']";
			driver.findElements(By.xpath(xpathExpression)).get(0).click();
		}
	}
	
	@Test(priority =5 ,groups= "regression")
	public void admin__2()throws Exception
	{
		currrent_test="admin__2";
		 try {

				driver.findElement(By.id("login")).clear();

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("authentication", "id", "login");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElement(By.xpath(xpathExpression)).clear();
			}

			try {

				driver.findElement(By.name("login")).sendKeys("admin");

			} catch (NoSuchElementException e) {
				String nameValue = repairerObj.repair("authentication", "name", "login");
				String xpathExpression = "//*[@name='" + nameValue + "']";
				driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
			}

			try {

				driver.findElement(By.id("password")).clear();

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("authentication", "id", "password");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElement(By.xpath(xpathExpression)).clear();
			}

			try {

				driver.findElement(By.name("password")).sendKeys("admin");

			} catch (NoSuchElementException e) {
				String nameValue = repairerObj.repair("authentication", "name", "password");
				String xpathExpression = "//*[@name='" + nameValue + "']";
				driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
			}

			try {

				driver.findElement(By.xpath("//*[@id=\"loginBox\"]/form/fieldset/button")).click();

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("authentication", "text", "Enter");
				String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
				driver.findElement(By.xpath(xpathExpression)).click();
			}

			try {

				driver.findElement(By.xpath("//*[@id=\"userBannerLeft\"]/ul/li[3]/span/a")).click();

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("admin", "text", "Platform administration");
				String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
				driver.findElement(By.xpath(xpathExpression)).click();
			}

			try {

				driver.findElement(By.xpath("//*[@id=\"claroBody\"]/ul/li[1]/ul/li[6]/a")).click();   //click on Manage classes
				flag = 1;																			

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("admin", "text", "Manage classes");
				String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
				driver.findElement(By.xpath(xpathExpression)).click();
				flag = 2;
			}

		try {

			driver.findElement(By.xpath("//*[@id=\"claroBody\"]/div[1]/table/tbody/tr/td[2]/ul/li/a")).click();   //click  on create a new class
																								

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("admin_class", "text", "Create a new class");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();

		}
		try {

			driver.findElement(By.name("class_name")).sendKeys("class2");  //set the value

		} catch (NoSuchElementException e) {
			String nameValue = repairerObj.repair("admin_class", "name", "class_name");
			String xpathExpression = "//*[@name='" + nameValue + "']";
			driver.findElement(By.xpath(xpathExpression)).sendKeys("class2");
		}
		try {

			driver.findElement(By.xpath("//*[@id=\"claroBody\"]/div[2]/div/form/table/tbody/tr[2]/td[2]/input")).click();   //click on OK
																								

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("admin_class", "value", " Ok ");
			String xpathExpression = "//input[@value='" + new_value + "']";
			driver.findElement(By.xpath(xpathExpression)).click();

		}
		
		
		try {

			driver.findElement(By.xpath("//*[@id=\"claroBody\"]/div[1]/table/tbody/tr/td[2]/ul/li[3]/a")).click();  //click on Delete all classes
																								

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("admin_class", "value", "Delete all classes");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();

		}
		
		Alert alert = driver.switchTo().alert();
        alert.accept();
		
			
			 try {

					Assert.assertTrue(driver.findElement(By.cssSelector("BODY")).getText()
							.matches("^[\\s\\S]*" + "All classes deleted" + "[\\s\\S]*$"));
				} catch (NoSuchElementException e) {
					String idValue = repairerObj.repair("admin_class", "id", "claroBody");
					String xpathExpression = "//*[@id='" + idValue + "']";
					AssertJUnit.assertEquals(driver.findElement(By.xpath(xpathExpression)).getText(), "All classes deleted");

				}
				try {
					driver.findElements(By.xpath("//*[@id=\"userBannerRight\"]/ul/li[3]/span/a")).get(0).click(); // click on
																													// logout

				} catch (NoSuchElementException e) {
					String idValue = repairerObj.repair("document", "id", "userBannerRight");
					String xpathExpression = "//*[@id='" + idValue + "']";
					driver.findElements(By.xpath(xpathExpression)).get(0).click();
				}
	}

}
