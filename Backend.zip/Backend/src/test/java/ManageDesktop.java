

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.testng.annotations.Test;

public class ManageDesktop extends DriverIntializor{

	  @Test(priority =1 ,groups= "regression")
		public void settings__1()throws Exception
		{
		  currrent_test="settings__1";
		  try {

				driver.findElement(By.id("login")).clear();

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("authentication", "id", "login");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElement(By.xpath(xpathExpression)).clear();
			}

			try {

				driver.findElement(By.name("login")).sendKeys("admin");

			} catch (NoSuchElementException e) {
				String nameValue = repairerObj.repair("authentication", "name", "login");
				String xpathExpression = "//*[@name='" + nameValue + "']";
				driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
			}

			try {

				driver.findElement(By.id("password")).clear();

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("authentication", "id", "password");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElement(By.xpath(xpathExpression)).clear();
			}

			try {

				driver.findElement(By.name("password")).sendKeys("admin");

			} catch (NoSuchElementException e) {
				String nameValue = repairerObj.repair("authentication", "name", "password");
				String xpathExpression = "//*[@name='" + nameValue + "']";
				driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
			}

			try {

				driver.findElement(By.xpath("//*[@id=\"loginBox\"]/form/fieldset/button")).click();

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("authentication", "text", "Enter");
				String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
				driver.findElement(By.xpath(xpathExpression)).click();
			}

			try {

				driver.findElement(By.xpath("//*[@id=\"userBannerLeft\"]/ul/li[3]/span/a")).click();

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("admin", "text", "Platform administration");
				String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
				driver.findElement(By.xpath(xpathExpression)).click();
			}

			try {

				driver.findElement(By.xpath("//*[@id=\"claroBody\"]/ul/li[1]/ul/li[8]/a")).click();   //click on Manage Desktop
				flag = 1;																				

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("admin", "text", "Manage user desktop");
				String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
				driver.findElement(By.xpath(xpathExpression)).click();
				flag = 2;
			}
			 String str2 = "",str1 = "";
			try {

			     str2=driver.findElement(By.xpath("//*[@id=\"claroBody\"]/table/tbody/tr[1]/td[2]/a/img")).getAttribute("alt");
																									

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("config", "alt", "visible");
				String xpathExpression = "//img[@alt='" + new_value + "']";
				 str2=driver.findElement(By.xpath(xpathExpression)).getAttribute("alt");

			}
			try {

				driver.findElement(By.xpath("//*[@id=\"claroBody\"]/table/tbody/tr[1]/td[2]/a/img")).click();   //click  on visibility
																									

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("config", "alt", "visible");
				String xpathExpression = "//img[@alt='" + new_value + "']";
				driver.findElement(By.xpath(xpathExpression)).click();

			}
			 try {

				 str1=driver.findElement(By.xpath("//*[@id=\"claroBody\"]/table/tbody/tr[1]/td[2]/a/img")).getAttribute("alt");
																									

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("config", "alt", "visible");
				String xpathExpression = "//img[@alt='" + new_value + "']";
				str1=driver.findElement(By.xpath(xpathExpression)).getAttribute("alt");

			}
				Assert.assertNotEquals(str1,str2);  //comparision
		
				try {
					driver.findElements(By.xpath("//*[@id=\"userBannerRight\"]/ul/li[3]/span/a")).get(0).click(); // click on
																													// logout

				} catch (NoSuchElementException e) {
					String idValue = repairerObj.repair("document", "id", "userBannerRight");
					String xpathExpression = "//*[@id='" + idValue + "']";
					driver.findElements(By.xpath(xpathExpression)).get(0).click();
				}
		}
	  
	  
	  @Test(priority =2,groups= "regression")
		public void config_edit__1()throws Exception
		{
		  currrent_test="config_edit__1";
		  try {

				driver.findElement(By.id("login")).clear();

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("authentication", "id", "login");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElement(By.xpath(xpathExpression)).clear();
			}

			try {

				driver.findElement(By.name("login")).sendKeys("admin");

			} catch (NoSuchElementException e) {
				String nameValue = repairerObj.repair("authentication", "name", "login");
				String xpathExpression = "//*[@name='" + nameValue + "']";
				driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
			}

			try {

				driver.findElement(By.id("password")).clear();

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("authentication", "id", "password");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElement(By.xpath(xpathExpression)).clear();
			}

			try {

				driver.findElement(By.name("password")).sendKeys("admin");

			} catch (NoSuchElementException e) {
				String nameValue = repairerObj.repair("authentication", "name", "password");
				String xpathExpression = "//*[@name='" + nameValue + "']";
				driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
			}

			try {

				driver.findElement(By.xpath("//*[@id=\"loginBox\"]/form/fieldset/button")).click();

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("authentication", "text", "Enter");
				String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
				driver.findElement(By.xpath(xpathExpression)).click();
			}

			try {

				driver.findElement(By.xpath("//*[@id=\"userBannerLeft\"]/ul/li[3]/span/a")).click();

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("admin", "text", "Platform administration");
				String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
				driver.findElement(By.xpath(xpathExpression)).click();
			}

			try {

				driver.findElement(By.xpath("//*[@id=\"claroBody\"]/ul/li[1]/ul/li[8]/a")).click();   //click on Manage Desktop
				flag = 1;																					

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("admin", "text", "Manage user desktop");
				String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
				driver.findElement(By.xpath(xpathExpression)).click();
				flag = 2;
			}
			 String str2 = "",str1 = "";
				try {
					 str2=driver.findElement(By.xpath("//*[@id=\"claroBody\"]/table/tbody/tr[1]/td[1]")).getText();  //get test of field
					 System.out.println(str2);
				 																						

				} catch (NoSuchElementException e) {
					String new_value = repairerObj.repair("config", "alt", "visible");
					String xpathExpression = "//img[@alt='" + new_value + "']";
					 str2=driver.findElement(By.xpath(xpathExpression)).getText();

				}
				try {

					driver.findElement(By.xpath("//*[@id=\"claroBody\"]/table/tbody/tr[1]/td[4]/a/img")).click();   //click  on move button
																										

				} catch (NoSuchElementException e) {
					String new_value = repairerObj.repair("config", "alt", "Move up");
					String xpathExpression = "//img[@alt='" + new_value + "']";
					driver.findElement(By.xpath(xpathExpression)).click();

				}
				 try {

					 str1=driver.findElement(By.xpath("//*[@id=\"claroBody\"]/table/tbody/tr[1]/td[1]")).getText();  //get test of field
					 System.out.println(str1);

				} catch (NoSuchElementException e) {
					String new_value = repairerObj.repair("config", "alt", "visible");
					String xpathExpression = "//img[@alt='" + new_value + "']";
					str1=driver.findElement(By.xpath(xpathExpression)).getAttribute("alt");

				}
					Assert.assertNotEquals(str1,str2);  //comparision
			
					try {
						driver.findElements(By.xpath("//*[@id=\"userBannerRight\"]/ul/li[3]/span/a")).get(0).click(); // click on
																														// logout

					} catch (NoSuchElementException e) {
						String idValue = repairerObj.repair("document", "id", "userBannerRight");
						String xpathExpression = "//*[@id='" + idValue + "']";
						driver.findElements(By.xpath(xpathExpression)).get(0).click();
					}
		} 

}
