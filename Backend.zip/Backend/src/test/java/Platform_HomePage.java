

import org.testng.annotations.Test;
import org.testng.Assert;
import org.testng.AssertJUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;

public class Platform_HomePage extends DriverIntializor {
	@SuppressWarnings("unused")
	private boolean acceptNextAlert = true;
	@SuppressWarnings("unused")
	private StringBuffer verificationErrors = new StringBuffer();

	@Test(priority = 2, groups = "regression")
	public void config_edit__1() throws Exception {
		currrent_test="config_edit__1";
		try {

			driver.findElement(By.id("login")).clear();

		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("authentication", "id", "login");
			String xpathExpression = "//*[@id='" + idValue + "']";
			driver.findElement(By.xpath(xpathExpression)).clear();
		}

		try {

			driver.findElement(By.name("login")).sendKeys("admin");

		} catch (NoSuchElementException e) {
			String nameValue = repairerObj.repair("authentication", "name", "login");
			String xpathExpression = "//*[@name='" + nameValue + "']";
			driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
		}

		try {

			driver.findElement(By.id("password")).clear();

		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("authentication", "id", "password");
			String xpathExpression = "//*[@id='" + idValue + "']";
			driver.findElement(By.xpath(xpathExpression)).clear();
		}

		try {

			driver.findElement(By.name("password")).sendKeys("admin");

		} catch (NoSuchElementException e) {
			String nameValue = repairerObj.repair("authentication", "name", "password");
			String xpathExpression = "//*[@name='" + nameValue + "']";
			driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
		}

		try {

			driver.findElement(By.xpath("//*[@id=\"loginBox\"]/form/fieldset/button")).click();

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("authentication", "text", "Enter");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();
		}

		try {

			driver.findElement(By.xpath("//*[@id=\"userBannerLeft\"]/ul/li[3]/span/a")).click();

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("admin", "text", "Platform administration");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();
		}

		try {

			driver.findElement(By.xpath("//*[@id=\"claroBody\"]/ul/li[3]/ul/li[1]/a")).click();
			flag = 1;
		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("admin", "text", "Configuration");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();
			flag = 2;
		}
		try {

			driver.findElement(By.xpath("//*[@id=\"claroBody\"]/ul[1]/li[1]/a")).click();

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("config_list", "text", "Home page");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();

		}
		// ***********************************Configuration_HomePage()*****************************
		// ***********************************Course List
		// *****************************************
		try {

			driver.findElement(By.xpath("//*[@id=\"navlist\"]/li[1]/a")).click();
			
		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("config_edit", "text", "Course list");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();
			
		}

		try {

			driver.findElement(By.xpath("//*[@id=\"label_course_order_by_course_title\"]")).click();

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("config_edit", "id", "label_course_order_by_course_title");
			String xpathExpression = "//*[@id='" + new_value + "']";
			driver.findElement(By.xpath(xpathExpression)).click();

		}
		try {

			driver.findElement(By.id("label_categories_order_by")).click();

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("config_edit", "id", "label_categories_order_by");
			String xpathExpression = "//*[@id='" + new_value + "']";
			driver.findElement(By.xpath(xpathExpression)).click();

		}

		try {

			driver.findElement(By.xpath("//*[@id=\"label_categories_order_by\"]/option[3]")).click();

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("config_edit", "option", "Alphabetical descending");
			String xpathExpression = "//option[text()='" + new_value + "']";
			driver.findElement(By.xpath(xpathExpression)).click();

		}
		try {

			driver.findElement(By.id("label_course_categories_hidden_to_anonymous_TRUE")).click();

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("config_edit", "id",
					"label_course_categories_hidden_to_anonymous_TRUE");
			String xpathExpression = "//*[@id='" + new_value + "']";
			driver.findElement(By.xpath(xpathExpression)).click();

		}

		try {

			WebElement ele = driver.findElement(By.xpath("//*[@id=\"claroBody\"]/form/table/tbody/tr[6]/td[2]/input"));
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", ele);

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("config_edit", "value", "Ok");
			String xpathExpression = "//input[@value='" + new_value + "']";
			WebElement ele = driver.findElement(By.xpath(xpathExpression));
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", ele);

		}

		try {

			Assert.assertTrue(driver.findElement(By.cssSelector("BODY")).getText().matches("^[\\s\\S]*"
					+ "Properties for Home page, \\(CLHOME\\) are now effective on server" + "[\\s\\S]*$"));
		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("userReport", "id", "claroBody");
			String xpathExpression = "//*[@id='" + idValue + "']";
			AssertJUnit.assertEquals(driver.findElement(By.xpath(xpathExpression)).getText(),
					"Properties for Home page, \\(CLHOME\\) are now effective on server");

		}
		// logout

		try {
			driver.findElements(By.xpath("//*[@id=\"userBannerRight\"]/ul/li[3]/span/a")).get(0).click(); // click on
																											// logout

		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("exercise", "id", "userBannerRight");
			String xpathExpression = "//*[@id='" + idValue + "']";
			driver.findElements(By.xpath(xpathExpression)).get(0).click();
		}
	}

	@Test(priority = 3, groups = "regression")
	public void course_Report__1() throws Exception {
		currrent_test="course_Report__1";
		try {

			driver.findElement(By.id("login")).clear();

		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("authentication", "id", "login");
			String xpathExpression = "//*[@id='" + idValue + "']";
			driver.findElement(By.xpath(xpathExpression)).clear();
		}

		try {

			driver.findElement(By.name("login")).sendKeys("admin");

		} catch (NoSuchElementException e) {
			String nameValue = repairerObj.repair("authentication", "name", "login");
			String xpathExpression = "//*[@name='" + nameValue + "']";
			driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
		}

		try {

			driver.findElement(By.id("password")).clear();

		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("authentication", "id", "password");
			String xpathExpression = "//*[@id='" + idValue + "']";
			driver.findElement(By.xpath(xpathExpression)).clear();
		}

		try {

			driver.findElement(By.name("password")).sendKeys("admin");

		} catch (NoSuchElementException e) {
			String nameValue = repairerObj.repair("authentication", "name", "password");
			String xpathExpression = "//*[@name='" + nameValue + "']";
			driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
		}

		try {

			driver.findElement(By.xpath("//*[@id=\"loginBox\"]/form/fieldset/button")).click();

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("authentication", "text", "Enter");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();
		}

		try {

			driver.findElement(By.xpath("//*[@id=\"userBannerLeft\"]/ul/li[3]/span/a")).click();

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("admin", "text", "Platform administration");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();
		}

		try {

			driver.findElement(By.xpath("//*[@id=\"claroBody\"]/ul/li[3]/ul/li[1]/a")).click();
			flag = 1;
		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("admin", "text", "Configuration");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();
			flag = 2;
		}
		try {

			driver.findElement(By.xpath("//*[@id=\"claroBody\"]/ul[1]/li[1]/a")).click();

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("config_list", "text", "Home page");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();

		}
		// ***********************************Configuration_HomePage()*****************************
		// *********************************** Display
		// *****************************************
		try {

			driver.findElement(By.xpath("//*[@id=\"navlist\"]/li[2]/a")).click();

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("config_edit", "text", "Display");
			String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
			driver.findElement(By.xpath(xpathExpression)).click();

		}

		try {

			driver.findElement(By.id("label_display_former_homepage_TRUE")).click();

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("config_edit", "id", "label_display_former_homepage_TRUE");
			String xpathExpression = "//*[@id='" + new_value + "']";
			driver.findElement(By.xpath(xpathExpression)).click();

		}
		try {

			driver.findElement(By.id("label_userDesktopMessageCollapsedByDefault_FALSE")).click();

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("config_edit", "id",
					"label_userDesktopMessageCollapsedByDefault_FALSE");
			String xpathExpression = "//*[@id='" + new_value + "']";
			driver.findElement(By.xpath(xpathExpression)).click();

		}
		try {

			WebElement ele = driver.findElement(By.xpath("//*[@id=\"claroBody\"]/form/table/tbody/tr[4]/td[2]/input"));
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", ele);

		} catch (NoSuchElementException e) {
			String new_value = repairerObj.repair("config_edit", "value", "Ok");
			String xpathExpression = "//input[@value='" + new_value + "']";
			WebElement ele = driver.findElement(By.xpath(xpathExpression));
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", ele);

		}
		try {

			Assert.assertTrue(driver.findElement(By.cssSelector("BODY")).getText().matches("^[\\s\\S]*"
					+ "Properties for Home page, \\(CLHOME\\) are now effective on server" + "[\\s\\S]*$"));
		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("userReport", "id", "claroBody");
			String xpathExpression = "//*[@id='" + idValue + "']";
			AssertJUnit.assertEquals(driver.findElement(By.xpath(xpathExpression)).getText(),
					"Properties for Home page, \\(CLHOME\\) are now effective on server");

		}
		// logout

		try {
			driver.findElements(By.xpath("//*[@id=\"userBannerRight\"]/ul/li[3]/span/a")).get(0).click(); // click on
																											// logout

		} catch (NoSuchElementException e) {
			String idValue = repairerObj.repair("exercise", "id", "userBannerRight");
			String xpathExpression = "//*[@id='" + idValue + "']";
			driver.findElements(By.xpath(xpathExpression)).get(0).click();
		}
	}

}
