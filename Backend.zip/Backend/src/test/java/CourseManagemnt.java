

import org.junit.Assert;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.testng.AssertJUnit;
import org.testng.annotations.Test;
public class CourseManagemnt extends DriverIntializor{

	  
	  @Test(priority =1 ,groups= "regression")
		public void chatting__1()throws Exception
		{
		  currrent_test="chatting__1";
		  
		  try {

				driver.findElement(By.id("login")).clear();

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("authentication", "id", "login");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElement(By.xpath(xpathExpression)).clear();
			}

			try {

				driver.findElement(By.name("login")).sendKeys("admin");

			} catch (NoSuchElementException e) {
				String nameValue = repairerObj.repair("authentication", "name", "login");
				String xpathExpression = "//*[@name='" + nameValue + "']";
				driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
			}

			try {

				driver.findElement(By.id("password")).clear();

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("authentication", "id", "password");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElement(By.xpath(xpathExpression)).clear();
			}

			try {

				driver.findElement(By.name("password")).sendKeys("admin");

			} catch (NoSuchElementException e) {
				String nameValue = repairerObj.repair("authentication", "name", "password");
				String xpathExpression = "//*[@name='" + nameValue + "']";
				driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
			}

			try {

				driver.findElement(By.xpath("//*[@id=\"loginBox\"]/form/fieldset/button")).click();

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("authentication", "text", "Enter");
				String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
				driver.findElement(By.xpath(xpathExpression)).click();
			}

			try {

				driver.findElement(By.xpath("//*[@id=\"userBannerLeft\"]/ul/li[3]/span/a")).click();

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("admin", "text", "Platform administration");
				String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
				driver.findElement(By.xpath(xpathExpression)).click();
			}

			try {

				driver.findElement(By.xpath("//*[@id=\"claroBody\"]/ul/li[2]/ul/li[2]/a")).click(); // click on Course list
				flag = 1;																				// button in Courses

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("admin", "text", "Course list");
				String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
				driver.findElement(By.xpath(xpathExpression)).click();
				flag = 2;
			}

			try {

				driver.findElement(By.xpath("//*[@id=\"claroBody\"]/table[2]/tbody/tr/td[2]/a")).click(); // click on Course
																											
			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("admin_courses", "text", "DATA STRUCTURE");
				String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
				driver.findElement(By.xpath(xpathExpression)).click();

			}
			
			try {

				WebElement ele = driver.findElement(By.xpath("//*[@id=\"CLCHAT\"]"));
				JavascriptExecutor executor = (JavascriptExecutor) driver;
				executor.executeScript("arguments[0].click();", ele);

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("course", "id", "CLCHAT");
				String xpathExpression = "//*[@id='" + new_value + "']";
				WebElement ele = driver.findElement(By.xpath(xpathExpression));
				JavascriptExecutor executor = (JavascriptExecutor) driver;
				executor.executeScript("arguments[0].click();", ele);

			}
			try {

				driver.findElement(By.id("clchat_msg")).clear();      //clear the field

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("chatting", "id", "clchat_msg");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElement(By.xpath(xpathExpression)).clear();
			}
			try {

				driver.findElement(By.id("clchat_msg")).sendKeys("hello");  //set the value

			} catch (NoSuchElementException e) {
				String nameValue = repairerObj.repair("chatting", "id", "clchat_msg");
				String xpathExpression = "//*[@id='" + nameValue + "']";
				driver.findElement(By.xpath(xpathExpression)).sendKeys("hello");
			}
			
			try {

				WebElement ele = driver.findElement(By.xpath("//*[@id=\"clchat_form\"]/input[4]"));   //click to send
				JavascriptExecutor executor = (JavascriptExecutor) driver;
				executor.executeScript("arguments[0].click();", ele);

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("chatting", "id", "clchat_form");
				String xpathExpression = "//*[@id='" + new_value + "']";
				WebElement ele = driver.findElement(By.xpath(xpathExpression));
				JavascriptExecutor executor = (JavascriptExecutor) driver;
				executor.executeScript("arguments[0].click();", ele);

			}
//			driver.findElement(By.linkText("Logout")).click();  //click to logout
		try {

			Assert.assertNotEquals(driver.findElement(By.xpath("//*[@id=\"clchat_msg\"]")).equals(null),null);   //click on chat

			} catch (NoSuchElementException e) {
				String nameValue = repairerObj.repair("chatting", "id", "clchat_msg");
				String xpathExpression = "//*[@id='" + nameValue + "']";
				Assert.assertNotEquals(driver.findElement(By.xpath(xpathExpression)).equals(null),null);   //click on chat
			}
			// logout
			try {

				WebElement ele = driver.findElement(By.xpath("//*[@id=\"userBannerRight\"]/ul/li[3]/span/a")); // click on logout
				JavascriptExecutor executor = (JavascriptExecutor) driver;
				executor.executeScript("arguments[0].click();", ele);

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("chatting", "id", "userBannerRight");
				String xpathExpression = "//*[@id='" + idValue + "']";
				WebElement ele = driver.findElement(By.xpath(xpathExpression));
				JavascriptExecutor executor = (JavascriptExecutor) driver;
				executor.executeScript("arguments[0].click();", ele);

			}
			
		}
	  
	  @Test(priority =2 ,groups= "regression")
		public void chatting__2()throws Exception
		{
			
		  currrent_test="chatting__2";

		  try {

				driver.findElement(By.id("login")).clear();

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("authentication", "id", "login");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElement(By.xpath(xpathExpression)).clear();
			}

			try {

				driver.findElement(By.name("login")).sendKeys("admin");

			} catch (NoSuchElementException e) {
				String nameValue = repairerObj.repair("authentication", "name", "login");
				String xpathExpression = "//*[@name='" + nameValue + "']";
				driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
			}

			try {

				driver.findElement(By.id("password")).clear();

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("authentication", "id", "password");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElement(By.xpath(xpathExpression)).clear();
			}

			try {

				driver.findElement(By.name("password")).sendKeys("admin");

			} catch (NoSuchElementException e) {
				String nameValue = repairerObj.repair("authentication", "name", "password");
				String xpathExpression = "//*[@name='" + nameValue + "']";
				driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
			}

			try {

				driver.findElement(By.xpath("//*[@id=\"loginBox\"]/form/fieldset/button")).click();

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("authentication", "text", "Enter");
				String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
				driver.findElement(By.xpath(xpathExpression)).click();
			}

			try {

				driver.findElement(By.xpath("//*[@id=\"userBannerLeft\"]/ul/li[3]/span/a")).click();

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("admin", "text", "Platform administration");
				String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
				driver.findElement(By.xpath(xpathExpression)).click();
			}

			try {

				driver.findElement(By.xpath("//*[@id=\"claroBody\"]/ul/li[2]/ul/li[2]/a")).click(); // click on Course list
				flag = 1;																				// button in Courses

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("admin", "text", "Course list");
				String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
				driver.findElement(By.xpath(xpathExpression)).click();
				flag = 2;
			}

			try {

				driver.findElement(By.xpath("//*[@id=\"claroBody\"]/table[2]/tbody/tr/td[2]/a")).click(); // click on Course
																											
			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("admin_courses", "text", "DATA STRUCTURE");
				String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
				driver.findElement(By.xpath(xpathExpression)).click();

			}
			
			try {

				WebElement ele = driver.findElement(By.xpath("//*[@id=\"CLCHAT\"]"));
				JavascriptExecutor executor = (JavascriptExecutor) driver;
				executor.executeScript("arguments[0].click();", ele);

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("course", "id", "CLCHAT");
				String xpathExpression = "//*[@id='" + new_value + "']";
				WebElement ele = driver.findElement(By.xpath(xpathExpression));
				JavascriptExecutor executor = (JavascriptExecutor) driver;
				executor.executeScript("arguments[0].click();", ele);

			}
			
			
			try {
				

				WebElement ele = driver.findElements(By.xpath("//*[@id=\"clchat_cmd_flush\"]")).get(0);   //click on reset
				JavascriptExecutor executor = (JavascriptExecutor) driver;
				executor.executeScript("arguments[0].click();", ele);

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("chatting", "id", "clchat_cmd_flush");
				String xpathExpression = "//*[@id='" + new_value + "']";
				WebElement ele = driver.findElement(By.xpath(xpathExpression));
				JavascriptExecutor executor = (JavascriptExecutor) driver;
				executor.executeScript("arguments[0].click();", ele);

			}
			Alert alert = driver.switchTo().alert();
	        alert.accept();
			
			try {

				Assert.assertTrue(driver.findElement(By.cssSelector("BODY")).getText()
						.matches("^[\\s\\S]*" + "" + "[\\s\\S]*$"));
			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("tools", "id", "claroBody");
				String xpathExpression = "//*[@id='" + idValue + "']";
				AssertJUnit.assertEquals(driver.findElement(By.xpath(xpathExpression)).getText(), "");

			}
			// logout
			try {
				driver.findElements(By.xpath("//*[@id=\"userBannerRight\"]/ul/li[3]/span/a")).get(0).click(); // click on
																												// logout

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("tools", "id", "userBannerRight");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElements(By.xpath(xpathExpression)).get(0).click();
			}
			
		}
	  
	  
	  @Test(priority =3 ,groups= "regression")
		public void wiki__1()throws Exception
		{
		  currrent_test="wiki__1";	
		  try {

				driver.findElement(By.id("login")).clear();

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("authentication", "id", "login");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElement(By.xpath(xpathExpression)).clear();
			}

			try {

				driver.findElement(By.name("login")).sendKeys("admin");

			} catch (NoSuchElementException e) {
				String nameValue = repairerObj.repair("authentication", "name", "login");
				String xpathExpression = "//*[@name='" + nameValue + "']";
				driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
			}

			try {

				driver.findElement(By.id("password")).clear();

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("authentication", "id", "password");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElement(By.xpath(xpathExpression)).clear();
			}

			try {

				driver.findElement(By.name("password")).sendKeys("admin");

			} catch (NoSuchElementException e) {
				String nameValue = repairerObj.repair("authentication", "name", "password");
				String xpathExpression = "//*[@name='" + nameValue + "']";
				driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
			}

			try {

				driver.findElement(By.xpath("//*[@id=\"loginBox\"]/form/fieldset/button")).click();

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("authentication", "text", "Enter");
				String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
				driver.findElement(By.xpath(xpathExpression)).click();
			}

			try {

				driver.findElement(By.xpath("//*[@id=\"userBannerLeft\"]/ul/li[3]/span/a")).click();

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("admin", "text", "Platform administration");
				String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
				driver.findElement(By.xpath(xpathExpression)).click();
			}

			try {

				driver.findElement(By.xpath("//*[@id=\"claroBody\"]/ul/li[2]/ul/li[2]/a")).click(); // click on Course list
				flag = 1;																				// button in Courses

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("admin", "text", "Course list");
				String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
				driver.findElement(By.xpath(xpathExpression)).click();
				flag = 2;
			}

			try {

				driver.findElement(By.xpath("//*[@id=\"claroBody\"]/table[2]/tbody/tr/td[2]/a")).click(); // click on Course
																											
			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("admin_courses", "text", "DATA STRUCTURE");
				String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
				driver.findElement(By.xpath(xpathExpression)).click();

			}
			
			try {

				WebElement ele = driver.findElement(By.xpath("//*[@id=\"CLWIKI\"]"));   //click on wiki
				JavascriptExecutor executor = (JavascriptExecutor) driver;
				executor.executeScript("arguments[0].click();", ele);

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("course", "id", "CLWIKI");
				String xpathExpression = "//*[@id='" + new_value + "']";
				WebElement ele = driver.findElement(By.xpath(xpathExpression));
				JavascriptExecutor executor = (JavascriptExecutor) driver;
				executor.executeScript("arguments[0].click();", ele);

			}
			
			
			
			try {

				driver.findElements(By.xpath("//*[@id=\"courseRightContent\"]/div/table/tbody/tr/td[2]/ul/li[2]/a")).get(0).click();   //click on create new wiki
																											
			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("wiki", "text", "Create a new Wiki");
				String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
				driver.findElement(By.xpath(xpathExpression)).click();

			}
			try {

				driver.findElement(By.id("wikiDesc")).clear();      //clear the field

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("wiki", "id", "wikiDesc");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElement(By.xpath(xpathExpression)).clear();
			}

			try {

				driver.findElement(By.id("wikiDesc")).sendKeys("new wiki is created");  // set decription

			} catch (NoSuchElementException e) {
				String nameValue = repairerObj.repair("wiki", "id", "wikiDesc");
				String xpathExpression = "//*[@id='" + nameValue + "']";
				driver.findElement(By.xpath(xpathExpression)).sendKeys("new wiki is created");
			}
			
			try {

				WebElement ele = driver.findElements(By.xpath("//*[@id=\"other_edit\"]")).get(0);   //click to select
				JavascriptExecutor executor = (JavascriptExecutor) driver;
				executor.executeScript("arguments[0].click();", ele);

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("wiki", "id", "other_edit");
				String xpathExpression = "//*[@id='" + idValue + "']";
				WebElement ele = driver.findElement(By.xpath(xpathExpression));
				JavascriptExecutor executor = (JavascriptExecutor) driver;
				executor.executeScript("arguments[0].click();", ele);

			}
			
			
			try {

				WebElement ele = driver.findElements(By.xpath("//*[@id=\"wikiProperties\"]/input[3]")).get(0);   //click on OK
				JavascriptExecutor executor = (JavascriptExecutor) driver;
				executor.executeScript("arguments[0].click();", ele);

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("wiki", "id", "wikiProperties");
				String xpathExpression = "//*[@id='" + idValue + "']";
				WebElement ele = driver.findElement(By.xpath(xpathExpression));
				JavascriptExecutor executor = (JavascriptExecutor) driver;
				executor.executeScript("arguments[0].click();", ele);

			}
			
			try {

				Assert.assertTrue(driver.findElement(By.cssSelector("BODY")).getText()
						.matches("^[\\s\\S]*" + "Wiki creation succeed" + "[\\s\\S]*$"));
			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("tools", "id", "claroBody");
				String xpathExpression = "//*[@id='" + idValue + "']";
				AssertJUnit.assertEquals(driver.findElement(By.xpath(xpathExpression)).getText(), "Wiki creation succeed");

			}
			// logout
			try {
				driver.findElements(By.xpath("//*[@id=\"userBannerRight\"]/ul/li[3]/span/a")).get(0).click(); // click on
																												// logout

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("tools", "id", "userBannerRight");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElements(By.xpath(xpathExpression)).get(0).click();
			}
			
			
		}
	  
	  
	  @Test(priority =4 ,groups= "regression")
		public void admin_add_new_user__1()throws Exception
		{
		  currrent_test="admin_add_new_user__1";	
		  try {

				driver.findElement(By.id("login")).clear();

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("authentication", "id", "login");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElement(By.xpath(xpathExpression)).clear();
			}

			try {

				driver.findElement(By.name("login")).sendKeys("admin");

			} catch (NoSuchElementException e) {
				String nameValue = repairerObj.repair("authentication", "name", "login");
				String xpathExpression = "//*[@name='" + nameValue + "']";
				driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
			}

			try {

				driver.findElement(By.id("password")).clear();

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("authentication", "id", "password");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElement(By.xpath(xpathExpression)).clear();
			}

			try {

				driver.findElement(By.name("password")).sendKeys("admin");

			} catch (NoSuchElementException e) {
				String nameValue = repairerObj.repair("authentication", "name", "password");
				String xpathExpression = "//*[@name='" + nameValue + "']";
				driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
			}

			try {

				driver.findElement(By.xpath("//*[@id=\"loginBox\"]/form/fieldset/button")).click();

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("authentication", "text", "Enter");
				String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
				driver.findElement(By.xpath(xpathExpression)).click();
			}

			try {

				driver.findElement(By.xpath("//*[@id=\"userBannerLeft\"]/ul/li[3]/span/a")).click();

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("admin", "text", "Platform administration");
				String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
				driver.findElement(By.xpath(xpathExpression)).click();
			}

			try {

				driver.findElement(By.xpath("//*[@id=\"claroBody\"]/ul/li[2]/ul/li[2]/a")).click(); // click on Course list
				flag = 1;																				// button in Courses

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("admin", "text", "Course list");
				String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
				driver.findElement(By.xpath(xpathExpression)).click();
				flag = 2;
			}

			try {

				driver.findElement(By.xpath("//*[@id=\"claroBody\"]/table[2]/tbody/tr/td[2]/a")).click(); // click on Course
																											
			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("admin_courses", "text", "DATA STRUCTURE");
				String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
				driver.findElement(By.xpath(xpathExpression)).click();

			}
			
			try {

				WebElement ele = driver.findElement(By.xpath("//*[@id=\"CLUSR\"]"));   //click on users
				JavascriptExecutor executor = (JavascriptExecutor) driver;
				executor.executeScript("arguments[0].click();", ele);

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("course", "id", "CLUSR");
				String xpathExpression = "//*[@id='" + new_value + "']";
				WebElement ele = driver.findElement(By.xpath(xpathExpression));
				JavascriptExecutor executor = (JavascriptExecutor) driver;
				executor.executeScript("arguments[0].click();", ele);

			}
			  
			try {

				driver.findElements(By.xpath("//*[@id=\"courseRightContent\"]/div[1]/table/tbody/tr/td[2]/ul/li[2]/a")).get(0).click();   //click on add user
																											
			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("user", "text", "Add a user");
				String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
				driver.findElement(By.xpath(xpathExpression)).click();

			}
			
			try {

				driver.findElement(By.id("lastname")).clear();      //clear the field

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("user", "id", "lastname");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElement(By.xpath(xpathExpression)).clear();
			}

			try {

				driver.findElement(By.id("lastname")).sendKeys("afzal");  // set name

			} catch (NoSuchElementException e) {
				String nameValue = repairerObj.repair("user", "id", "lastname");
				String xpathExpression = "//*[@id='" + nameValue + "']";
				driver.findElement(By.xpath(xpathExpression)).sendKeys("afzal");
			}
			
			try {

				driver.findElement(By.id("firstname")).clear();      //clear the field

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("user", "id", "firstname");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElement(By.xpath(xpathExpression)).clear();
			}

			try {

				driver.findElement(By.id("firstname")).sendKeys("aqeel");  // set decription

			} catch (NoSuchElementException e) {
				String nameValue = repairerObj.repair("user", "id", "firstname");
				String xpathExpression = "//*[@id='" + nameValue + "']";
				driver.findElement(By.xpath(xpathExpression)).sendKeys("aqeel");
			}
			
			try {

				driver.findElements(By.xpath("//*[@id=\"applySearch\"]")).get(0).click();   //click on search

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("user", "id", "applySearch");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElement(By.xpath(xpathExpression)).click();
			}
			
			
			try {

				Assert.assertTrue(driver.findElement(By.cssSelector("BODY")).getText()
						.matches("^[\\s\\S]*" + "already enrolled" + "[\\s\\S]*$"));
			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("tools", "id", "claroBody");
				String xpathExpression = "//*[@id='" + idValue + "']";
				AssertJUnit.assertEquals(driver.findElement(By.xpath(xpathExpression)).getText(), "already enrolled");

			}
			// logout
			try {
				driver.findElements(By.xpath("//*[@id=\"userBannerRight\"]/ul/li[3]/span/a")).get(0).click(); // click on
																												// logout

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("tools", "id", "userBannerRight");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElements(By.xpath(xpathExpression)).get(0).click();
			}
			
		}
	  
	  @Test(priority =5 ,groups= "regression")
			public void admin_users__1()throws Exception
			{
		  currrent_test="admin_users__1";
		  try {

				driver.findElement(By.id("login")).clear();

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("authentication", "id", "login");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElement(By.xpath(xpathExpression)).clear();
			}

			try {

				driver.findElement(By.name("login")).sendKeys("admin");

			} catch (NoSuchElementException e) {
				String nameValue = repairerObj.repair("authentication", "name", "login");
				String xpathExpression = "//*[@name='" + nameValue + "']";
				driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
			}

			try {

				driver.findElement(By.id("password")).clear();

			} catch (NoSuchElementException e) {
				String idValue = repairerObj.repair("authentication", "id", "password");
				String xpathExpression = "//*[@id='" + idValue + "']";
				driver.findElement(By.xpath(xpathExpression)).clear();
			}

			try {

				driver.findElement(By.name("password")).sendKeys("admin");

			} catch (NoSuchElementException e) {
				String nameValue = repairerObj.repair("authentication", "name", "password");
				String xpathExpression = "//*[@name='" + nameValue + "']";
				driver.findElement(By.xpath(xpathExpression)).sendKeys("admin");
			}

			try {

				driver.findElement(By.xpath("//*[@id=\"loginBox\"]/form/fieldset/button")).click();

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("authentication", "text", "Enter");
				String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
				driver.findElement(By.xpath(xpathExpression)).click();
			}

			try {

				driver.findElement(By.xpath("//*[@id=\"userBannerLeft\"]/ul/li[3]/span/a")).click();

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("admin", "text", "Platform administration");
				String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
				driver.findElement(By.xpath(xpathExpression)).click();
			}

			try {

				driver.findElement(By.xpath("//*[@id=\"claroBody\"]/ul/li[2]/ul/li[2]/a")).click(); // click on Course list
				flag = 1;																				// button in Courses

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("admin", "text", "Course list");
				String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
				driver.findElement(By.xpath(xpathExpression)).click();
				flag = 2;
			}

			try {

				driver.findElement(By.xpath("//*[@id=\"claroBody\"]/table[2]/tbody/tr/td[2]/a")).click(); // click on Course
																											
			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("admin_courses", "text", "DATA STRUCTURE");
				String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
				driver.findElement(By.xpath(xpathExpression)).click();

			}
			
			try {

				WebElement ele = driver.findElement(By.xpath("//*[@id=\"CLUSR\"]"));   //click on users
				JavascriptExecutor executor = (JavascriptExecutor) driver;
				executor.executeScript("arguments[0].click();", ele);

			} catch (NoSuchElementException e) {
				String new_value = repairerObj.repair("course", "id", "CLUSR");
				String xpathExpression = "//*[@id='" + new_value + "']";
				WebElement ele = driver.findElement(By.xpath(xpathExpression));
				JavascriptExecutor executor = (JavascriptExecutor) driver;
				executor.executeScript("arguments[0].click();", ele);

			}
			  
				
				try {

					driver.findElements(By.xpath("//*[@id=\"courseRightContent\"]/div[1]/table/tbody/tr/td[2]/ul/li[4]/a")).get(0).click();   //click to unregistor all users
																												
				} catch (NoSuchElementException e) {
					String new_value = repairerObj.repair("user", "text", "Unregister all students");
					String xpathExpression = "//a[contains(text(),'" + new_value + "')]";
					driver.findElement(By.xpath(xpathExpression)).click();

				}
				Alert alert = driver.switchTo().alert();
		        alert.accept();

		      
		      
				
				try {

					Assert.assertTrue(driver.findElement(By.cssSelector("BODY")).getText()
							.matches("^[\\s\\S]*" + "unregistered from this course" + "[\\s\\S]*$"));
				} catch (NoSuchElementException e) {
					String idValue = repairerObj.repair("user", "id", "claroBody");
					String xpathExpression = "//*[@id='" + idValue + "']";
					AssertJUnit.assertEquals(driver.findElement(By.xpath(xpathExpression)).getText(), "unregistered from this course");

				}
				// logout
				try {
					driver.findElements(By.xpath("//*[@id=\"userBannerRight\"]/ul/li[3]/span/a")).get(0).click(); // click on
																													// logout

				} catch (NoSuchElementException e) {
					String idValue = repairerObj.repair("tools", "id", "userBannerRight");
					String xpathExpression = "//*[@id='" + idValue + "']";
					driver.findElements(By.xpath(xpathExpression)).get(0).click();
				}	
				
			}
	  
	 
	  

}
