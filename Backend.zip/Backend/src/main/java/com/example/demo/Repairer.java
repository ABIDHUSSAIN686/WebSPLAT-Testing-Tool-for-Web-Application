package com.example.demo;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Dictionary;
import java.util.Enumeration;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Attribute;
import org.jsoup.nodes.Attributes;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

/****
 * 
 *  Repairer class is used to Repair the test
 *  scripts of each feature in feature model.
 * 
 * ****/
public class Repairer {
	Dictionary<Integer, String> feature_ids;
	Dictionary<Integer, String> map;
	public Repairer() {
		FeatureModel obj1 = new FeatureModel();
		try {
			 feature_ids=obj1.model_processor("model.xml");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			map=obj1.feature_page_mapper("Version01", "Version02",feature_ids);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public String repair(String feature,String attri,String base_attri) {
		
				String new_attri = "";
				System.out.println(map);
				String fileName = "";
			    String line1 = null,line2=null;
			    int id =0,tagcount=0;
			    boolean flag =false;
			    String tagname=null, tagtext =null, tagattri=null;
			    Enumeration<Integer> ids = feature_ids.keys();
			   
			    while (ids.hasMoreElements()) {
			    	int n=ids.nextElement();
			    String fea=feature_ids.get(n);
			   
			    	if(fea.equals(feature))
			    	{
			    		
			    		id =n;
			    	}
			    	 
					
			    }
			 
			        String folderPath = "F:\\eclipes_workspace3\\fyp2\\frontend\\public\\Changestxt";
			        File folder = new File(folderPath);

			        
			        
			        
			        if (folder.isDirectory()) {
			            String[] files = folder.list();
			            String str2=map.get(id);
		            	String[] str1=str2.split(" ",0);
			            for (String filename : files) {
			            	
			            	String[] str=filename.split(" ",0);
			            	if(str[0].equals(str1[0]))
			            		fileName = filename;
			            }
			        } else {
			            System.out.println("Invalid directory path");
			        }
			        
			        
			        
			        try (BufferedReader reader = new BufferedReader(new FileReader("F:\\eclipes_workspace3\\fyp2\\frontend\\public\\Changestxt\\"+fileName))) {
			            while ((line1 = reader.readLine()) != null) {
			            	line2 = reader.readLine();
			              //  System.out.println(line1);
			              //  System.out.println(line2);
			                String[] str=line1.split(">         ",0);
			                if(!str[0].isEmpty())
			                { String[] str1=str[0].split("         Line:  ",0);
			               
			                Document doc1 = Jsoup.parse(str1[1]+">");
			        		Elements elements1 = doc1.getAllElements();
			        		int count = 0;
			        		for (Element element : elements1) {
			        			Attributes attrs = element.attributes();
			        			count++;
			    				for (Attribute attr : attrs) {
			    					 
			    					if(attri.equals("text"))
			    					 {
			    						if(element.text().equals(base_attri))
			    						{
			    							 tagname = element.tagName();
			    							 tagtext = element.text();
			    							 tagcount = count;
			    							 tagattri =attr.getValue();
			    							 flag =true;
			    							System.out.println(count+" tag name:   "+element.tagName()+"          arrti: "+attr.getKey()+"      text:  "+element.text());
			    						break;
			    						}
			    					 }
			    					
			    					if(attri.equals("id") || attri.equals("name") || attri.equals("type")|| attri.equals("class")|| attri.equals("href")|| attri.equals("alt")|| attri.equals("value")|| attri.equals("option")|| attri.equals("span"))
			    					 {
			    						if(attr.getValue().equals(base_attri))
			    						{
			    							 tagname = element.tagName();
			    							 tagtext = element.text();
			    							 tagcount = count;
			    							 tagattri =attr.getValue();
			    							 flag =true;
			    							System.out.println(count+" tag name:   "+element.tagName()+"          arrti: "+attr.getKey()+"      text:  "+element.text()+"      value:  "+attr.getValue());
			    						break;
			    						}
			    					 }
			    					if(flag)
			    						break;
			    				}
			    				
			        		}
			                }
			                
			                
			                String[] str2=line2.split(">         ",0);
			                if(!str2[0].isEmpty())
			                { String[] str1=str2[0].split("         Line:  ",0);
			               
			                Document doc1 = Jsoup.parse(str1[1]+">");
			        		Elements elements1 = doc1.getAllElements();
			        		int count = 0;
			        		for (Element element : elements1) {
			        			Attributes attrs = element.attributes();
			        			count++;
			    				for (Attribute attr : attrs) {
			    					 
			    					if(attri.equals("text"))
			    					 {
			    						if(element.tagName().equals(tagname) && attr.getValue().equals(tagattri))
			    						{
			    							System.out.println(count+" tag name:   "+element.tagName()+"          arrti: "+attr.getValue()+"      text:  "+element.text());
			    							return element.text();
			    						}
			    					 }
			    					
			    					if(attri.equals("id") || attri.equals("name") || attri.equals("type")|| attri.equals("class")|| attri.equals("href")|| attri.equals("alt")|| attri.equals("value")|| attri.equals("option")|| attri.equals("span"))		
			    					 {
			    						if(element.tagName().equals(tagname) && element.text().equals(tagtext))
			    						{
			    							System.out.println(count+" tag name:   "+element.tagName()+"          arrti: "+attr.getValue()+"      text:  "+element.text());
			    							return attr.getValue();
			    						}
			    					 }
			    					
			    				}
			    				
			        		}
			                }
			                
			                
			            }
			        } catch (IOException e) {
			            System.err.format("IOException: %s%n", e);
			        }
			        
		
		return base_attri;
	}
	
	public String repair_mini(String filename,String attri,String base_attri) {
		
		String new_attri = "";
		System.out.println(map);
	    String line1 = null,line2=null;
	    int id =0,tagcount=0;
	    boolean flag =false;
	    String tagname=null, tagtext =null, tagattri=null;
	    Enumeration<Integer> ids = feature_ids.keys();
	   
	  
	 
	       

	        
	        
	        
	       
	        
	        
	        
	        try (BufferedReader reader = new BufferedReader(new FileReader("F:\\eclipes_workspace3\\fyp2\\frontend\\public\\Changestxt\\"+filename))) {
	            while ((line1 = reader.readLine()) != null) {
	            	line2 = reader.readLine();
	              //  System.out.println(line1);
	              //  System.out.println(line2);
	                String[] str=line1.split(">         ",0);
	                if(!str[0].isEmpty())
	                { String[] str1=str[0].split("         Line:  ",0);
	               
	                Document doc1 = Jsoup.parse(str1[1]+">");
	        		Elements elements1 = doc1.getAllElements();
	        		int count = 0;
	        		for (Element element : elements1) {
	        			Attributes attrs = element.attributes();
	        			count++;
	    				for (Attribute attr : attrs) {
	    					 
	    					if(attri.equals("text"))
	    					 {
	    						if(element.text().equals(base_attri)&&attr.getKey().equals(attri))
	    						{
	    							 tagname = element.tagName();
	    							 tagtext = element.text();
	    							 tagcount = count;
	    							 tagattri =attr.getValue();
	    							 flag =true;
	    							System.out.println(count+" 1tag name:   "+element.tagName()+"          arrti: "+attr.getKey()+"      text:  "+element.text());
	    						break;
	    						}
	    					 }
	    					
	    					if(attri.equals("id") || attri.equals("name") || attri.equals("type")|| attri.equals("class")|| attri.equals("href")|| attri.equals("alt")|| attri.equals("value")|| attri.equals("option")|| attri.equals("span"))
	    					 {	    					

	    						if(attr.getValue().equals(base_attri) &&attr.getKey().equals(attri))
	    						{
	    							 tagname = element.tagName();
	    							 tagtext = element.text();
	    							 tagcount = count;
	    							 tagattri =attr.getValue();
	    							 flag =true;
	    							System.out.println(count+" 3tag name:   "+element.tagName()+"          arrti: "+attr.getKey()+"      text:  "+element.text()+element.text()+"      value:  "+attr.getValue());
	    						break;
	    						}
	    					 }
	    					if(flag)
	    						break;
	    				}
	    				
	        		}
	                }
	                
	                
	                String[] str2=line2.split(">         ",0);
	                if(!str2[0].isEmpty()&&flag)
	                { String[] str1=str2[0].split("         Line:  ",0);
	               
	                Document doc1 = Jsoup.parse(str1[1]+">");
	        		Elements elements1 = doc1.getAllElements();
	        		int count = 0;
	        		for (Element element : elements1) {
	        			Attributes attrs = element.attributes();
	        			count++;
	    				for (Attribute attr : attrs) {
	    					 
	    					if(attri.equals("text"))
	    					 {
	    						if(element.tagName().equals(tagname) && attr.getValue().equals(tagattri))
	    						{
	    							System.out.println(count+" 3tag name:   "+element.tagName()+"          arrti: "+attr.getValue()+"      text:  "+element.text());
	    							return element.text();
	    						}
	    					 }
	    					

	    					if(attr.getKey().equals(attri) )		
	    					 {
	    						
	    							System.out.println(count+" 4tag name:   "+element.tagName()+"          arrti: "+attr.getKey()+"      text:  "+element.text()+element.text()+"      value:  "+attr.getValue());
	    							return attr.getValue();
	    						
	    					 }
	    					
	    				}
	    				
	        		}
	                }
	                
	                
	            }
	        } catch (IOException e) {
	            System.err.format("IOException: %s%n", e);
	        }
	        

return base_attri;
}
}



