package com.example.demo;
import java.util.ArrayList;
import java.util.Dictionary;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Attribute;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import com.google.gson.Gson;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Dictionary;
import java.util.Enumeration;


/****
 * 
 *  Driver class used to run the functionality
 * 
 * ****/
public class Driver {	
	
	
	/****
	 * 
	 *  starter function calls all function to get final desired output
	 * 
	 * ****/
	public void starter() throws IOException
	{
		
		WebPage obj =new WebPage();
		List<String> list2 = new ArrayList<String>();
		//	obj.genrator("http://localhost/parent/claroline/","Version01");
		//	obj.genrator("http://localhost/parent3/vtwo/","Version02");
		DOM_Diffrence_Detector obj3 = new DOM_Diffrence_Detector();
		FeatureModel obj1 = new FeatureModel();
			obj1.name_formator("Version01");
			obj1.name_formator("Version02");
		Dictionary<Integer, String> feature_ids=obj1.model_processor("model.xml");
		Dictionary<Integer, String> map=obj1.feature_page_mapper("Version01", "Version02",feature_ids);
	
		Enumeration<Integer> ids = map.keys();
		Enumeration<Integer> ids1 = map.keys();
		File folder1 = new File("Version01/");
		File folder2 = new File("Version02/");
		ArrayList<String> features=new ArrayList<String>();
		ArrayList<String> features_file=new ArrayList<String>();
		Comparisor obj2 =new Comparisor();
		while (ids.hasMoreElements()) {
			int n=ids.nextElement();
			if(n!=0)
			{System.out.println("------>"+n);
			String[] str=map.get(n).split(" ",0);
			System.out.println("----00-->"+Integer.parseInt(str[0])+"  "+ Integer.parseInt(str[1]));
			if (obj1.getAllFiles1(folder1,Integer.parseInt(str[0])) != null && obj1.getAllFiles1(folder2,Integer.parseInt(str[1])) !=null)
			{	
				features.add(feature_ids.get(n));
			features_file.add(obj1.getAllFiles1(folder1,Integer.parseInt(str[0])));
//System.out.println("------- "+obj1.getAllFiles1(folder1,Integer.parseInt(str[0])));
		//	if (obj1.getAllFiles1(folder1,Integer.parseInt(str[0])) != null)
				list2=obj3.Formatting("Version01/"+obj1.getAllFiles1(folder1,Integer.parseInt(str[0])));
			String[] arr3 = list2.toArray(new String[0]);
		//	if (obj1.getAllFiles1(folder2,Integer.parseInt(str[1])) != null)
				list2=obj3.Formatting("Version02/"+obj1.getAllFiles1(folder2,Integer.parseInt(str[1])));
			String[] arr4 = list2.toArray(new String[0]);

			obj3.sort_File(arr3,"Version01/"+obj1.getAllFiles1(folder1,Integer.parseInt(str[0])));
			obj3.sort_File(arr4,"Version02/"+obj1.getAllFiles1(folder2,Integer.parseInt(str[1])));
			obj3.createFolders(obj1.getAllFiles1(folder1,Integer.parseInt(str[0])));
			
				obj2.codeExecutor(obj1.getAllFiles1(folder1,Integer.parseInt(str[0])),obj1.getAllFiles1(folder2,Integer.parseInt(str[1])));
		//	if (obj1.getAllFiles1(folder1,Integer.parseInt(str[0])) != null && obj1.getAllFiles1(folder2,Integer.parseInt(str[1])) !=null)
				obj2.codeExecutor1(obj1.getAllFiles1(folder1,Integer.parseInt(str[0])),obj1.getAllFiles1(folder2,Integer.parseInt(str[1])));
			System.out.println("\n\n");
		}}}
		while (ids1.hasMoreElements()) {
			int n=ids1.nextElement();
			if(n!=0)
			{	
				String[] str=map.get(n).split(" ",0);
				File file =null;
				System.out.println("----------->       "+map.get(n));
				if (obj1.getAllFiles1(folder1,Integer.parseInt(str[0])) != null)
				{		file = new File("F:/eclipes_workspace3/fyp2/frontend/public/Changes/"+obj1.getAllFiles1(folder1,Integer.parseInt(str[0])));
			BufferedReader br = new BufferedReader(new FileReader(file));
			String st;
			List<String> list1 = new ArrayList<String>();
			while ((st = br.readLine()) != null) {
				list1.add(st + "\n");
			}
			String[] arr = list1.toArray(new String[0]);
			obj3.intialize_Changes();
			obj3.Diffrence_Phrase(arr, obj1.getAllFiles1(folder1,Integer.parseInt(str[0])),"F:/eclipes_workspace3/fyp2/frontend/public/Changestxt/"+obj1.getAllFiles1(folder1,Integer.parseInt(str[0]))+".txt","F:/eclipes_workspace3/fyp2/frontend/public/Changes/");
			System.out.println(obj3.allChanges);
		}}
			}
		obj3.Write_Overall_changes();
		System.out.println(features);
		System.out.println(features_file);

		List<String> list = new ArrayList<String>();
		Map<String,String> map1=new HashMap<String,String>();
		int i=0;
		Gson gson2 = new Gson(); 
		String json2 = null;
		while(i<features.size())
		{
			map1.put("name",features.get(i));  
			map1.put("URL",features_file.get(i)); 
			Gson gson1 = new Gson(); 
			String json1 = gson1.toJson(map1); 
			list.add(json1);
			i++;
		}

		try {
			FileWriter file = new FileWriter("F:/eclipes_workspace3/fyp2/frontend/src/Pages/options.json");
			file.write(list.toString());
			file.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("list\n"+list);
	}

	

	/****
	 * 
	 *  main function is the entry point to run the application
	 * 
	 * ****/
	public static void main(String[] args) throws IOException,Exception {
		Driver obj1 =new Driver();
		DOM_Diffrence_Detector obj3 = new DOM_Diffrence_Detector();
	//	obj1.starter();
		
//		Comparisor obj2 =new Comparisor();
//		obj3.createFolders("user_search_v1.html");
//		obj2.codeExecutor("user_search_v1.html","user_search_v2.html");
//		obj2.codeExecutor1("user_search_v1.html","user_search_v2.html");
//		File file = new File("F:/eclipes_workspace3/fyp2/frontend/public/Changes/user_search_v1.html");
//		BufferedReader br = new BufferedReader(new FileReader(file));
//		String st;
//		List<String> list1 = new ArrayList<String>();
//		while ((st = br.readLine()) != null) {
//			list1.add(st + "\n");
//		}
//		String[] arr = list1.toArray(new String[0]);
//		obj3.intialize_Changes();
//		obj3.Diffrence_Phrase(arr, "user_search_v1.html","F:/eclipes_workspace3/fyp2/frontend/public/Changestxt/user_search_v1.html.txt","F:/eclipes_workspace3/fyp2/frontend/public/Changes/");

		FeatureModel obj2 = new FeatureModel();
		
	obj2.feature_TestSuite_mapper("model.xml");

	}
}





