package com.example.demo;

import java.io.File;
import java.io.FileWriter; 
import java.io.IOException; 
import java.nio.file.Files;
import java.nio.file.Paths;
import org.apache.commons.io.FileUtils;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Set;

/****
 * 
 *WebPage class is used to 
 *extract web pages of a variant.
 * 
 * ****/

public class WebPage {
	protected static WebDriver driver;
	protected WebDriverWait wait;
	protected static JavascriptExecutor js;
	protected String pageName;
	protected String pageID;
	protected String pageURL;
	public String getPageName() {
		return pageName;
	}
	public void setPageName(String pageName) {
		this.pageName = pageName;
	}
	public String getPageID() {
		return pageID;
	}
	public void setPageID(String pageID) {
		this.pageID = pageID;
	}
	public String getPageURL() {
		return pageURL;
	}
	public void setPageURL(String pageURL) {
		this.pageURL = pageURL;
	}
	
	
	/****
	 * 
	 *generator function is used to 
	 *extract web pages of a variant.
	 *it take root link of the variant as input
	 *and store the files to the given path as 
	 *input.
	 * 
	 * ****/
	public void genrator(String rootLink,String foldername) throws IOException {
		String filepath = foldername+"/";
		File file1 = new File(filepath);
		FileUtils.cleanDirectory(file1);
		String strs=rootLink.substring(16);
		String str1="claroline/admin/admincourseusers.php";
		String str2="claroline/admin/adminmailsystem.php";
		int no = 0;
		int index = 0;
		String fileName;
		int pageLinkno = 0;
		boolean duplicateFiles = false;
		String pageLink = rootLink;

		ArrayList<String> linkArray = new ArrayList<String>();// Creating arraylist
		Set<String> s;
		int flag = 1;

		Iterator itr1 = linkArray.iterator(); // getting the Iterator
		System.setProperty("webdriver.chrome.driver",
				"F:\\\\eclipes_workspace3\\\\fyp2\\\\chromedriver.exe");
		driver = new ChromeDriver(); // for Chrome driver

		int i = 0;
		do {

			int totallinks = 0;
			System.out.println("link No. = " + i);
			System.out.println("Main Page Link = " + pageLink);

			driver.get(pageLink); // loading page url to driver

			if (i >= 0) {
				boolean isloginPresent = driver.findElements(By.id("login")).size() > 0;

				if (isloginPresent) {
					driver.findElement(By.id("login")).clear(); // clear the field
					driver.findElement(By.id("login")).sendKeys("admin");
					driver.findElement(By.id("password")).clear(); // clear the field
					driver.findElement(By.id("password")).sendKeys("admin");
				}

				boolean isEnterPresent = driver.findElements(By.xpath("//*[@id=\"loginBox\"]/form/fieldset/button"))
						.size() > 0;
						boolean isOkPresent = driver
								.findElements(By.xpath("//*[@id=\"claroBody\"]/div[1]/form/fieldset/input[6]")).size() > 0;

								if (isEnterPresent) {
									driver.findElement(By.xpath("//*[@id=\"loginBox\"]/form/fieldset/button")).click();

								} else if (isOkPresent) {
									driver.findElement(By.xpath("//*[@id=\"claroBody\"]/div[1]/form/fieldset/input[6]")).click();
								}
			}

			String duplicatefileName = "";
			String title = driver.getTitle();
			System.out.println(title);

			fileName = no +"  "+title+".html"; 
			String p = driver.getPageSource(); 
			
			/*
			 * Fetching already created files from the folder and comparing their page
			 * source with page source of current page to detect duplications
			 */
			String[] chunks1 = pageLink.split("\\?", 0);
			String result1 = rootLink+str1;
			String result2 = rootLink+str2;
			try {
				String content = "";
				File folder = new File(foldername+"/");
				File[] listOfFiles = folder.listFiles();

				for (File file : listOfFiles) {
					if (file.isFile()) {
						String fileName1 = file.getPath();
						content = new String(Files.readAllBytes(Paths.get(fileName1)));
						// comparing page source
						duplicateFiles = p.equals(content);
						if (duplicateFiles) {
							duplicatefileName = fileName1;
							break;
						}
					}
				}

				System.out.println("File Same ? " + p.equals(content) + "\nDuplicate With = " + duplicatefileName);

				// if current page is duplicated then ignore it, otherwise make file
				
                
                
				if (!(duplicateFiles)&&!title.equals("")&&!(result1.equals(chunks1[0])||result2.equals(chunks1[0]))) {

					System.out.println(no+"   "+fileName);
					FileWriter myWriter = new FileWriter(filepath + "\\" + fileName);
					myWriter.write(p);
					myWriter.close();

					FileWriter fw = new FileWriter(filepath + "\\Links.txt", true);
					fw.write(no + "-pageLink--->" + pageLink + "\n");
					fw.close();
				}

			} catch (IOException e) {
				System.out.println("An error occurred.");
				e.printStackTrace();
			}

			// If current page is not duplicate, then extract href tags
			if (!(duplicateFiles)&&!title.equals("")&&!(result1.equals(chunks1[0])||result2.equals(chunks1[0]))) {

				File input1 = new File(filepath + "\\" + fileName);
				Document doc1 = Jsoup.parse(input1, "UTF-8", "");
				Elements elements1 = doc1.body().getAllElements();

				String l = "";
				System.out.println("Links of this Page are = ");
				//extracting a substring from the base url of a variant. e.g. /parent/claroline/
                String url = rootLink;
                int index1 = url.indexOf("localhost/");
                String extractedString = url.substring(index1 + 9);
                System.out.println("Extracted string: " + extractedString);

                //removing last character '/' from base url
                String result = rootLink.substring(0, rootLink.length() - 1);
                System.out.println("Extracted result: " +result);
                for (Element element : elements1) 
				{                                           //unique tags
                    if (element.hasAttr("href")) 
					{
                        if ( (!element.attr("href").toString().contains("phpInfo.php")) && (!element.attr("href").equals("campusProblem.php"))) 
						{
                            // your code here

                            if (((element.attr("href").contains(extractedString) || element.attr("href").contains(".php")))) 
							{
                                //System.out.println("if messagescourse = " + pageLink);
                                //System.out.println("Original Link = " + element.attr("href"));

                                //l = "http://localhost" + element.attr("href");

                                if (element.attr("href").contains(extractedString) && !(element.attr("href").contains("//localhost")) && !(element.attr("href").contains(extractedString + "claroline/admin/admin_courses.php?cmd=exDelete&delCode="))) 
								{
                                    totallinks++;
                                    System.out.println("page link = " + pageLink);
                                    //System.out.println("Hheheheheheheh");
                                    linkArray.add("http://localhost" + element.attr("href"));
                                    System.out.println("http://localhost" + element.attr("href"));

                                } 
								else if (element.attr("href").equals("inscription.php")) 
								{
                                    totallinks++;
                                    linkArray.add(rootLink + "claroline/auth/inscription.php");
                                    System.out.println("http://localhost/abc/claroline/claroline/auth/inscription.php");
                                } 
								else if (element.attr("href").equals("importLearningPath.php?cidReset=true&cidReq=")) 
								{
                                    totallinks++;
                                    linkArray.add(rootLink + "claroline/learnPath/importLearningPath.php?cidReset=true&cidReq=");
                                    System.out.println("http://localhost/abc/claroline/claroline/learnPath/importLearningPath.php?cidReset=true&cidReq=");
                                } 
								else if (pageLink.contains("admin") && (element.attr("href").contains(".php")) && (!(pageLink.contains("admin.php")) && !(element.attr("href").contains("//localhost")) && !(element.attr("href").contains(extractedString)))) 
								{
                                    //System.out.println("In admin.");
									if(element.attr("href").contains(".."))
									{
										String href = element.attr("href").replaceAll("\\.\\.", "");
										//System.out.println("In admin 1.");
										//linkArray.add("http://localhost/abc/claroline/claroline" +href);
										linkArray.add(result+"claroline" + href);
										System.out.println(result + href);
										totallinks++;
									}
									else if (element.attr("href").contains("edit_question.php?cmd=rqEdit&cidReset=true&cidReq")) 
									{
                                        linkArray.add(rootLink + "claroline/exercise/admin/edit_question.php?cmd=rqEdit&cidReset=true&cidReq");
                                        System.out.println("http://localhost/abc/claroline/claroline/exercise/admin/edit_question.php?cmd=rqEdit&cidReset=true&cidReq");
                                        totallinks++;
                                    } 
									else if (element.attr("href").contains("./edit_question.php?exId=&cmd=rqEdit&quId=&cidReset=true&cidReq")) 
									{
                                        linkArray.add(rootLink + "claroline/exercise/exercise.php?cidReset=true&cidReq");
                                        System.out.println("http://localhost/abc/claroline/claroline/exercise/exercise.php?cidReset=true&cidReq");
                                        totallinks++;
                                    } 
									else if (element.attr("href").contains("config_edit.php")) 
									{
                                        linkArray.add(rootLink + "claroline/admin/tool/" + element.attr("href"));
                                        System.out.println("http://localhost/abc/claroline/claroline/admin/tool/" + element.attr("href"));
                                        totallinks++;
                                    } 
									else
                                    {
										//System.out.println("In admin 2.");
										//linkArray.add("http://localhost/abc/claroline/claroline/admin/" + element.attr("href"));
										linkArray.add(rootLink + "claroline/admin/" + element.attr("href"));
										//System.out.println(rootLink + "admin/" + element.attr("href"));
										totallinks++;
                                    }


                                } 
								else if (pageLink.contains(rootLink + "claroline/messaging/admin.php")) 
								{
                                    System.out.println("new cond");
                                    totallinks++;
                                    linkArray.add(rootLink + "claroline/messaging/" + element.attr("href"));
                                    System.out.println("http://localhost/abc/claroline/claroline/messaging/" + element.attr("href"));
                                } 
								else if (element.attr("href").contains("//localhost")) 
								{
                                    totallinks++;
                                    linkArray.add(element.attr("href"));
                                    System.out.println(element.attr("href"));
                                } 
								else if (element.attr("href").contains("admin/question_pool.php?cidReset=true&cidReq")) 
								{
                                    totallinks++;
                                    linkArray.add(rootLink + "claroline/exercise/admin/question_pool.php?cidReset=true&cidReq");
                                    System.out.println("http://localhost/abc/claroline/claroline/exercise/admin/question_pool.php?cidReset=true&cidReq");
                                } 
								else if (element.attr("href").contains("delete_course_stats.php?cidReset=true&cidReq")) 
								{
                                    totallinks++;
                                    linkArray.add(rootLink + "claroline/tracking/delete_course_stats.php?cidReset=true&cidReq");
                                    System.out.println("http://localhost/abc/claroline/claroline/tracking/delete_course_stats.php?cidReset=true&cidReq");
                                } 
								else if (element.attr("href").contains("admin/question_category.php?cidReset=true&cidReq")) 
								{
                                    totallinks++;
                                    linkArray.add(rootLink + "claroline/exercise/admin/question_category.php?cidReset=true&cidReq");
                                    System.out.println("http://localhost/abc/claroline/claroline/exercise/admin/question_category.php?cidReset=true&cidReq");
                                }
                            }
                        }
                    }
                }
				System.out.println(
						"----------------------------------------------------------------------------------------------------------------");
				// set to remove duplicate links from arraylist
				s = new LinkedHashSet<String>(linkArray);
				linkArray.clear();
				linkArray.addAll(s);
				s.clear();

				// Traversing list through Iterator
				Iterator itrr = linkArray.iterator(); // getting the Iterator
				System.out.println("Total Links in a Page = " + totallinks);
			}

			no++;
			if (linkArray.size() > pageLinkno)
			{
				pageLink = linkArray.get(pageLinkno);
				pageLinkno++;
			}
			else
			{
				break;
			}

			i++;

		} while (itr1.hasNext()); // check if iterator has the elements

		System.out.println(
				"\n\n\n++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n\nList without Duplication : \n");
		System.out.println("Total links are = " + linkArray.size());

		// Traversing list through Iterator
		Iterator itrr = linkArray.iterator(); // getting the Iterator
		while (itrr.hasNext()) // check if iterator has the elements
		{
			System.out.println(itrr.next()); // printing the element and move to next
		}
		driver.close();	
	}
	public static void main(String[] args) throws Exception {

	}
}