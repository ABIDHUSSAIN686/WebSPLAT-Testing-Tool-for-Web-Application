package com.example.demo;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Comparisor {
	String s;
	public void codeExecutor(String filename1,String filename2) throws IOException {
		String pathPython = "delta.py";
		String [] cmd = new String[4];
		cmd[0] = "python";
		cmd[1] = pathPython;
		cmd[2] = filename1;
		cmd[3] = filename2;
		Runtime r = Runtime.getRuntime();  
		Process p = r.exec(cmd);
		BufferedReader in = new BufferedReader(new InputStreamReader(p.getInputStream()));
		while((s=in.readLine()) != null){
			System.out.println(s);
		}
	}
	public void codeExecutor1(String filename1,String filename2) throws IOException {
		String pathPython = "delta2.py";
		String [] cmd = new String[4];
		cmd[0] = "python";
		cmd[1] = pathPython;
		cmd[2] = filename1;
		cmd[3] = filename2;
		Runtime r = Runtime.getRuntime();
		Process p = r.exec(cmd);
	}
	public static void main(String args[]) throws IOException {
		Comparisor obj =new Comparisor();
		obj.codeExecutor("index1.html","index2.html");
	}
}