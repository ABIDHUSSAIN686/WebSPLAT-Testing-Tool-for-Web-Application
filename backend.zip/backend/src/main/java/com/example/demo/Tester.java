package com.example.demo;


/****
 * 
 *Tester class is used to 
 *store tester details.
 * 
 * ****/

public class Tester {
protected String name;
protected String email;
protected String passward;
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public String getPassward() {
	return passward;
}
public void setPassward(String passward) {
	this.passward = passward;
}


}
