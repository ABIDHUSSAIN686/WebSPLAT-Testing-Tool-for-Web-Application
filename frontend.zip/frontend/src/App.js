import React,{useEffect} from 'react';
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Loginandsignup from "./Pages/Loginandsignup.js";
import TestVariant from "./Pages/VariantInput.js";
import Pdf_Viewer from "./Pages/DifferencesView.js";
import Delta_Changes_Viewer from "./Pages/DeltaChangesView"
import Taxonomy_Changes_Viewer from "./Pages/TaxonomyChanges"
import Test_Case_Mapping from "./Pages/TestCaseMapping"
import Home from './Pages/Home';
import bootstrap from "../node_modules/bootstrap/dist/css/bootstrap.min.css"
import "bootstrap"
/**** 
 App is main class
 Defines the routes for different Pages
****/
function App() {
  /****
  Routes is used to define the seprate path for each element 
  ****/
  return (
    <div className="App">
      <BrowserRouter>
        <Routes>
          <Route path="/" exact element={<Loginandsignup />} />
          <Route path="/home" exact element={<Home />} />
          <Route path="/testing_variant" exact element={<TestVariant />} />
          <Route path="/pdf_viewer" exact element={<Pdf_Viewer />} />
          <Route path="/delta_changes_view" exact element={<Delta_Changes_Viewer />} />
          <Route path="/taxonomy_changes_view" exact element={<Taxonomy_Changes_Viewer />} />
          <Route path="/TestCaseMapping" exact element={<Test_Case_Mapping />} />
        </Routes>
      </BrowserRouter>
    </div>
  );
}
export default App;
