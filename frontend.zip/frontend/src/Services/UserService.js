import axios from 'axios'

const USERS_REST_API_URL = 'http://localhost:8083/';

class UserService {

    getUsers(){
        return axios.get(USERS_REST_API_URL);
    }
    upload(data) {
        return axios.post("http://localhost:8083/", data);
    }
     download(data) {
        return axios.get("http://localhost:8083/download", data);
    }
}

export default new UserService();