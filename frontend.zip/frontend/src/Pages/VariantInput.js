import React from 'react';
import UserService from '../Services/UserService'
import NavBar from '../components/NavBar';
import axios from "axios"
const logo = require('../Pictures/testinglogo.jpg');
/****
  Test Variant take variant name as input 
 ****/

class  TestVariant extends React.Component{
/****
  Constructor is initilized
 ****/	
	constructor(props){
		super(props)
		this.state = {
			users:[]
		}
		this.PrintResponse = this.PrintResponse.bind(this);
	}
/****
  Used for seprating the file of css
 ****/	
	componentWillMount(){
	import ("./VariantInput.css")
	}
	
/****
  Print the response from backend on the screen 
 ****/
PrintResponse(){
	
	UserService.getUsers().then((response) => {
			this.setState({ users: response.data})
			console.log()
		});
}

/****
  Upload the file from the Spring boot
 ****/
	onFileChangeHandler = (e) => {
		const formData = new FormData();
		for(let i = 0; i< e.target.files.length; i++) {
			formData.append('file', e.target.files[i])
		}
		UserService.upload(formData)  
			.then(res => {
					console.log(res.data);
					alert("File uploaded successfully.")
			})  
	};
/****
 Send the URL from front end to the Backend 
 ****/	
	handleSubmit = (e) =>{
		e.preventDefault();
		const v1=e.target.variant1.value;
		const v2=e.target.version1.value;
		const v3=e.target.variant2.value;
		const v4=e.target.version2.value;
		console.log(v1);
		console.log(v2);
		console.log(v3);
		console.log(v4);
		
		return axios
		.post("http://localhost:8083/url", {
			v1,
			v2,
			v3,
			v4
		})
		.then(response => {
			return response.data;
		});
	};
/****
 Rendering the changes to the screen 
 ****/
render() {
	return (
		<div className="dashdiv">
		<NavBar />
		<form className="formdiv" onSubmit={this.handleSubmit}>
			<div className='forminput'>
			<div className='padding'></div>
			<hr></hr>
				<div className="logotext">
					START TESTING YOUR APPLICATION!!!
				</div>
				<hr></hr>	
			</div>
			<div className='padding'></div>
			<div className='padding'></div>
			
				<div className='forminput'><div className='padding'></div>
						
						<input type="text" name="variant1" placeholder="Variant1 URL"></input>
						<br></br>
						<input type="text" name="version1" placeholder="Version1 Name"></input>
						<br></br>
						<input type="text" name="variant2" placeholder="Variant2 URL"></input>
						<br></br>
						<input type="text" name="version2" placeholder="Version2 Name"></input>
						<br></br>   
						<div className='forminput'>
						<button class=" btn-center btn-primary1 btn-lg">Submit</button>
						</div>	
				</div>
		</form>
		<div>
			<img src={logo} />
		</div>
			<form1>
				<br></br>
				{this.state.users}
			</form1>	
	</div> 
		
	
	)
}
}
export default TestVariant