import React ,{ useState }from 'react';
import {Link, useNavigate} from 'react-router-dom';
import Select from 'react-select';
import Users from "./options.json";
import { Dropdown } from "rsuite";
import { SelectedElement } from 'rsuite/esm/Picker';
import "./DifferencesView.css"
import "../components/NavBar"
import NavBar from '../components/NavBar';
const aquaticCreatures = [];
const logo = require('../Pictures/deltacalcultion.jpg');
/****
  DifferencesView is used to show the diffences in form of 
  HTML pages
****/
const  DifferencesView =()=>{
/****
 useNavigate is used to navigate to the next page 
 ****/
	const navigate = useNavigate();
	const [isOpened, setIsOpened] = useState(false);
	const [setdifferencebutton, setIsdifferencebutton] = useState("");
	const [settaxonomybutton, setIstaxonomybutton] = useState("");
/****
 Populating the dropdown menu
 ****/
	let optionTemplate = Users.map(user => (
		aquaticCreatures.push({label:user.name,value:user.URL})
    ));
/****
 ViewDifferenceFile is used to navigate to html diffrence file
 ****/
	function ViewDifferenceFile(){
		window.location.href=setdifferencebutton
	}
/****
 NavigatetoDeltaChanges is used to navigate to delta changes
 ****/
	function NavigatetoDeltaChanges(){
		navigate('/delta_changes_view',{state:{name:settaxonomybutton}});
	}
/****
 NavigatetoTaxnonomyChanges is used to navigate to taxonomy changes
 ****/
	function NavigatetoTaxnonomyChanges(){
		console.log("function", settaxonomybutton);
		navigate('/taxonomy_changes_view',{state:{name:settaxonomybutton}});
	}
/****
 handleChange is used to store the path of the selected features
 ****/
	const handleChange=(selectedOption)=>{
		const submit="/Comparision/"+selectedOption.value
		const submit1="/ChangesSidebySide/"+selectedOption.value
		console.log("THE VAL", submit1);
		setIsOpened(wasOpened => !wasOpened);
		setIsdifferencebutton(submit)
		setIstaxonomybutton(submit1)
	}
   
	return (	
	<div className="PdfViewerDiv">
		<NavBar />
		<div className="formdiv">
			<div className='forminput'>
				<div className='padding'></div>
					<hr></hr>
					<div className="logotext1">
					SEARCH FEATURES BELOW
					</div>
					<hr></hr>	
				<div className='searchpadding'></div>
					<Select 
						options={aquaticCreatures}
						placeholder={'Search'}
						onChange={handleChange}
					/> 	
			<div className='padding'></div>
			<div className='padding'></div>
			{ isOpened && (
				<div className='differencepagebutton'>
					<button class=" btn-center btn-primary1 btn-lg" onClick={ViewDifferenceFile}>View Differences File</button>
					<div className='padding'></div>
					<button class=" btn-center btn-primary1 btn-lg" onClick={NavigatetoDeltaChanges}>View Delta Changes</button>
					<div className='padding'></div>
					<button class=" btn-center btn-primary1 btn-lg" onClick={NavigatetoTaxnonomyChanges}>View Taxonomy</button>  
				</div>
			)}
			</div>
		</div>
		<div className="imagediv">
			<img src={logo} />
	  	</div>
	</div>  
    )
  }
export default DifferencesView