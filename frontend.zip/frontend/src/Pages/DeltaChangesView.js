import React ,{ useState}from 'react';
import {useLocation,useNavigate} from 'react-router-dom';
import "./DeltaChangesView.css"
import "../components/NavBar"
import NavBar from '../components/NavBar';
import DemoPie from "../components/PieChart"
import BarChart from "../components/BarChart"
import ReactDOM from 'react-dom';
/****
 Delta Changes is used show the change in form of 
 Graphs
 ****/
const  Delta_Changes =()=>{
/****
 useLocation is used to get the save state 
 ****/
	const location = useLocation();
/****
 useNavigate is used to navigate to the next page 
 ****/
	const navigate = useNavigate();
/****
 useNavigate is used to PDF page
 ****/
	function NavigatetoBackPage(){
		navigate('/pdf_viewer');
	}
	return (
	<div className="DeltaChangeDiv">
		<NavBar />
		<div className="formdiv2">
			<div className='forminput2'>
				<div className='padding1'></div>
					<hr></hr>
					<div className="logotext1">
					View Delta Changes
					</div>
					<hr></hr>		
				</div> 
		    </div> 
			<div className="GraphsDiv">
				<div className="logotext3">
					Feature-Wise Change
				</div>
				<div className="BarChartDiv">
					<BarChart/>
				</div>
			</div>
			<div className="GraphsDiv1">
				<div className="logotext3">
					OverAll Change in Variant
				</div>
				<div className="DemoPieDiv">
				<DemoPie/>
				</div>
			</div>
			<div className='buttonforminput2'>
				<button class=" btn-center btn-primary1 btn-lg" onClick={NavigatetoBackPage}>&laquo;<b>BACK</b></button>
			</div>
	</div>  
    )
  }
export default Delta_Changes