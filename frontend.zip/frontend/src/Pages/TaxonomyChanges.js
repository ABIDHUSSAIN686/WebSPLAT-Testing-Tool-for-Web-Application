import React ,{ useState,useEffect}from 'react';
import {useLocation,useNavigate} from 'react-router-dom';
import Select from 'react-select';
import Users from "./options1.json";
import NavBar from '../components/NavBar';
import { Dropdown } from "rsuite";
import { SelectedElement } from 'rsuite/esm/Picker';
import "./TaxonomyChanges.css"
import "../components/NavBar"
const aquaticCreatures = [];
/****
  Taxonomy Changes is used to show the diffences 
  of faetures w.r.t taxonomy
 ****/
const  Taxonomy_Changes =()=>{
/****
 useLocation is used to get the save state 
 ****/
	const location = useLocation();
/****
 useNavigate is used to navigate to the next page 
 ****/
	const navigate = useNavigate();
	const [isOpened, setIsOpened] = useState(false);
	const [setdifferencebutton, setIsdifferencebutton] = useState("");
	const [text1, setText1] = useState("");
	const [text2, setText2] = useState("");
/****
 Populating the dropdown menu
 ****/
	let optionTemplate = Users.map(user => (
		aquaticCreatures.push({label:user.name,value:user.URL})
    ));
/****
 Navigating to the Pdf page
 ****/
	function NavigatetoBackPage(){
		navigate('/pdf_viewer');
	}
/****
 Handle Change is used to show the taxonomy 
 changes files of the both variant
 ****/
	const handleChange=(selectedOption)=>{
		const submit=location.state.name+"/"+"1"+selectedOption.value+".txt"
		const submit1=location.state.name+"/"+"2"+selectedOption.value+".txt"
		console.log("THE VALUE 1", submit);
		console.log("THE VALUE 2", submit1);
		setIsdifferencebutton(submit)
		console.log(submit)
/****
 Fetch here is used to extract the data 
 of the first variant
 ****/
		fetch(submit)
		.then(r => r.text())
		.then(text => {
		  console.log('text decoded:', text);
		  if (text ==""){
			text="No taxonomy Change Found"
		   }
		  setText1(text)
		});
/****
 Fetch here is used to extract the data 
 of the second variant
 ****/
		fetch(submit1)
		.then(r => r.text())
		.then(text1 => {
		  console.log('text decoded:', text1);
		  if (text1 ==""){
			text1="No taxonomy Change Found"
		   }
		  setText2(text1)
		});
	}

	return (
	<div className="TaxonomyDiv1">
		<NavBar />
		<div className="formdiv1">
			<div className='forminput1'>
				<div className='padding1'></div>
					<hr></hr>
					<div className="logotext1">
					SEARCH TAXONOMY BELOW
					</div>
					<hr></hr>	
				<div className='searchpadding1'></div>
					<Select 
						options={aquaticCreatures}
						placeholder={'Search'}
						onChange={handleChange}
					/>
				</div> 
			</div> 
			<div class="wrapper">
				<div class="item1"><div className="logotext1">Variant 1</div></div>
				<div class="item2"><div className="logotext1">Variant 2</div></div>
				<div class="item3"><p>{text1}</p></div>
				<div class="item4"><p>{text2}</p></div>
			</div>
			<div className='buttonforminput1'>
				<button class=" btn-center btn-primary1 btn-lg" onClick={NavigatetoBackPage}>&laquo;<b>BACK</b></button>
			</div>
	</div>  
    )
  }
export default Taxonomy_Changes