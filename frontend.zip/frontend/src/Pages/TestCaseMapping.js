import React ,{ useState }from 'react';
import {Link, useNavigate} from 'react-router-dom';
import Select from 'react-select';
import Users from "./options.json";
import { Dropdown } from "rsuite";
import { SelectedElement } from 'rsuite/esm/Picker';
import "./TestCaseMapping.css"
import "../components/NavBar"
import NavBar from '../components/NavBar';
const logo = require('../Pictures/deltacalcultion.jpg');
const logo1 = require('../Pictures/Mapping.jpg');
const aquaticCreatures = [];


/****
 Test Mapping is used to show the mapping between 
the features and testcases
****/
const  TestCaseMapping =()=>{
/****
 Used to navigate from  first page to another
****/
	const navigate = useNavigate();
	const [text1, setText1] = useState("");
/****
 Mapping the Dropdown menu
****/
	let optionTemplate = Users.map(user => (
		aquaticCreatures.push({label:user.name,value:user.URL})
	));
/****
 Handle change is used to fetch the data from the files 
w.r.t features
****/
	const handleChange=(selectedOption)=>{
		const submit="/Feature_suite/"+selectedOption.value+"/test.txt";
		console.log(submit)
		fetch(submit)
		.then(r => r.text())
		.then(text => {
		console.log('text decoded:', text);
		console.log(text)
		if (text ==""){
			text="No TestCases Mapped Found"
		}
		setText1(text)
		});
	}
/****
 Navigate to the home screen
****/
	function NavigatetoBackPage(){
		navigate('/home');
	}

	return (	
	<div className="TestCaseMapping">
		<NavBar />
		<div className="Testformdiv">
			<div className='Testforminput'>
				<div className='Testpadding'></div>
					<hr></hr>
					<div className="Testlogotext1">
					SEARCH TEST CASE MAPPING BELOW
					</div>
					<hr></hr>	
				<div className='Testsearchpadding'></div>
					<Select
						options={aquaticCreatures}
						placeholder={'Search'}
						onChange={handleChange}
						className="mt m-auto w-75"
					/> 	
				<div className="Testimagediv">
					<img src={logo1} />
				</div>
			</div>
		</div>
		<div class="Testwrapper">
				<div class="Testitem1"><div className="Testlogotext1">Mapped Test Cases</div></div>
				<div class="Testitem2"><p style={{ whiteSpace: 'pre-line' }}>{text1}</p></div>
		</div>
		<div className='buttonforminput1'>
				<button class=" btn-center btn-primary1 btn-lg" onClick={NavigatetoBackPage}>&laquo;<b>BACK</b></button>
		</div>
	</div>  
	)
}
export default TestCaseMapping