import React from 'react';
import "./Home.css"
import ImageSlider, { Slide } from "react-auto-image-slider";
import NavBar from '../components/NavBar';
import { useNavigate } from "react-router-dom";
var logo =require( "../Pictures/Mapping1.jpg" )
const Home=() => {
  const navigate=useNavigate();

  function NavigatetoTestingVariantPage(){
		navigate('/testing_variant');
	}
  function NavigatetoDifferencesPage(){
		navigate('/pdf_viewer');
	}
  function NavigatetoMappingPage(){
		navigate('/TestCaseMapping');
	}
  
  return (
  <><NavBar/><div class="container1">
      <div id="div1">
        <div className="content">
          <h2 className="landing_text">
            <span className="highlight">WebSPLAT</span> A Smart and Reliable Testing Tool
          </h2>


          <p className="landing_para">
            WebSPLAT is a web based solution to test Software Product Lines(SPLs). It provides easy and efficient testing of different
            variants of a Software Product Line by reusing the core assets such as test suite which ultimately reduces the testing efforts
            and cost. This tool automatically transforms and migrate test suite for all the variants of a Software Product Line. 
          </p>

          <div id="features">
           <div id="shapes">
           <img
                src={logo}
                className="img-fluid"
                alt="landing img"
                style={{ width: "70%", height: "70%" }}
              />
           </div>
           </div>
        </div>
        
      </div>

      <div id="div2">

        <div id="innerdiv1">
          <span id="worktitle" class="fw-bold fs-1" style={{ color: "blue" }}>HOW IT WORKS? </span>
        </div>

        <div id="innerdiv2">
          <div id="bigdiv1">
            <div id="actualstep1">
              <h className="bignumbers">01</h>
              <p id="s1" className="stepsdetail">Upload the both Varinat's URLs and folder names where system will store the extracted
                HTML files.</p>

              <button className="buttonclass" onClick={NavigatetoTestingVariantPage}>
                Upload URLs
              </button>
            </div>
            <div id="actualstep1">
              <h className="bignumbers">02</h>
              <p id="s2" className="stepsdetail">After uploading the URLs, here you will see the differences that exists between both variants.</p>

              <button className="buttonclass" onClick={NavigatetoDifferencesPage}>
                Differences
              </button>
            </div>
          </div>

          <div id="bigdiv1">
            <div id="actualstep1">
              <h className="bignumbers">03</h>
              <p id="s3" className="stepsdetail">Aftere finding all differences, here all features will be mapped to their
                corresponding test cases.</p>
              <button className="buttonclass" onClick={NavigatetoMappingPage}>
                Test Mapping
              </button>
            </div>
            <div id="actualstep1">
              <h className="bignumbers">04</h>
              <p id="s4" className="stepsdetail">Now, the test suite generated for your new variant is ready. You can view and download it.</p>

              <button className="buttonclass">
                Get Test Suite
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
    </>     
  );
};

export default Home;
