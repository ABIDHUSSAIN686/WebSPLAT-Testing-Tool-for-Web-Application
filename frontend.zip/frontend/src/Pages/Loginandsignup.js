import React, { useState,useRef,useEffect } from "react";
import {useNavigate} from "react-router-dom"
import "./Loginandsignup.css"
let logo = require('../Pictures/Login.jpg');
let logo1 = require('../Pictures/Brandlogo.png');

/****
 Loginandsignup is used to Register the Users
****/
export default function Loginandsignup() {
  const headerRef = useRef();
  const headerRef1 = useRef();
  const headerRef2 = useRef();
  const headerRef3 = useRef();
  const headerRef4 = useRef();
  const navigate = useNavigate() 

  const [user, setUser,useEffect] = useState({
    email: "",
    password: "",
    repassword: "",
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setUser({
      ...user,
      [name]: value,
    });
  };
/****
 Used to navigate to the Home Page
****/
  const navigateToDashboard = () => {
    navigate('/Home');
  };
/****
 Used to navigate to the LoginPage
****/
  const navigateToHomepage = () => {
    navigate('/');
  };

  const scrollToSignUp = () => {
    headerRef1.current.style.marginLeft = "-50%";
    headerRef.current.style.marginLeft = "-50%";
  };
  const scrollToLogin = () => {
    headerRef1.current.style.marginLeft = "0%";
    headerRef.current.style.marginLeft = "0%";
  };

  const goToLink = () => {
    headerRef3.current.click();
    headerRef1.current.style.marginLeft = "-50%";
    headerRef.current.style.marginLeft = "-50%";
  };

/****
 Rendering the Login Page
****/
  return (
	<div className="apppage">
    <div className="Branding">
      <img src={logo1} />
    </div>
    <div className="logindiv">
      {console.log("User", user)}
      <div className="logindiv1 overflow-hidden">
      <div className="wrapper1 ">
        <div className="title-text1">
          <div className="title1 login1" ref={headerRef}>
          <div className="loginlogotext">
            Login
          </div>
          </div>
          <div className=" loginlogotext title1 signup1">Signup</div>
        </div>
        <div className="form-container1">
          <div className="slide-controls1">
            <input
              type="radio1"
              name="slide"
              id="login"
              defaultChecked={true}
            ></input>
            <input type="radio1" name="slide" id="signup"></input>
            <label
              htmlFor="login"
              className="loginlogotext slide1 login1"
              ref={headerRef2}
              onClick={scrollToLogin}
              >
              Login
            </label>
            <label
              htmlFor="signup"
              className="loginlogotext slide1 signup1"
              ref={headerRef3}
              onClick={scrollToSignUp}
            >
              Signup
            </label>
            <div className="slider-tab1"></div>
          </div>
          <div className="form-inner1">
            <form action="#" className="login1" ref={headerRef1}>
              <div className="field1">
                <input
                  type="text"
                  name="email"
                  value={user.email}
                  placeholder="Email Address"
                  onChange={handleChange}
                  required
                ></input>
              </div>
              <div className="field1">
                <input
                  type="password"
                  name="password"
                  value={user.password}
                  placeholder="Password"
                  onChange={handleChange}
                  required
                ></input>
              </div>
              <div className="pass-link1">
                <a href="#">Forgot password?</a>
              </div>
              <div className="field1 btn1">
                <div className="btn-layer1"></div>
                <input className="loginlogotext" type="submit" value="Login" onClick={navigateToDashboard}></input>
              </div>
              <div className=" signup-link1">
                Not a member?{" "}
                <div href="" ref={headerRef4} onClick={goToLink}>
                  <a>Signup now</a>
                </div>
              </div>
            </form>
            <form action="#" className="signup1">
              <div className="field1">
                <input
                  type="text"
                  name="email"
                  value={user.email}
                  placeholder="Email Address"
                  onChange={handleChange}
                  required
                ></input>
              </div>
              <div className="field1">
                <input
                  type="password"
                  name="password"
                  value={user.password}
                  placeholder="Password"
                  onChange={handleChange}
                  required
                ></input>
              </div>
              <div className="field1">
                <input 
                  type="password"
                  name="repassword"
                  value={user.repassword}
                  placeholder="Confirm password"
                  onChange={handleChange}
                  required
                ></input>
              </div>
              <div className="field1 btn1">
                <div className="btn-layer1"></div>
                <input className="loginlogotext"  type="submit" value="Signup" onClick={navigateToHomepage}></input>
              </div>
            </form>
          </div>
        </div>
        
      </div>
      <div className="loginimagediv">
      <img src={logo} />
      </div>
      </div>
      
    </div>
    </div>
  );
}
