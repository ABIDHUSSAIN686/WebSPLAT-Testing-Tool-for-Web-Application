import React, { useState, useEffect } from 'react';
import ReactDOM from 'react-dom';
import { Pie } from '@ant-design/plots';
import path from '../GraphsData/data.json'
/**** 
  DemoPie is used to show differences of the 
  whole Variant in form of PieChart
 ****/
const DemoPie = () => {
  const [data, setData] = useState([]);
  /****
  Used to directly fetch  data and update DOM 
  ****/
  useEffect(() => {
    asyncFetch();
  }, []);
  /****
  Fetching the data from the data.json file  
  ****/
  const asyncFetch = () => {
    console.log(path)
    if (path===[]){
      path=[{'type':"none",'value':0}]
    }
    setData(path)
  };
  /****
  Configuartion File for the BarChart  
  ****/
  const config = {
    appendPadding: 25,
    data,
    style: {
      fill:'black',
      fontSize:10,
        stroke:'black',
    },
    angleField: 'value',
    colorField: 'type',
    radius: 0.8,
    label: {
      type: 'outer',
      content: '{name} {percentage}',
      style: {
        fill:'black',
        fontSize:10,
        stroke:'black',
      },
    },
    interactions: [     
      {
        type: 'pie-legend-active',style: {
          fill: 'black',
          fontSize:10,
          stroke:'black',
        },
      },
      {
        type: 'element-active',
        
      },
    ],
  };
  return <Pie {...config} />;
};

export default DemoPie