import React, { useState, useEffect } from 'react';
import ReactDOM from 'react-dom';
import {useLocation} from 'react-router-dom';
import { Bullet, Column } from '@ant-design/plots';
import axios from "axios";

/****
  Bar Chart is used to show the delta changes of 
  Feature 
 ****/
const BarChart = () => {

  const location = useLocation();
	console.log(location.state.name+"Bar Chart")
  let data1 = require("../GraphsData"+location.state.name+"/data.json");
  const [data, setData] = useState([]);
  /****
  Used to directly fetch  data and update DOM 
  ****/
  useEffect(() => {
    asyncFetch();
  }, []);

  /****
  Fetching the data from the data.json file  
  ****/
  const asyncFetch = () => {
    if (data1===[{}]){
      data1=[{"type":"none","value":0}]
      setData(data1)
    }
    setData(data1)
  };
  /****
  Configuartion File for the BarChart  
  ****/
    const config = {
      data,
      xField: 'type',
      yField: 'value',
      xAxis: {
        label: {
          autoRotate: false,
          style: {
            fill:'black',
            fontSize:12,
          },
        },
      },
      scrollbar: {
        type: 'horizontal',
      },
    };
    return <Column {...config} />;
};
export default BarChart;