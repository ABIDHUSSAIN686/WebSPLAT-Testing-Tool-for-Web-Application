import Button from 'react-bootstrap/Button';
import Container from 'react-bootstrap/Container';
import Form from 'react-bootstrap/Form';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import NavDropdown from 'react-bootstrap/NavDropdown';
import TestCaseMapping from "../Pages/TestCaseMapping"
import './NavBar.css'
/**** 
  NavScrollExample is used to display the 
  navbar on the top of screen
 ****/
function NavScrollExample() {
  return (
    <Navbar  className="NavBarDiv" collapseOnSelect expand="lg"  variant='light' >
      <Container fluid>
        <Navbar.Brand className="loginlogotext2" href="#" style={{fontSize:"25px"} }><b>WEBSPLAT</b></Navbar.Brand>
        <Navbar.Toggle aria-controls="navbarScroll" />
        <Navbar.Collapse id="navbarScroll">
          <Nav
            className=" me-auto my-2 my-lg-0"
            style={{ maxHeight: '100px' }}
            navbarScroll
          >
            <Nav.Link className="loginlogotext1" href="/home" style={{color:"black"}}><b>Home</b></Nav.Link>
            <Nav.Link className="loginlogotext1"href="/testing_variant" style={{color:"black"}}><b>Variant Testing</b></Nav.Link>
            <Nav.Link className="loginlogotext1" href="/pdf_viewer" style={{color:"black"}}><b>View Differences</b></Nav.Link>
            <Nav.Link className="loginlogotext1" href="/TestCaseMapping" style={{color:"black"}}><b>TestCases Mapping</b></Nav.Link>
          </Nav>
          <Nav className=" me-auto my-2 my-lg-0"
            style={{ maxHeight: '100px' }}
            navbarScroll>
          </Nav>
          <Nav className="me my-2 my-lg-0"
            style={{ maxHeight: '100px' }}
            navbarScroll>
          <Nav.Link className="loginlogotext1"  href="/" style={{color:"black"}}><b>SignIn</b></Nav.Link>
          <Nav.Link  className="loginlogotext1" href="/" style={{color:"black"}}><b>LogOut</b></Nav.Link>
          </Nav>
        </Navbar.Collapse>
      </Container>
    </Navbar>
  );
}

export default NavScrollExample;
